
This lexicon was compiled using Adam Kilgariff's compiled BNC database and word frequency 
lists. (http://www.itri.brighton.ac.uk/~Adam.Kilgarriff/bnc-readme.html)

We have first put everything in a Prolog format.

We have then mapped all tags to correspond to those of the Penn Treebank 
that we already use.

We have considered the words that do not occur in the lexicon of the WSJ 
that we already have.

We have considered words that occur more than (or equal) to 40 times.

'40 occurrences' was chosen arbitrarily. There are still a lot of words that could never 
occur in a Biology domain. A lot of words are bizarre or just lists of symbols.
Hence, this list could be sifted even more.


Jana Sukkarieh, Summer 2003.   
