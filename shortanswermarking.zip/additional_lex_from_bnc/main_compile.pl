
:- multifile lx/2.
:- dynamic lx/2.

:- compile('unseen_cwritten_a_1.pl').
:- compile('unseen_cwritten_a_2.pl').
:- compile('unseen_cwritten_b_1.pl').
:- compile('unseen_cwritten_b_2.pl').
:- compile('unseen_cwritten_c_1.pl').
:- compile('unseen_cwritten_c_2.pl').
:- compile('unseen_cwritten_d.pl').
:- compile('unseen_cwritten_e.pl').
:- compile('unseen_cwritten_f.pl').
:- compile('unseen_cwritten_g.pl').
:- compile('unseen_cwritten_h.pl').
:- compile('unseen_cwritten_i.pl').
:- compile('unseen_cwritten_j.pl').
:- compile('unseen_cwritten_k.pl').
:- compile('unseen_cwritten_l.pl').
:- compile('unseen_cwritten_m_1.pl').
:- compile('unseen_cwritten_m_2.pl').
:- compile('unseen_cwritten_n.pl').
:- compile('unseen_cwritten_o.pl').
:- compile('unseen_cwritten_p_1.pl').
:- compile('unseen_cwritten_p_2.pl').
:- compile('unseen_cwritten_q.pl').
:- compile('unseen_cwritten_r.pl').
:- compile('unseen_cwritten_s_1.pl').
:- compile('unseen_cwritten_s_2.pl').
:- compile('unseen_cwritten_t.pl').
:- compile('unseen_cwritten_u.pl').
:- compile('unseen_cwritten_v.pl').
:- compile('unseen_cwritten_w.pl').
:- compile('unseen_cwritten_x.pl').
:- compile('unseen_cwritten_y.pl').
:- compile('unseen_cwritten_z.pl').

