:- multifile answer/4.

answer(number(5),part(a),subpart(ii),[1, 0  ," by the male sperm and female egg being reproduced but there was two of each therefore they split into 2 in the fetus "]).
answer(number(5),part(a),subpart(ii),[2, 0 ,"   
They have the same number of chromosomes   
 "]).
answer(number(5),part(a),subpart(ii),[3, 0 ,"	The same sperm and egg's. "]).
answer(number(5),part(a),subpart(ii),[4, 0	,"2 lots of sperm got there "]).
answer(number(5),part(a),subpart(ii),[5, 1	," The chromosomes which give them their appearance are identical "]).
answer(number(5),part(a),subpart(ii),[6,noanswer]).
answer(number(5),part(a),subpart(ii),[7, 0  ,"	The mans sperm has caused these twins to be identical because twins look the same but they are different to normal brouthers or sisters. "]).
answer(number(5),part(a),subpart(ii),[8, 0 ,"	as the sperm travels through it has got split up and gone into 2 eggs instead of one and that is how the twins have developed. "]).
answer(number(5),part(a),subpart(ii),[9,noanswer]).
answer(number(5),part(a),subpart(ii),[10, 0	," The twins are made up of the exact same chromosones. They have taken on the same parent "]).
answer(number(5),part(a),subpart(ii),[11, 2 ,"	The twins both have the same genes and their chromosomes are both the same as each other "]).
answer(number(5),part(a),subpart(ii),[12, 1 ," These twins are identical because they come from the same sperm and same egg, which has then seperated / split into 2.   
"]).
answer(number(5),part(a),subpart(ii),[13, 1 ," the egg at some point after fertilization split in to to there for so did the chromosomes every thing doubled.  
"]).
answer(number(5),part(a),subpart(ii),[14, 1 ,"when the egg gets released something happens to make the egg split in half so therefore you get two babies inside of you. "]).
%answer(number(5),part(a),subpart(ii),[15, 1	," The twins are identical, because they have been fertisied, & the egg has gone into two ! "]).
answer(number(5),part(a),subpart(ii),[15, 1	," The twins are identical, because they have been fertilised, & the egg has gone into two ! "]).
answer(number(5),part(a),subpart(ii),[16,noanswer]).
%answer(number(5),part(a),subpart(ii),[17,1	,"The same sperm fertlising the same egg and being broken into two parts"]).
answer(number(5),part(a),subpart(ii),[17,1	,"The same sperm fertilising the same egg and being broken into two parts"]).
answer(number(5),part(a),subpart(ii),[18,noanswer]).
answer(number(5),part(a),subpart(ii),[19,noanswer]).
answer(number(5),part(a),subpart(ii),[20, 0	,"The rasions why the two twins are identical is because the are bothe faceing the son proaestion."]).
answer(number(5),part(a),subpart(ii),[21, 1	,"Because the genes of the embryo are identical because the chromosomes are identical."]).
answer(number(5),part(a),subpart(ii),[22, 1	,"The egg has been fertilized by one sperm and has split in half."]).
answer(number(5),part(a),subpart(ii),[23, 1	,"When the sperm and egg fertilised the embryo split, causing the nucleus to seprate into two different embroys "]).
answer(number(5),part(a),subpart(ii),[24, 1	,"They are from the same egg and sperm."]).
%answer(number(5),part(a),subpart(ii),[25, 1	,"The fetus has been split in to two after fertalizeation"]).
answer(number(5),part(a),subpart(ii),[25, 1	,"The fetus has been split in to two after fertilization"]).
answer(number(5),part(a),subpart(ii),[26, 0	,"The reason why the twins are identical is because it is something to do with the chromosomes"]).
answer(number(5),part(a),subpart(ii),[27, 0	,"instead of one egg there are two eggs being fertilised in the uterus."]).
answer(number(5),part(a),subpart(ii),[28, 0	,"Because they both came out of the same line-(sperm), and thats what make twins identical"]).
answer(number(5),part(a),subpart(ii),[29, 1	,"One egg has been released and one sperm has split the egg in two after being fertilized."]).
answer(number(5),part(a),subpart(ii),[30,0	,"same egg"]).
answer(number(5),part(a),subpart(ii),[31, 0	,"the two sperm chromosones found the same chromosones or xx."]).
answer(number(5),part(a),subpart(ii),[32,0	,"The egg has nvertlertised in to twos because more than one sperm as reashed the egg"]).
answer(number(5),part(a),subpart(ii),[33,0	,"one babys jeenes has mixed with the others."]).
answer(number(5),part(a),subpart(ii),[34, 1	,"When the zygote reaches the womb it splits in two and then both fertises are there they grow normaly like normal babies. Each nucleus is identicle because two sperm cells got in to the egg."]).
answer(number(5),part(a),subpart(ii),[35,noanswer]).
answer(number(5),part(a),subpart(ii),[36,1 ,"	the fertilized egg has split into two & reattached them selves to the uterus"]).
answer(number(5),part(a),subpart(ii),[37,0	,"From the mothers mother or father it produces two eggs instead of one, the eggs released twice"]).
answer(number(5),part(a),subpart(ii),[38,0	,"One sperm from the male as fertilized the egg. The sperm then splits inside to produce identical twins."]).
answer(number(5),part(a),subpart(ii),[39,0	,"these twins are identical because 2 sperm cell make it in to one egg.  
"]).
answer(number(5),part(a),subpart(ii),[40,0	,"Both living on the same embryo's"]).
answer(number(5),part(a),subpart(ii),[41, 0	,"When sexual intercourse took place, two sperms fertilised one egg and the egg split into two, creating identical twins.  
"]).
answer(number(5),part(a),subpart(ii),[42,1	," The twins were in one same cell and the cell split into two this caused the twins to have exatly the same chromosomes."]).
answer(number(5),part(a),subpart(ii),[43,1	," Because they joint, (not properly) and so are growing together the same. They will have the same genes."]).
answer(number(5),part(a),subpart(ii),[44, 0	," This is because the parents have the same chromosomes and they might have similar jean's"]).
answer(number(5),part(a),subpart(ii),[45,0	," They could have it in the jeans"]).
answer(number(5),part(a),subpart(ii),[46,0	," The cell membrane is the same within the eggs which makes the babies the same."]).
answer(number(5),part(a),subpart(ii),[47,1	,"When the egg was fertilized it split in two to form 2 embryos which were identical."]).
answer(number(5),part(a),subpart(ii),[48, 1	," The chromosomes are identical and split into two. It has the same genitic information going into two of them."]).
answer(number(5),part(a),subpart(ii),[49, 0	," They have had the same amount of the x and y gene which then causes them to be identical. "]).
answer(number(5),part(a),subpart(ii),[50,noanswer]).
answer(number(5),part(a),subpart(ii),[51,0	," The thing that has caused these twins to be identical is the fact that when the sperm has developed and spread it connected making to babies which are twins to be identical."]).
answer(number(5),part(a),subpart(ii),[52, 0	," because they both have the same human cell of a human embryo"]).
answer(number(5),part(a),subpart(ii),[53,noanswer]).
answer(number(5),part(a),subpart(ii),[54,0	," Because they are in the same egg."]).
answer(number(5),part(a),subpart(ii),[55,0	," If one twin is the same the other one is going to be the same to."]).
answer(number(5),part(a),subpart(ii),[56,0	," the identical twins are growing from one chromosone"]).
%answer(number(5),part(a),subpart(ii),[57, 1	,"When the egg was fertelised it split into two."]).
answer(number(5),part(a),subpart(ii),[57, 1	,"When the egg was fertilised it split into two."]).
answer(number(5),part(a),subpart(ii),[58, 0	,"because they have come from the same overy"]).
answer(number(5),part(a),subpart(ii),[59,0	,"The nuclear of a cell has produced a copy of itself since two eggs where released from the ovarys."]).
answer(number(5),part(a),subpart(ii),[60,0	," because they could have exactly the same amount of DNA from one parents and exactly the same DNA from the orther"]).
answer(number(5),part(a),subpart(ii),[61,0	,"The sperm helped the egg to reproduce another baby at the same time as the first one."]).
answer(number(5),part(a),subpart(ii),[62,2	,"They are from only 1 egg and sperm so have the same genetic material."]).
answer(number(5),part(a),subpart(ii),[63,noanswer]).
answer(number(5),part(a),subpart(ii),[64,0	,"As the eggs developed instead of all the eggs going into one it split into two..  
"]).
answer(number(5),part(a),subpart(ii),[65, 0	,"The cause to these identical twins is that the mother has send two same eggs.  
"]).
answer(number(5),part(a),subpart(ii),[66, 0	," Because the sperm split in to two so there like the other half an equal so thats 1 the're there identical twins."]).
answer(number(5),part(a),subpart(ii),[67,0	," The genes of the sperm were same and when they collided together they twins."]).
answer(number(5),part(a),subpart(ii),[68,0	,"because they have the same sperm cells from they mother and father therefore they are identical twins."]).
answer(number(5),part(a),subpart(ii),[69, 0	," Two sperms have joined together."]).
answer(number(5),part(a),subpart(ii),[70,0	," The chromosomes have been matched."]).
answer(number(5),part(a),subpart(ii),[71,noanswer]).
answer(number(5),part(a),subpart(ii),[72, 0	,"The sperm cell's going in at the same time and the mother and the fathers genes make these twins identical."]).
answer(number(5),part(a),subpart(ii),[73,0	," Theye are conected to the same side of the uterus."]).
%answer(number(5),part(a),subpart(ii),[74,2	," When the egg becomes firtilized and starts to develop it muliply's and splits up in to 2 different eggs with the same genetic information for growth."]).
answer(number(5),part(a),subpart(ii),[74,2	," When the egg becomes fertilized and starts to develop it muliplies and splits up in to 2 different eggs with the same genetic information for growth."]).
%answer(number(5),part(a),subpart(ii),[75,2	," When a sperm cell had fertisised the egg the egg then splits into two so the same genetics are in each embryo to form identical twins"]).
answer(number(5),part(a),subpart(ii),[75,2	," When a sperm cell had fertilised the egg the egg then splits into two so the same genetics are in each embryo to form identical twins"]).

answer(number(5),part(a),subpart(ii),[76,1	," Because they have both come from the same egg & sperm which when fertilised has split and made two of the same kind."]).
%answer(number(5),part(a),subpart(ii),[77,1	," The egg splits in half and the jeans are all the same"]).
answer(number(5),part(a),subpart(ii),[77,1	," The egg splits in half and the genes are all the same"]).

answer(number(5),part(a),subpart(ii),[78,0	,"because they are growing on the same egg they share chromosomes"]).
answer(number(5),part(a),subpart(ii),[79,0	," 2 sperms have fertillsed 1 egg which then splits in to two: causes them to be identical"]).
answer(number(5),part(a),subpart(ii),[80,0	,"The twins are identical because they shared the same amount of the same sperm from the mother and farther."]).
answer(number(5),part(a),subpart(ii),[81,1	,"The same chromosomes"]).
answer(number(5),part(a),subpart(ii),[82,0	,"The twins are identical due to two identical genes. This happen when one gene splits to form two."]).
answer(number(5),part(a),subpart(ii),[83,0	,"Two egg sperms have got on to the egg and have both been fertilised."]).
%answer(number(5),part(a),subpart(ii),[84,1	," Both will have the same gens and both will have the same amounts of chromosomes."]).
answer(number(5),part(a),subpart(ii),[84,1	," Both will have the same genes and both will have the same amounts of chromosomes."]).
answer(number(5),part(a),subpart(ii),[85,noanswer]).
answer(number(5),part(a),subpart(ii),[86,2	,"The egg from the mother must of split and so while fertilised there are now two eggs and both contain the same genetic code so are identical."]).
answer(number(5),part(a),subpart(ii),[87,0	,"The father and the mother gave the same jeans"]).
answer(number(5),part(a),subpart(ii),[88,0	," Because of the xx and xy chromosones. The xx take over the xy and you have twins."]).
answer(number(5),part(a),subpart(ii),[89,0	,"Because the cells are the same"]).
answer(number(5),part(a),subpart(ii),[90,0	,"The genes of the parents form together to make the same babys."]).
answer(number(5),part(a),subpart(ii),[91,0 ,"	The twins are identical because"]).
answer(number(5),part(a),subpart(ii),[92,0	," living on the wall as each other."]).
answer(number(5),part(a),subpart(ii),[93,noanswer]).
answer(number(5),part(a),subpart(ii),[94,0	," The egg has split equally in two so that then creates identical twins."]).
answer(number(5),part(a),subpart(ii),[95,1	," Because the fertilized egg has divided in two, which means that each twin has half of the chromosomes."]).
answer(number(5),part(a),subpart(ii),[96, 0	,"The x and y chromosomes at the end were both x or both y and also, if one or both of the parents have had twins in the family."]).
answer(number(5),part(a),subpart(ii),[97, 1	,"1 fertilized egg splits into 2 which produces identical twin"]).
answer(number(5),part(a),subpart(ii),[98, 0	,"There have been too many chrosome there found in the uterus of the human body which made this to happen. "]).
answer(number(5),part(a),subpart(ii),[99,0	,"The egg breaks up into small parts so the baby what is inside of them becomes twins"]).
answer(number(5),part(a),subpart(ii),[100,noanswer]).
answer(number(5),part(a),subpart(ii),[101,0	,"because the sperm was as strong strong as each other so they both got to the uterus at the same time"]).
answer(number(5),part(a),subpart(ii),[102,0	,"The mother and father passed on the same amount of genes to each of them "]).
answer(number(5),part(a),subpart(ii),[103,0	,"The genes in the male & female. The chromosomes are hetrozygous "]).
%answer(number(5),part(a),subpart(ii),[104,1	,"One sperm has fertlised, one egg which has split into 2, producing identical twins.  "]).
answer(number(5),part(a),subpart(ii),[104,1	,"One sperm has fertilised, one egg which has split into 2, producing identical twins.  "]).
answer(number(5),part(a),subpart(ii),[105,1	,"When an egg is released from the ovaries, their is one egg, however after it is fertilized, the cell splits and therefore there are 2 cells, but from the same egg."]).

answer(number(5),part(a),subpart(ii),[106,1	,"The turns were formed from the same egg and one sperm but the egg separted into two. This is known as mitosis "]).
answer(number(5),part(a),subpart(ii),[107,0	," an egg has split in 2 and they are both attached to the same part of the uterus"]).
answer(number(5),part(a),subpart(ii),[108,0	," because genes have come from the mother and father of equal amounts and the parent might have similar genes."]).
answer(number(5),part(a),subpart(ii),[109,0	,"when fertilising the egg the sperm split into two forming the identical babies"]).
answer(number(5),part(a),subpart(ii),[110,1	,"Both their chromosomes are the same"]).
answer(number(5),part(a),subpart(ii),[111,1	," When they were fertilized the ball of cells divide so they have the same genes "]).
answer(number(5),part(a),subpart(ii),[112,0	," they are living off the same tube  
"]).
answer(number(5),part(a),subpart(ii),[113,2	," When the egg was fertilized it split into two seperate embryo's and they contained the same genes.  
"]).
answer(number(5),part(a),subpart(ii),[114,	0	,"The eggs were fertilised at the same time, two sperm fertilised the egg, cells divided my meiosis. "]).
answer(number(5),part(a),subpart(ii),[115, 1	,"Melosis has played a part as they have split of and ended up with the same genes that went into one, into both."]).
answer(number(5),part(a),subpart(ii),[116,0	,"because the egg has formed into two so they are identical twins in side the humans body."]).
answer(number(5),part(a),subpart(ii),[117,0	,"the male chromosomes have connected to the female chromosomes which add up to 46 and then they brake apart from each other to form twins. "]).
answer(number(5),part(a),subpart(ii),[118,1	,"They have shared chromosomes, so they will be sharing the same genes, this is how they become identical twins."]).
answer(number(5),part(a),subpart(ii),[119,	0	,"a sperm has got in each egg at the same time. "]).
answer(number(5),part(a),subpart(ii),[120,	0	,"the chromosomes have split up into two pairs of 32, these chromosomes are identical."]).
%answer(number(5),part(a),subpart(ii),[121,	1	,"they are same because they have the same chromosones from when they were fertilizing. The same type of sperm."]).
answer(number(5),part(a),subpart(ii),[121,	1	,"they are same because they have the same chromosomes from when they were fertilizing. The same type of sperm."]).
%answer(number(5),part(a),subpart(ii),[122,1	,"They have both come from the same membrane and the egg which makes them the same and the same chromosones."]).
answer(number(5),part(a),subpart(ii),[122,1	,"They have both come from the same membrane and the egg which makes them the same and the same chromosomes."]).
answer(number(5),part(a),subpart(ii),[123,	0	,"It is from one different egg to make it identical"]).
answer(number(5),part(a),subpart(ii),[124,0	,"the cell neucluse has split into, to so there are to eggs and so this sperm can come into contacter one for each instead of just on egg being their"]).
answer(number(5),part(a),subpart(ii),[125,1	,"when the cells of the embryo started to develop it split into 2 making two children identical because they are from the same egg and sperm "]).
answer(number(5),part(a),subpart(ii),[126,2	,"the embryo has split and as the egg has the same genes it means that the twins will be identical "]).
answer(number(5),part(a),subpart(ii),[127,0	,"the embryo had spit apart during the pregnancy and formed two embryo's"]).
answer(number(5),part(a),subpart(ii),[128,0	,"What has these to be identical is that they have no divides and stuck together they share there amian, card placenta and amian. Genes caused them to be identical."]).
answer(number(5),part(a),subpart(ii),[129,0	,"These twins are born together of the same embryo which would make them identical"]).
answer(number(5),part(a),subpart(ii),[130,0	,"it might run in a family or it something what in girl body"]).
answer(number(5),part(a),subpart(ii),[131,0	,"When sperm has reached the egg and two bits of produce the same kid twice"]).
answer(number(5),part(a),subpart(ii),[132,1	,"The twins are identical because each embryo has exactly the same chromosomes each"]).
answer(number(5),part(a),subpart(ii),[133,0	,"because the sperm when into the egg at the very same time."]).
%answer(number(5),part(a),subpart(ii),[134,2	,"They share the chromosones so they have the same genetic makeup. This is because the zygotte splits into two parts."]).
answer(number(5),part(a),subpart(ii),[134,2	,"They share the chromosones so they have the same genetic makeup. This is because the zygote splits into two parts."]).
answer(number(5),part(a),subpart(ii),[135,1	,"The are both from the same sperm which they would have all the same chromosomes so they would be exactly the same "]).
answer(number(5),part(a),subpart(ii),[136,0	,"The genes of one of the parents has been two making the identicle twins ."]).
%answer(number(5),part(a),subpart(ii),[137,2	,"they share the same amount of chromosomes and have identicle DNA. They have also grown from the same fertilized egg."]).
answer(number(5),part(a),subpart(ii),[137,2	,"they share the same amount of chromosomes and have identical DNA. They have also grown from the same fertilized egg."]).
answer(number(5),part(a),subpart(ii),[138,	0	,"sperm"]).
answer(number(5),part(a),subpart(ii),[139,	0	,"The egg must have split into two before fertilization."]).
answer(number(5),part(a),subpart(ii),[140,1	,"They have the exact same genes and the exact same number of genes from mum and dad."]).
answer(number(5),part(a),subpart(ii),[141,0	,"the are both growing from the same egg but the egg is attached to both of them. "]).
answer(number(5),part(a),subpart(ii),[142,0	,"when to eggs are fertelised"]).
answer(number(5),part(a),subpart(ii),[143,0	,"because they have reached the egg at the same time and are forming together."]).
answer(number(5),part(a),subpart(ii),[144,1	,"They both recieved the same amount of chromosomes they have the same chromosomes "]).
answer(number(5),part(a),subpart(ii),[145,0	,"You can have different types of chromosomes but all of these were the same"]).
answer(number(5),part(a),subpart(ii),[146,0	,"Two pieces of spurm got in instead of one which make twin"]).
answer(number(5),part(a),subpart(ii),[147,noanswer]).
answer(number(5),part(a),subpart(ii),[148,noanswer]).
answer(number(5),part(a),subpart(ii),[149,1	,"The exact same number of chromosomes have been added to the twins, and they come from the same egg and sperm. "]).
answer(number(5),part(a),subpart(ii),[150,noanswer]).
answer(number(5),part(a),subpart(ii),[151,noanswer]).
answer(number(5),part(a),subpart(ii),[152,0	,"they were fertlised by one sperm one split into two."]).
%answer(number(5),part(a),subpart(ii),[153,1	,"Their was one egg ferstilied which split into two which formed twins -identical, where as they will look the same "]).
answer(number(5),part(a),subpart(ii),[153,1	,"There was one egg fertilised which split into two which formed twins -identical, where as they will look the same "]).
answer(number(5),part(a),subpart(ii),[154,0	,"when chromosomes get in pairs the go through so when the sperm lets through the vagina and pair links up "]).
answer(number(5),part(a),subpart(ii),[155,0	,"The egg has split to 2 parts when the egg was released, and when the fetuses were developing, so they were on the same spongy area."]).
answer(number(5),part(a),subpart(ii),[156,0	,"When the sperm swims to the egg and the egg splits up in two. "]).
answer(number(5),part(a),subpart(ii),[157,0	,"if both sexes are same and have identical eggs and same amount of chromosomes in there genes."]).
answer(number(5),part(a),subpart(ii),[158,0	,"because it is show have the two identical twin's growing in your uterus."]).
answer(number(5),part(a),subpart(ii),[159,1	,"One sperm has fertilised one egg and the egg that has been fetiled has split in two, so the both share the same placenta. "]).

answer(number(5),part(a),subpart(ii),[160,0	,"The female has released two identical eggs at the same time. "]).
answer(number(5),part(a),subpart(ii),[161,1	,"a zygote has split into two exactly identical bundles of cells."]).
answer(number(5),part(a),subpart(ii),[162,1	,"They have been fertilized by same egg when it was fertilized they split too make two identical child grow."]).
answer(number(5),part(a),subpart(ii),[163,0	,"It is probably because of the genes that run in the family. If someone has got twins in the family. "]).
answer(number(5),part(a),subpart(ii),[164,noanswer]).
answer(number(5),part(a),subpart(ii),[165,1	,"Firstly there was only one egg fertilised by one sperm, but when the gametes were splitting it splitted into half. They are likely to be sharing the same placenta "]).
answer(number(5),part(a),subpart(ii),[166,1	,"the egg split and gave them the same DNA"]).
answer(number(5),part(a),subpart(ii),[167,0	,"When the sperm fertilised the egg the egg then split into two halves causing identical twins "]).
answer(number(5),part(a),subpart(ii),[168,0	,"because its in the genes."]).
answer(number(5),part(a),subpart(ii),[169,noanswer]).
answer(number(5),part(a),subpart(ii),[170,1	,"the genes of the move and father and when the egg were feartilised the broken in too to two "]).
answer(number(5),part(a),subpart(ii),[171,0	,"These twins are identical because the sperm split into two and stayed together. "]).
answer(number(5),part(a),subpart(ii),[172,0	,"they are growing of the same part uterus "]).
answer(number(5),part(a),subpart(ii),[173,1	,"The fertilised egg split into 2. "]).
answer(number(5),part(a),subpart(ii),[174,0	,"The chromosomes have fused together taking similar genetic information from each other. "]).
answer(number(5),part(a),subpart(ii),[175,1	,"they were produce from the same embryo insted of there being 2 embroyo's produced  "]).
answer(number(5),part(a),subpart(ii),[176,0	,"the sperm fertiliszes 2 different eggs "]).
answer(number(5),part(a),subpart(ii),[177,noanswer]).
answer(number(5),part(a),subpart(ii),[178,noanswer]).
%answer(number(5),part(a),subpart(ii),[179,2	,"Two sets of identicle chromosomes were made when the sperm and egg met together. The egg split to make two. "]).
answer(number(5),part(a),subpart(ii),[179,2	,"Two sets of identical chromosomes were made when the sperm and egg met together. The egg split to make two. "]).
answer(number(5),part(a),subpart(ii),[180,1	,"When a sperm meets an egg and during fertilisation the fertilised eggs divides into 2  "]).
answer(number(5),part(a),subpart(ii),[181,1	,"They are from the same egg that has split in two early on. There fore the foetus start to grow with identical genetics. "]).
%answer(number(5),part(a),subpart(ii),[182,1	,"Once an egg was fertised, it split in to two, causing identical twins to be born. "]).
answer(number(5),part(a),subpart(ii),[182,1	,"Once an egg was fertilised, it split in to two, causing identical twins to be born. "]).
%answer(number(5),part(a),subpart(ii),[183,1	,"The egg produced by the women interatced with the sperm then the egg split into two diffrent eggs forming identical twins.  "]).
answer(number(5),part(a),subpart(ii),[183,1	,"The egg produced by the women interacted with the sperm then the egg split into two diffrent eggs forming identical twins.  "]).
answer(number(5),part(a),subpart(ii),[184,0	,"In this unlikely event, Two sperms has fertilized the egg. The cells have grown and stayed together in the protective outings to form 2 babys that are identical "]).
answer(number(5),part(a),subpart(ii),[185,0	,"The cell divides and they are then separated to form two babies and then continues to divide.  "]).
answer(number(5),part(a),subpart(ii),[186,1	,"the egg split equaly giving each embyo the same amount of chromosomes. "]).
answer(number(5),part(a),subpart(ii),[187,0	,"Exactly the same amount of chromosomes has caused these twins to be identical. "]).
answer(number(5),part(a),subpart(ii),[188,0	,"their DNA has been fertilised twice. Same sperm, but split in to two.  "]).
answer(number(5),part(a),subpart(ii),[189,0	,"the egg split doen the middle and formed twins  "]).
answer(number(5),part(a),subpart(ii),[190,0	,"The twins have become identicle because during fertilization a sperm fertilized 1 egg / causing it to split / ?  "]).
answer(number(5),part(a),subpart(ii),[191,1	,"When the cells where dividing some broke off and began to devide aswell and therefore to zygotes where formed from the same sperm and egg "]).
answer(number(5),part(a),subpart(ii),[192, 0	,"The nucleus has split into two multicelvar) causing the chromosones (xy) to be split identically. Because they come from the same one they will be identical. "]).
answer(number(5),part(a),subpart(ii),[193,noanswer]).
answer(number(5),part(a),subpart(ii),[194,0	,"The egg split many time's making two half's. "]).
%answer(number(5),part(a),subpart(ii),[195,1	,"the embroyos has come from the same xygote and split evenly "]).
answer(number(5),part(a),subpart(ii),[195,1	,"the embroyos has come from the same zygote and split evenly "]).
answer(number(5),part(a),subpart(ii),[196,0	,"There has been more chromosomes in the neucleus so this has formed twins "]).

answer(number(5),part(a),subpart(ii),[197,0	,"genes will make the identical they may iherit genes from parents, giving them a certain hair or eye colour or / and disabilities. "]).
%answer(number(5),part(a),subpart(ii),[198,2	,"The twins have each got the same chromosones as each other, and were formed when 1 egg became fertilised, which then split into 2. "]).
answer(number(5),part(a),subpart(ii),[198,2	,"The twins have each got the same chromosomes as each other, and were formed when 1 egg became fertilised, which then split into 2. "]).
answer(number(5),part(a),subpart(ii),[199,1	,"The embryo has divided like it's suposed to but then it divides again which instead of 1 whole embryo it is split into 2 halfs. "]).
answer(number(5),part(a),subpart(ii),[200,1	,"The twins are identical cause the chromosomes have doubled giving them the same genes. "]).
answer(number(5),part(a),subpart(ii),[201,0	,"One person had the beans for this to happen "]).
