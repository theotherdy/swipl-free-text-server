:- multifile answer/4.

answer(number(12),part(c),subpart(i),[1,0	,"The maggots do it quicker "]).
answer(number(12),part(c),subpart(i),[2,0	,"The maggots use a lot more air than woodlice. "]).
answer(number(12),part(c),subpart(i),[3,0	,"Because they don't need as much oxygen. "]).
answer(number(12),part(c),subpart(i),[4,1	,"The maggots use up more oxygen, the coloured water drop moves further in the same time "]).
answer(number(12),part(c),subpart(i),[5,1	,"When useing Fly maggots the coloured water moves faster than with woodlice "]).
answer(number(12),part(c),subpart(i),[6,0	,"The fly maggots take in less oxygen. "]).
answer(number(12),part(c),subpart(i),[7,1	,"the coloured water moved further in short space of time "]).
answer(number(12),part(c),subpart(i),[8,0	,"There is more water going in per mins. "]).
answer(number(12),part(c),subpart(i),[9,noanswer]).
answer(number(12),part(c),subpart(i),[10,0	,"the maggots use more oxygen you can see the results are giving up in bigger numbers with the fly maggots."]).
answer(number(12),part(c),subpart(i),[11,1	,"The maggots have used up oxygen quicker. "]).
answer(number(12),part(c),subpart(i),[12,1	,"The results that the fly maggots use up more oxygen than woodlice as the coloured water moves futher and quicker "]).
answer(number(12),part(c),subpart(i),[13,1	,"the maggots used more oxygen "]).
answer(number(12),part(c),subpart(i),[14,0	,"maggots have a faster reaction (go quicker) "]).
answer(number(12),part(c),subpart(i),[15,1	,"The maggots are using more oxygen than the woodlice. "]).
answer(number(12),part(c),subpart(i),[16,1	,"in the same amount of time they use more oxygen. "]).
answer(number(12),part(c),subpart(i),[17,1	,"The maggots use up more oxygen. "]).
answer(number(12),part(c),subpart(i),[18,2	,"The fly maggosts seemed to have used up more oxygen as the dye moved further.  "]).
answer(number(12),part(c),subpart(i),[19,1	,"The maggots use oxygen quicker than the woodlice. The maggots "]).
answer(number(12),part(c),subpart(i),[20,1	,"The woodlice didn't use as much oxygen as the fly maggots as the distance that the drop of water moved was much more for maggots than woodlice. "]).
answer(number(12),part(c),subpart(i),[21,1	,"in maggots the drop of coloured water moves faster. "]).
answer(number(12),part(c),subpart(i),[22,1	,"the fly maggots the distance of the drop moved quicker "]).
answer(number(12),part(c),subpart(i),[23,1	,"The coloured water moves a further distance with the fly maggots "]).
answer(number(12),part(c),subpart(i),[24,0	,"The results get higher  "]).
answer(number(12),part(c),subpart(i),[25,1	,"with the maggots the water moves faster. "]).
answer(number(12),part(c),subpart(i),[26,0	,"the maggots needed more (illegible) than the woodlice "]).
answer(number(12),part(c),subpart(i),[27,1	,"the water moved quicker with the maggots "]).
answer(number(12),part(c),subpart(i),[28,1	,"For maggots every minute passed distance increases 0.3 cm. For woodlice every minute passed increases 0.2 cm. "]).
answer(number(12),part(c),subpart(i),[29,	1	,"The maggots use more oxygen "]).
answer(number(12),part(c),subpart(i),[30,1	,"the maggots use more oxygen. "]).
answer(number(12),part(c),subpart(i),[31,0	,"There is not as much coloured water with the woodlice. "]).
answer(number(12),part(c),subpart(i),[32,0	,"the fly maggots move faster than the woodlice "]).
answer(number(12),part(c),subpart(i),[33,noanswer]).
answer(number(12),part(c),subpart(i),[34,noanswer]).
answer(number(12),part(c),subpart(i),[35,1	,"The maggots almost double in the distance moved."]).
answer(number(12),part(c),subpart(i),[36,1	,"the maggote used the oxygen quicker than the woodlice"]).
answer(number(12),part(c),subpart(i),[37,1	,"The maggots used up more oxygen in a given time than the woodlice did"]).
answer(number(12),part(c),subpart(i),[38,0	,"Because woodlice are more used to oxygen "]).
answer(number(12),part(c),subpart(i),[39,0	,"It is different probably because of the numbers going up."]).
answer(number(12),part(c),subpart(i),[40,1	,"After every 2 minutes the distance of coloured water moved further."]).
answer(number(12),part(c),subpart(i),[41,1	,"The maggots use up more, oxygen"]).
answer(number(12),part(c),subpart(i),[42,1	,"each result with maggots was more than the woodlice"]).
answer(number(12),part(c),subpart(i),[43,1	,"The fly maggots use up more oxygen than the woodlice do."]).
answer(number(12),part(c),subpart(i),[44,noanswer]).
answer(number(12),part(c),subpart(i),[45,1	,"maggots distance is much higher"]).
answer(number(12),part(c),subpart(i),[46,noanswer]).
answer(number(12),part(c),subpart(i),[47,0	,"The results with the maggots increase than the woodlice"]).
answer(number(12),part(c),subpart(i),[48,0	,"the fly maggots moved more with more coloured water"]).
answer(number(12),part(c),subpart(i),[49,1	,"The did the same longer they were left the more the water moved. The woodlice moved every 2 minutes 0.2 more but the maggots moved every 2 minutes 0.3 more "]).
answer(number(12),part(c),subpart(i),[50,0	,"more coloured water went in"]).
answer(number(12),part(c),subpart(i),[51,noanswer]).
answer(number(12),part(c),subpart(i),[52,noanswer]).
answer(number(12),part(c),subpart(i),[53,1	,"The distance with the maggots rises faster than with the woodlice."]).
answer(number(12),part(c),subpart(i),[54,noanswer]).
answer(number(12),part(c),subpart(i),[55,noanswer]).
answer(number(12),part(c),subpart(i),[56,noanswer]).
answer(number(12),part(c),subpart(i),[57,1	,"Because fly maggots take in more oxygen each time"]).
answer(number(12),part(c),subpart(i),[58,1	,"the coloured water moved quicker with the maggots."]).
answer(number(12),part(c),subpart(i),[59,0	,"because maggots can life without oxygen. And can live in water."]).
answer(number(12),part(c),subpart(i),[60,0	,"moved at different pace "]).
answer(number(12),part(c),subpart(i),[61,0	,"the maggots used up more air in 10 minutes"]).
answer(number(12),part(c),subpart(i),[62, 1	,"because the experiment with the maggots they used up oxygen quicker"]).
answer(number(12),part(c),subpart(i),[63,	1	,"Maggot respire at a higher rate as the gradient is steeper."]).
answer(number(12),part(c),subpart(i),[64,noanswer]).
answer(number(12),part(c),subpart(i),[65,1	,"maggots use far more oxygen than woodloce do"]).
answer(number(12),part(c),subpart(i),[66,1	,"The coloured water moves a lot quicker and more than with the woodlice."]).
answer(number(12),part(c),subpart(i),[67,1	,"It goes up at a faster rate."]).
answer(number(12),part(c),subpart(i),[68,1	,"The distance the cloloured water moves is bigger with the maggots. They use more oxygen."]).
answer(number(12),part(c),subpart(i),[69,0	,"because woodlice have more energy."]).
answer(number(12),part(c),subpart(i),[70,1	,"The fly maggots used oxygen quicker than the woodlice"]).
answer(number(12),part(c),subpart(i),[71,0	,"they use less oxygen"]).
answer(number(12),part(c),subpart(i),[72,0	,"Woodlice has legs maggots don't"]).
answer(number(12),part(c),subpart(i),[73,0	,"The experiment results are continuestly increasing which means that they are better creatures to do it on."]).
answer(number(12),part(c),subpart(i),[74,0	,"The woodlice use 02. Because the woodlice use 02 and when the drop coloured water was dropped at 0.3 it took less time than the flymaggots who dont use 02"]).
answer(number(12),part(c),subpart(i),[75,0	,"the maggots stay at at constant level of in take where as the woodlouse don't."]).
answer(number(12),part(c),subpart(i),[76,0	,"They differ because at 10 mins the woodlice are only at 0.8 when the maggots where at 1.5"]).
answer(number(12),part(c),subpart(i),[77, 1	,"the maggots use more oxygen than the woodlice"]).
answer(number(12),part(c),subpart(i),[78, 1	,"the maggots use oxygen faster"]).
answer(number(12),part(c),subpart(i),[79, 0	,"The maggots it higher in the drop of colour water"]).
answer(number(12),part(c),subpart(i),[80,	0	,"because the maggots might be a bit lighter"]).
answer(number(12),part(c),subpart(i),[81,	1	,"the maggots needed more oxygen"]).
answer(number(12),part(c),subpart(i),[82,	1	,"the maggots inhale more oxygen in the same time woodlice do. for the maggots the coloured water moved further then the woodlice in the same time "]).
answer(number(12),part(c),subpart(i),[83,0	,"they (the maggots) absorb the coloured water quicker "]).
answer(number(12),part(c),subpart(i),[84,1	,"The distance between the drop of coloured water + the syringe decreases much more quickly with the maggots."]).
answer(number(12),part(c),subpart(i),[85,1	,"the maggots use more oxygen than the woodlice"]).
answer(number(12),part(c),subpart(i),[86,0	,"because maggots and woodlice are two different insects"]).
answer(number(12),part(c),subpart(i),[87, 1	,"The distance moved was much more for the maggots than the woodlice at the same minutes."]).
answer(number(12),part(c),subpart(i),[88,	1	,"the maggots use more oxygen so the coloured water moves graph has steeper gradient further"]).
answer(number(12),part(c),subpart(i),[89,1	,"They seem to have used up more oxygen - The numbers get higher quicker - water moved further faster.  
"]).
answer(number(12),part(c),subpart(i),[90,1	," The maggots use more oxygen.  
"]).
answer(number(12),part(c),subpart(i),[91,0	,"woodlice use oxygen more than maggots "]).
answer(number(12),part(c),subpart(i),[92,1	," The drop of water moved alot faster along the tube."]).
answer(number(12),part(c),subpart(i),[93,0	,"The fly maggots had higher results"]).
answer(number(12),part(c),subpart(i),[94,1	,"the maggots use up more oxygen (faster), the distance the coloured water moves is further."]).
answer(number(12),part(c),subpart(i),[95,1	,"This means the woodlice take in more oxygen than the maggots.   
"]).
answer(number(12),part(c),subpart(i),[96,1	," The maggots use oxygen alot more quickly than woodlice "]).
answer(number(12),part(c),subpart(i),[97,0	,"The maggots take in oxygen much more slowly than the woodlice because the die moves slower."]).
answer(number(12),part(c),subpart(i),[98,1	,"The fly maggots moved the water along quicker than the woodlice."]).
answer(number(12),part(c),subpart(i),[99,1	,"The coloured water moved further in 10 mins with the maggots, than it did with the woodlice. "]).
answer(number(12),part(c),subpart(i),[100,1	,"With the maggots the coloured water is quicker"]).
answer(number(12),part(c),subpart(i),[101,0	,"It shows that they were breathimg more than the woodlice"]).
answer(number(12),part(c),subpart(i),[102,noanswer]).
answer(number(12),part(c),subpart(i),[103,noanswer]).
answer(number(12),part(c),subpart(i),[104,0	," They grow as fast has the wood lice does"]).
answer(number(12),part(c),subpart(i),[105,1	,"because every two minutes in the magots one it increases by 3 which the woodlice only increases by 2 "]).
answer(number(12),part(c),subpart(i),[106,1	,"The maggots use more oxygen than the woodlice."]).
answer(number(12),part(c),subpart(i),[107, 0	," The results with maggots: the distance the drop of coloured water moved in centimeters wasn't as far"]).
answer(number(12),part(c),subpart(i),[108,1	," The water moves closer to the shringe every 2 minutes"]).
answer(number(12),part(c),subpart(i),[109,0	," The maggots distance of coloured water moved in cm is different."]).
answer(number(12),part(c),subpart(i),[110,0	,"goes up in the minutes go lower"]).
answer(number(12),part(c),subpart(i),[111,0	," maggots will swim in the water"]).
answer(number(12),part(c),subpart(i),[112,noanswer]).
answer(number(12),part(c),subpart(i),[113,1	,"The maggots coloured water did travel faster than the woodlice."]).
answer(number(12),part(c),subpart(i),[114,noanswer]).
answer(number(12),part(c),subpart(i),[115,1	,"the coloured water moved faster with the maggots."]).
answer(number(12),part(c),subpart(i),[116,0	,"it's just higher"]).
answer(number(12),part(c),subpart(i),[117,1	," the couloured water moved more with the maggots."]).
answer(number(12),part(c),subpart(i),[118,1	," maggots use more oxygen."]).
answer(number(12),part(c),subpart(i),[119,0	," Magets have a cooler body temperature"]).
answer(number(12),part(c),subpart(i),[120,1	,"The water moves further towards the syringe in less time."]).
answer(number(12),part(c),subpart(i),[121,1	,"The maggots move the water along twice as fast as the woodlice"]).
answer(number(12),part(c),subpart(i),[122,1	,"The drop of coloured water moved along the tube. It traveled faster."]).
answer(number(12),part(c),subpart(i),[123,0	," The results don't match to the graph of the woodlice."]).
answer(number(12),part(c),subpart(i),[124,0	,"The results are quicker and has a pattern to them."]).
answer(number(12),part(c),subpart(i),[125,1	,"the maggot water moves faster"]).
answer(number(12),part(c),subpart(i),[126,0	,"the results of the woodlice is higher than the maggots"]).
answer(number(12),part(c),subpart(i),[127,1	,"The distance travelled is much quicker for the fly - same time but moved along faster"]).
answer(number(12),part(c),subpart(i),[128,1	,"Fly maggots use more oxygen as the coloured water moves forward quicker"]).
answer(number(12),part(c),subpart(i),[129,1	,"Maggots use more oxygen so their graph would have a steeper gradient"]).
answer(number(12),part(c),subpart(i),[130, 1	,"The coloured water moves closer to the syringe with the maggots."]).
answer(number(12),part(c),subpart(i),[131,0	,"The results are much different and are in a funny pattern"]).
answer(number(12),part(c),subpart(i),[132,0	,"the "]).
answer(number(12),part(c),subpart(i),[133,0	,"The go in two's."]).
answer(number(12),part(c),subpart(i),[134,1	,"The maggots result moves 1cm more each 2 minutes than the woodlice."]).
answer(number(12),part(c),subpart(i),[135,0	,"The magets went slower the woodlice went faster than the magets"]).
answer(number(12),part(c),subpart(i),[136,0	," The maggots distance increased than the woodlice"]).
answer(number(12),part(c),subpart(i),[137,noanswer]).
answer(number(12),part(c),subpart(i),[138,1	,"It moves 1 or 2 cm's more than woodlice."]).
answer(number(12),part(c),subpart(i),[139,0	,"Because the woodlice breathe more oxygen in"]).
answer(number(12),part(c),subpart(i),[140,noanswer]).
answer(number(12),part(c),subpart(i),[141,1	,"The water hasn't moved as far with the woodlice."]).
answer(number(12),part(c),subpart(i),[142,1	,"The maggat have more of a distance of coloured water moved in cm's every 2 minutes."]).
answer(number(12),part(c),subpart(i),[143,1	," the water from the maggots moves abit more than from the woodlice"]).
answer(number(12),part(c),subpart(i),[144,1	,"The coloured water moves much faster with the maggots than with the woodlice."]).
answer(number(12),part(c),subpart(i),[145,0	,"it takes longer for the magets to go throw"]).
answer(number(12),part(c),subpart(i),[146,noanswer]).
answer(number(12),part(c),subpart(i),[147,0	,"because fly maggots need carbon dioxide to fly."]).
answer(number(12),part(c),subpart(i),[148,0	," the maggot stay warmer for longer."]).
answer(number(12),part(c),subpart(i),[149,0	," Because the maggots fly"]).
answer(number(12),part(c),subpart(i),[150, 0	," the maggots test was quicker than the woodlice test"]).
answer(number(12),part(c),subpart(i),[151,0	," Woodlice use more oxygen."]).
answer(number(12),part(c),subpart(i),[152,0	," The maggots don't move as much as the woodlice did."]).
answer(number(12),part(c),subpart(i),[153, 0	," they must of had a high temp from the woodlice."]).
answer(number(12),part(c),subpart(i),[154, 1	," The coloured water travels further with the maggots."]).
answer(number(12),part(c),subpart(i),[155,1	," The fly maggots use more oxygen"]).
answer(number(12),part(c),subpart(i),[156,1	," they go higher"]).
answer(number(12),part(c),subpart(i),[157,1	," With the woodlice the water didn't move as far as what the fly maggots did."]).
answer(number(12),part(c),subpart(i),[158, 0	," because the maggots need more oxygen quicker than the woodlice"]).
answer(number(12),part(c),subpart(i),[159,1	," the woodlice dont use as much oxygen as maggots"]).
answer(number(12),part(c),subpart(i),[160,0	," Because fly maggots don't use oxygen."]).
answer(number(12),part(c),subpart(i),[161,1	," the fly maggots use more oxygen which make the results differant."]).
answer(number(12),part(c),subpart(i),[162, 1	,"The maggots use up more oxygen than the woodlice."]).
answer(number(12),part(c),subpart(i),[163,1	,"Water moved a lot quicker"]).
answer(number(12),part(c),subpart(i),[164,1	,"the longer the maggots are in there the farer the coloured water moved in cm. But woodlice were in they just a long as the maggots but the coloured water did not travl (illegible) "]).
answer(number(12),part(c),subpart(i),[165,1	,"The drop of water when maggots were used moved faster than when woodlice were used."]).
answer(number(12),part(c),subpart(i),[166,0	,"The maggots go more distance than the woodlice"]).
answer(number(12),part(c),subpart(i),[167, 1	,"In 10 minutes the coloured water moves closer, to the chemical."]).
answer(number(12),part(c),subpart(i),[168, 0	,"the maggots have better results."]).
answer(number(12),part(c),subpart(i),[169, 1	,"The fly maggots needed more oxygen and the woodlice didn't so the graph was higher."]).
answer(number(12),part(c),subpart(i),[170, 0	,"the fly maggots last longet without oxygen."]).
answer(number(12),part(c),subpart(i),[171,noanswer]).
answer(number(12),part(c),subpart(i),[172, 0	,"because the maggots don't need as much oxygen as the woodlice."]).
answer(number(12),part(c),subpart(i),[173,noanswer]).
answer(number(12),part(c),subpart(i),[174, 0	,"maggots used more air in the space of time."]).
answer(number(12),part(c),subpart(i),[175, 0	,"Because it is kept in sylinge."]).
answer(number(12),part(c),subpart(i),[176, 0	,"with the maggots the coloured water moves up every 3cm."]).
answer(number(12),part(c),subpart(i),[177, 0	,"because there less woodlice than flymaggots."]).
answer(number(12),part(c),subpart(i),[178, 1	,"they use more oxygen than the woodlice"]).
answer(number(12),part(c),subpart(i),[179, 1	,"The maggots use more oxygen in less time than the lice."]).

answer(number(12),part(c),subpart(i),[181, 1	,"The maggots would have a steeper slope on the graph"]).
answer(number(12),part(c),subpart(i),[182, 1	,"The fly maggets moved the coloured water further"]).
answer(number(12),part(c),subpart(i),[183,noanswer]).
answer(number(12),part(c),subpart(i),[184,noanswer]).
answer(number(12),part(c),subpart(i),[185,noanswer]).
answer(number(12),part(c),subpart(i),[186, 1	," The graident is steeper for the maggots."]).
answer(number(12),part(c),subpart(i),[187,noanswer]).
answer(number(12),part(c),subpart(i),[188, 1 ,"	The results differ because, the maggots, coloured water moved faster than the woodlice "]).
answer(number(12),part(c),subpart(i),[189, 1 ,"	It shows that maggots take in more oxygen than woodlice "]).
answer(number(12),part(c),subpart(i),[190, 0 ," The maggots produce more oxygen than the woodlice and at a quicker rate."]).
answer(number(12),part(c),subpart(i),[191, 0 ,"	the distance the drop of water travelled with the maggots id roughly half the distance travelled with the woodlice. "]).
answer(number(12),part(c),subpart(i),[192, 1	," The distance that the water moved was much greater "]).
answer(number(12),part(c),subpart(i),[193, 1 ,"	the drop of colour moved more rapidly with the fly maggots than the woodlice "]).
answer(number(12),part(c),subpart(i),[194,noanswer]).
answer(number(12),part(c),subpart(i),[195,noanswer]).
answer(number(12),part(c),subpart(i),[196, 0 ,"	The maggots results are different to the woodlice one because "]).
answer(number(12),part(c),subpart(i),[197, 0 ,"	distance the drop of coloured water moved in cm goes up in the 3 times table "]).
answer(number(12),part(c),subpart(i),[198, 1 ,"The drop of coloured water moves faster with the maggots "]).
answer(number(12),part(c),subpart(i),[199, 0	," It's just a bit smaller "]).
answer(number(12),part(c),subpart(i),[200,	1	," maggots experiment, water moves further "]).
answer(number(12),part(c),subpart(i),[201, 1 ,"the maggot moved further more up the tube than the woodlice did"]).
answer(number(12),part(c),subpart(i),[202, 1 ,"the coloured water moves quicker with the maggots"]).

