:- multifile answer/4.

answer(number(12),part(c),subpart(ii),[1,0	,"Woodlice where slower than the maggots. "]).
answer(number(12),part(c),subpart(ii),[2,0	,"Because the maggots used more air in the time space and the woodlice didn't take much air up. "]).
answer(number(12),part(c),subpart(ii),[3,0	,"Because the woodlice results the water moves slower than the fly maggots results. "]).
answer(number(12),part(c),subpart(ii),[4,2	,"Temperature effects the rate at which maggots move, in hot conditions they move quicker. The maggots used up more oxygen because they were moving and respiring at a faster rate than the woodlice. "]).
answer(number(12),part(c),subpart(ii),[5,0	,"Woodlice use oxygen, and as the cotton wool is absorbing so there is less of it, where as maggots are used to warm conditions and CO2 or oxygen doesn't bother them! "]).
answer(number(12),part(c),subpart(ii),[6,0	,"The fly maggots take in more oxygen than the woodlice. "]).
answer(number(12),part(c),subpart(ii),[7,1	,"the maggot uses more oxygen than the woodlice "]).
answer(number(12),part(c),subpart(ii),[8,1	,"The maggot has more body mass which mean's the is going faster. Also the maggot's body can expand more. "]).
answer(number(12),part(c),subpart(ii),[9,noanswer]).
answer(number(12),part(c),subpart(ii),[10,1	,"the fly maggots use oxygen fastie.      OR. Also the fly maggots could be using more.  "]).
answer(number(12),part(c),subpart(ii),[11,2	,"Because maggots move around a lot more and faster than woodlice do and so they respire and use more oxygen up "]).
answer(number(12),part(c),subpart(ii),[12,2	,"the 2 sets of results are different because the fly maggots use up more oxygen than the woodlice. "]).
answer(number(12),part(c),subpart(ii),[13,1	,"Because the maggots used more oxygen than the woodlice and they used more energy. "]).
answer(number(12),part(c),subpart(ii),[14,0	,"Woodlice don't need Co2 but the coloured water moves less quicker. "]).
answer(number(12),part(c),subpart(ii),[15,1	,"They are different because the woodlice are not using as much oxygen as the maggots are, the coloured water moves towards the syringe faster where the maggots are in the syringe. "]).
answer(number(12),part(c),subpart(ii),[16,1	,"the results are different because the fly maggots use more oxygen so the coloured water moves down quicker. "]).
answer(number(12),part(c),subpart(ii),[17,0	,"Because the maggots use up more oxygen than woodlice as they have produced anaerobic respiration. "]).
answer(number(12),part(c),subpart(ii),[18,0	,"Because the fly maggots need more oxygen. The experiment didn't say how many of each they put into the test tube which could also affect results. "]).
answer(number(12),part(c),subpart(ii),[19,0	,"The woodlice don't use as much oxygen and change the pase they use it. The fly maggots have a constant amount of oxygen. "]).
answer(number(12),part(c),subpart(ii),[20,1	,"The fly maggots made the distance of the drop of colour water moved much more than the woodlice did, which means the maggots used up more oxygen. "]).
answer(number(12),part(c),subpart(ii),[21,1	,"The maggots use up their oxygen quicker and there for are left with less oxygen than the woodlice. "]).
answer(number(12),part(c),subpart(ii),[22,1	,"The coloured drop for the fly maggots moved quicker because they used more oxygen. "]).
answer(number(12),part(c),subpart(ii),[23,0	,"Because the fly maggots take up a smaller surface area. "]).
answer(number(12),part(c),subpart(ii),[24,0	,"They use two different things (woodlice + maggots) so the results different as the woodlice need to use the oxygen up.  
 "]).
answer(number(12),part(c),subpart(ii),[25,1	,"because the fly maggots use up more oxygen than the woodlice so it makes the water move towards them quicker "]).
answer(number(12),part(c),subpart(ii),[26,0	,"because maggots dont use arerobic resparation "]).
answer(number(12),part(c),subpart(ii),[27,0	,"Because each insect uses a different amount of carbon dioxide "]).
answer(number(12),part(c),subpart(ii),[28,1	,"Fly maggots may have a smaller lung capacity which means that they have to absorb more oxygen as they are more active than the woodlouse. "]).
answer(number(12),part(c),subpart(ii),[29,1	,"They are 2 different animals maggots respirate more "]).
answer(number(12),part(c),subpart(ii),[30,1	,"there could have been more maggots than woodlice, more coloured water or less.  "]).
answer(number(12),part(c),subpart(ii),[31,0	,"They are 2 different creatures woodlice can't cope as well as fly maggots because woodlice are usually always covered up. "]).
answer(number(12),part(c),subpart(ii),[32,0	,"on is a line graph on it on the chart are the reading are diffrent "]).
answer(number(12),part(c),subpart(ii),[33,noanswer]).
answer(number(12),part(c),subpart(ii),[34,noanswer]).
answer(number(12),part(c),subpart(ii),[35,0	,"The sets of results are different because in one they use woodlice and in another they use maggots"]).
answer(number(12),part(c),subpart(ii),[36,0	,"as the 2 differ species respirate at different rates, so using up the oxygen at different rates "]).
answer(number(12),part(c),subpart(ii),[37,1	,"As they are different types of insects which require different amounts of oxygen. They are different sizes and shapes so the maggots may require a larger intake of oxygen"]).
answer(number(12),part(c),subpart(ii),[38,0	,"Different animals"]).
answer(number(12),part(c),subpart(ii),[39,0	,"It is probably different because of the numbers going up. (And probably because of the maggots don't last as long as woodlice)."]).
answer(number(12),part(c),subpart(ii),[40,2	,"They'se different because fly maggots need more oxygen than woodlice. Probably also because the fly maggots move faster than the woodlice so need more oxygen."]).
answer(number(12),part(c),subpart(ii),[41,2	,"because maggots move around a lot more than woodlice. This means that the rate of respiration will be higher, thus using up more oxygen."]).
answer(number(12),part(c),subpart(ii),[42,1	,"They are different because maggots live in water are bigger and move faster the woodlice."]).
answer(number(12),part(c),subpart(ii),[43,0	,"fly maggots are changing animals During this change and before this change they need more oxygen so they can change with less difficulties."]).
answer(number(12),part(c),subpart(ii),[44,0	,"because your used to kind's of different experiments. "]).
answer(number(12),part(c),subpart(ii),[45,0	,"Woodlice use's up oxygen and this makes it go closer to the sringe, maggots do not use up oxygen so it makes it faster to go near the syringe."]).
answer(number(12),part(c),subpart(ii),[46,noanswer]).
answer(number(12),part(c),subpart(ii),[47,0	,"Because the maggots and the woodlice took their time to move so the coloured water moved slower. according to the results"]).
answer(number(12),part(c),subpart(ii),[48,0	,"one experiment had a drop of coloured water moved and the other had all coloured water."]).
answer(number(12),part(c),subpart(ii),[49,2	,"Because maggots are bigger and they might have used up more oxygen than what the woodlice did."]).
answer(number(12),part(c),subpart(ii),[50,0	,"The two results are diffren because diffren animals don't always like the things the other one does."]).
answer(number(12),part(c),subpart(ii),[51,noanswer]).
answer(number(12),part(c),subpart(ii),[52,noanswer]).
answer(number(12),part(c),subpart(ii),[53,2	,"The fly maggots respirate quicker, so take in more oxygen than woodlice. There could have been more maggots than woodlice."]).
answer(number(12),part(c),subpart(ii),[54,noanswer]).
answer(number(12),part(c),subpart(ii),[55,noanswer]).
answer(number(12),part(c),subpart(ii),[56,noanswer]).
answer(number(12),part(c),subpart(ii),[57,0	,"Because woodlice do not take in a lot of oxygen each time, where as fly maggots take in a lot of oxygen."]).
answer(number(12),part(c),subpart(ii),[58,0	,"They are different because maggots dont use as much oxygen as the woodlice."]).
answer(number(12),part(c),subpart(ii),[59,noanswer]).
answer(number(12),part(c),subpart(ii),[60,noanswer]).
answer(number(12),part(c),subpart(ii),[61,0	,"either there are more maggots in the syringe than there are woodlice or the maggots were using up more air than the woodlice. "]).
answer(number(12),part(c),subpart(ii),[62,0	,"they are different as the woodlice did not use up oxygen as quickly as the maggots."]).
answer(number(12),part(c),subpart(ii),[63,	1	,"Because the two animals, woodlice and maggots, are completely different organisms and so are bound to respire at different rates. "]).
answer(number(12),part(c),subpart(ii),[64,noanswer]).
answer(number(12),part(c),subpart(ii),[65,1	,"maggots use far more oxygen than woodlice do because they are different species of animal. The distance the drop of coloured water moved in cm towards the syringe was a greater amount per minuit for the maggots case compared to the woodlice."]).
answer(number(12),part(c),subpart(ii),[66,0	,"This is because the substance absorbs carbon dioxide and the woodlice use all of the oxygen."]).
answer(number(12),part(c),subpart(ii),[67,1	,"Because the fly maggots use up more oxygen than the woodlice so the results were different"]).
answer(number(12),part(c),subpart(ii),[68,1	,"They are different because the 2 insects use up different amounts of oxygen. The maggots use more, so the coloured water moves further"]).
answer(number(12),part(c),subpart(ii),[69,0	,"because they have different cells and organs."]).
answer(number(12),part(c),subpart(ii),[70,0	,"The two sets are different because the fly maggots use oxygen quicker this is because they are younger than the woodlice so they take in more oxygen."]).
answer(number(12),part(c),subpart(ii),[71,0	,"As maggots use less oxygen it took the coloured water even longer to reach them "]).
answer(number(12),part(c),subpart(ii),[72,0	,"because they are tottaly different from each other"]).
answer(number(12),part(c),subpart(ii),[73,0	,"The results in cinda and kathleen experiments are different because they were using two different types of ingredients in each one."]).
answer(number(12),part(c),subpart(ii),[74,0	,"They are different because the woodlice takes up more so it takes less time for the colour water to move along. The maggots dont use 02 so it takes longer for the coloured water to move along."]).
answer(number(12),part(c),subpart(ii),[75,1	,"because the maggots ate up more oxygen than the woodlice, because they move around alot more using up more energy and needing more oxygen."]).
answer(number(12),part(c),subpart(ii),[76,1	,"They differ as the ink got to the cotton wool quicker with the maggots than it did with the woodlice"]).
answer(number(12),part(c),subpart(ii),[77,1	,"the maggots could be moving around more than the woodlice so they use more oxygen."]).
answer(number(12),part(c),subpart(ii),[78, 1	,"because the curve on the woodlice graph is not as steap as the one on the maggets graph"]).
answer(number(12),part(c),subpart(ii),[79, 1	,"The results are different because the woodlice are smaller and maggots are bigger to the woodlice."]).
answer(number(12),part(c),subpart(ii),[80, 0	,"because the maggots might be a bit lighter and it was not a fair test because the woodlice are not the same weight as the maggots."]).
answer(number(12),part(c),subpart(ii),[81,0	,"because they are different so each specie needs different amounts of oxygen."]).
answer(number(12),part(c),subpart(ii),[82,	1	,"maggots take in more oxygen so the coloured water will move along the, glass tube further then if woodlice were in there."]).
answer(number(12),part(c),subpart(ii),[83,noanswer]).
answer(number(12),part(c),subpart(ii),[84,1	,"The maggots move carbon dioxide, and less oxygen than the woodlice do. So their results become much higher, much more quickly. "]).
answer(number(12),part(c),subpart(ii),[85,1	,"because different animals use different amounts of oxygen to stay alive. Also the water moved up the syringe at the different points woodlice didn't move it as far as the fly maggots."]).
answer(number(12),part(c),subpart(ii),[86,0	,"because like maggots is different from woodlice so you are going to inspect different results and so they won't get the same results because two completely different insects"]).
answer(number(12),part(c),subpart(ii),[87,	1	,"Because maybe the different animals need different amounts of oxygen in the same time the maggots respire more."]).
answer(number(12),part(c),subpart(ii),[88, 1	,"The maggots use up more of the oxygen this means they breathe out more carbon dioxide making the water move a bigger distance."]).
answer(number(12),part(c),subpart(ii),[89,  1	,"They fly maggots have used up more oxygen because they breathed more oxygen in quicker, so the graph would be steeper.  "]).
answer(number(12),part(c),subpart(ii),[90,0	," Because the fly maggots maybe breath faster than the woodlouse  "]).
answer(number(12),part(c),subpart(ii),[91,1	," less water was droped for the woodlice than the maggots "]).
answer(number(12),part(c),subpart(ii),[92,2	," Fly maggots move along faster therefore taking in much more oxygen therefore making the water move faster along the tubes"]).
answer(number(12),part(c),subpart(ii),[93,1	,"The flymaggots had used more oxygen than the woodlice"]).
answer(number(12),part(c),subpart(ii),[94,1	,"because the animals are different maggots can use up oxygen faster and survive without it. They respire at different rates."]).
answer(number(12),part(c),subpart(ii),[95,1	,"because the insects can be different sizes and so they take up different amounts of oxygen in the body."]).
answer(number(12),part(c),subpart(ii),[96,0	," Because they are different types of creatures so they use different amounts of oxygen "]).
answer(number(12),part(c),subpart(ii),[97,0	,"The maggots and woodlice are different sizes and the woodlice had alot of water but the maggots only had a drop of water."]).
answer(number(12),part(c),subpart(ii),[98,1	,"the fly maggots respire quicker than the woodlice, therefore the water moved quicker, than it did with the woodlice.  
"]).
answer(number(12),part(c),subpart(ii),[99,1	,"The results are different because the maggots use much more oxygen than the woodlice!!"]).
answer(number(12),part(c),subpart(ii),[100,1	," Because the maggots take in alot more oxygen than woodlice do. Therefore oxygen is exchanged for Co2 which is absorbed quicker, making the colour move quicker. Maggots respire more "]).
answer(number(12),part(c),subpart(ii),[101,1	,"The fly maggot was breathing more than the woodlice did so the coloured water moved more up the tube. "]).
answer(number(12),part(c),subpart(ii),[102,noanswer]).
answer(number(12),part(c),subpart(ii),[103,noanswer]).
answer(number(12),part(c),subpart(ii),[104,noanswer]).
answer(number(12),part(c),subpart(ii),[105,0	,"Because these don't use oxygen and they are smaller living things. "]).
answer(number(12),part(c),subpart(ii),[106,1	," Maggots need to take in more oxygen than woodlice as they are bigger and so need more oxygen to go around there body."]).
answer(number(12),part(c),subpart(ii),[107,0	," The fly maggots are smaller than the woodlice, so they don't need to take in as much oxygen."]).
answer(number(12),part(c),subpart(ii),[108,2	," Because the maggots might breath in more oxygen, which means the drop of water is moving closer to the syringe, and the carbon dioxide which they are breathing out, is absorbed by the chemical"]).
answer(number(12),part(c),subpart(ii),[109,0	," Because they are 2 different insects and because the maggots have no legs. And because it takes them longer to move."]).
answer(number(12),part(c),subpart(ii),[110,0	," Because might have change the water And room temp might have some up or down"]).
answer(number(12),part(c),subpart(ii),[111,0	," because both diffrent things all diffrent produce that they cannot live the same thing"]).
answer(number(12),part(c),subpart(ii),[112,noanswer]).
answer(number(12),part(c),subpart(ii),[113,2	,"The two sets of results are different because the woodlices take up less oxygen then the maggots. The maggots take alot more oxygen."]).
answer(number(12),part(c),subpart(ii),[114,noanswer]).
answer(number(12),part(c),subpart(ii),[115,0	,"Because the maggots could fly and push the water along and the woodlice crawl."]).
answer(number(12),part(c),subpart(ii),[116,0	,"Ones higher"]).
answer(number(12),part(c),subpart(ii),[117, 1	,"The two differant anamals must need difrant oxygen levels, the maggots use more oxygen and the woodlice use less oxygen and so the results are different"]).
answer(number(12),part(c),subpart(ii),[118,0	," they are different at every time recorded, the maggots have used more air so the more time for the maggots the more air. maggots air increase by 0.1cm every two minutes compared with woodlice."]).
answer(number(12),part(c),subpart(ii),[119,0	," Magets would die first as they body temperature is cooler "]).
answer(number(12),part(c),subpart(ii),[120,1	,"The results are different because fly maggots use up more oxygen than woodlice and so produce more carbon dioxide."]).
answer(number(12),part(c),subpart(ii),[121, 2	,"Maggots are bigger and use up more oxygen therefore the water moves along faster."]).
answer(number(12),part(c),subpart(ii),[122, 0	," because they are different types of creatures. They use different amounts of carbon dioxide."]).
answer(number(12),part(c),subpart(ii),[123,2	," The woodlice are smaller so they don't need as much oxygen as the maggots do so the maggots use up all of the oxygen supply so the die much faster."]).
answer(number(12),part(c),subpart(ii),[124,0	,"Because woodlice use oxygen which makes the coloured water move toward the syringe."]).
answer(number(12),part(c),subpart(ii),[125,0	,"the maggots breath in more Air than woodlice"]).
answer(number(12),part(c),subpart(ii),[126,0	," Woodlice take up more oxygen than the maggots do "]).
answer(number(12),part(c),subpart(ii),[127,1	,"Because maybe the fly maggots can breathe better in those conditions which absorbs more Co2 & moves the water quicker and the wood lice cant. - There different species "]).
answer(number(12),part(c),subpart(ii),[128,2	," Because they are two different sorts of insect and maggots use more energy and move around more "]).
answer(number(12),part(c),subpart(ii),[129, 2	," Maggots use more energy therefore they need more oxygen than the woodlice."]).
answer(number(12),part(c),subpart(ii),[130,0	,"The results are different because the maggots use more air than the woodlice so the coloured water moves closer to the syringe."]).
answer(number(12),part(c),subpart(ii),[131,0	,"They are different because they've been tested, on 2 different insect's which are woodlice and maggots. "]).
answer(number(12),part(c),subpart(ii),[132,0	,"The two sets of results are different because the woodlice moves faster than the maggots."]).
answer(number(12),part(c),subpart(ii),[133,0	,"Maggots are more slower."]).
answer(number(12),part(c),subpart(ii),[134,0	,"Because the fly maggots dont use up much oxygen"]).
answer(number(12),part(c),subpart(ii),[135,0	," magets are small and travel slowly the woolice are not slimy and they even travel more faster than the small little slimy magets"]).
answer(number(12),part(c),subpart(ii),[136, 0	,"because they want to keep the experiment fair.  
"]).
answer(number(12),part(c),subpart(ii),[137,0 ,"	Because the graph one multiply in one and the table one multiply in 3s"]).
answer(number(12),part(c),subpart(ii),[138,0	,"The two sets of results are different because both of the things are different and they move in different distances from each other.  
"]).
answer(number(12),part(c),subpart(ii),[139,2	,"Woodlice a bigger and last longer than maggots, they eat and need oxygen more than maggots"]).
answer(number(12),part(c),subpart(ii),[140,noanswer]).
answer(number(12),part(c),subpart(ii),[141,1	,"Because the woodlice use less oxygen than the fly maggots so the water doesn't move as far along the tube."]).
answer(number(12),part(c),subpart(ii),[142,0	," Maggats dont use as much oxygen to start the process off."]).
answer(number(12),part(c),subpart(ii),[143,noanswer]).
answer(number(12),part(c),subpart(ii),[144,0	,"The woodlice use oxygen and the maggots don't use the same amount of oxygen that the woodlice do. Maggots use less."]).
answer(number(12),part(c),subpart(ii),[145,noanswer]).
answer(number(12),part(c),subpart(ii),[146,noanswer]).
answer(number(12),part(c),subpart(ii),[147,0	," The results are different because fly maggots need air to fly and woodlice don't need as much air because they walk"]).
answer(number(12),part(c),subpart(ii),[148,0	," because the woodlice and the maggots are different"]).
answer(number(12),part(c),subpart(ii),[149,0	," Because they are both different creatures."]).
answer(number(12),part(c),subpart(ii),[150,noanswer]).
answer(number(12),part(c),subpart(ii),[151,0	," because woodlice use alot more oxygen than magents."]).
answer(number(12),part(c),subpart(ii),[152,0	," The two sets of results are different because the maggots are a different species of insect to the woodlice and the woodlice are more active than the maggots are."]).
answer(number(12),part(c),subpart(ii),[153, 0	," Maggots are a complete different thing then woodlice"]).
answer(number(12),part(c),subpart(ii),[154,2	," The two sets of results are different because fly maggots use up more oxygen than woodlice so therefore the coloured water travels further with the fly maggots in the syringe"]).
answer(number(12),part(c),subpart(ii),[155,1	," The fly maggots use more oxygen therefore die / starve quicker. The coloured water moves more in the fly maggots than the woodlice. "]).
answer(number(12),part(c),subpart(ii),[156,0	," because the woodlice take in more oxygen than the maggots"]).
answer(number(12),part(c),subpart(ii),[157,0	," They are different because fly maggots are much lighter than woodlice so they would move more cm's "]).
answer(number(12),part(c),subpart(ii),[158, 2	,"because the maggots need more oxygen quicker than the woodlice that is why the coloured water move's quicker than the woodlice coloured water."]).
answer(number(12),part(c),subpart(ii),[159,0	,"Because the experiment is done with two diffrent living thing and there is a change of body mass"]).
answer(number(12),part(c),subpart(ii),[160,0	," Because they are two different kind of insects, so they will be a different reaction."]).
answer(number(12),part(c),subpart(ii),[161,0	," the two setts of results are differant because the maggots and woodlice are differant and breath differant amount of oxygen.  
"]).
answer(number(12),part(c),subpart(ii),[162,0	,"The maggots started to use the oxygen more quicker at the start of the experiment than the woodlice so they ended up useing more altogether at the end."]).
answer(number(12),part(c),subpart(ii),[163,1	,"This is because the maggots need more oxygen than the woodlice to keep alive."]).
answer(number(12),part(c),subpart(ii),[164, 1	,"because the flying maggots are useing more air up make the water tarvel a long diste but woodlice just walke around and the coloured water did not tarvel as far."]).
answer(number(12),part(c),subpart(ii),[165,2	,"These results are different because the maggots used more oxygen and in a faster time than the woodlice did. Also fly maggots are more active so need more oxygen to move."]).
answer(number(12),part(c),subpart(ii),[166,0	,"Because the woodlice use up more oxygen so they would go slower and the maggots don't need as much oxygen"]).
answer(number(12),part(c),subpart(ii),[167,2	,"because the maggots produce more carbon dioxide so the chemical pulls the coloured water closer each time it absorbs the carbon dioxide the maggots produce."]).
answer(number(12),part(c),subpart(ii),[168,0	,"Because maggots are not drged out like woodlice."]).
answer(number(12),part(c),subpart(ii),[169, 1	,"The fly maggots respired quicker than the woodlice. This may be because the fly magots are smaller and reqire more energy to respire because of their size."]).
answer(number(12),part(c),subpart(ii),[170,1	,"  
Woodlice are bigger so they use more oxygen"]).
answer(number(12),part(c),subpart(ii),[171,0	,"They have done two expemce on the woodlice"]).
answer(number(12),part(c),subpart(ii),[172,0	,"Because the are different types of animals so there for have different needs like the maggots don't need as much oxygen as the woodlice."]).
answer(number(12),part(c),subpart(ii),[173,noanswer]).
answer(number(12),part(c),subpart(ii),[174,1,"maggots might be bigger than the woodlice"]).
answer(number(12),part(c),subpart(ii),[175, 0	,"because it is different time of minutes"]).
answer(number(12),part(c),subpart(ii),[176, 1	,"because woodlice is much lighter in weight than the fly maggots."]).
answer(number(12),part(c),subpart(ii),[177, 0	,"Because 1 is for woodlice and I is for maggots"]).
answer(number(12),part(c),subpart(ii),[178, 0	,"because they used two different insects"]).
answer(number(12),part(c),subpart(ii),[179, 0	,"The maggots use more oxygen in less time than the woodlice."]).
%answer(number(12),part(c),subpart(ii),[180,]).
answer(number(12),part(c),subpart(ii),[181, 1	,"The maggots use more oxygen than the woodlice"]).
answer(number(12),part(c),subpart(ii),[182, 2	,"Because the fly maggets used more oxygen than the woodlice. Which means they preform aerobic respiration faster."]).
answer(number(12),part(c),subpart(ii),[183, 0	,"The two sets of results one different because 1 is about distance the drop of coloured water and the other is about distance coloured water moved.  
"]).
answer(number(12),part(c),subpart(ii),[184,noanswer]).
answer(number(12),part(c),subpart(ii),[185,noanswer]).
answer(number(12),part(c),subpart(ii),[186, 1	,"  
Because the maggots use up the oxygen quicker. Also the maggots breathe out more carbon dioxide. "]).
answer(number(12),part(c),subpart(ii),[187,noanswer]).
answer(number(12),part(c),subpart(ii),[188, 1 ,"	the maggots use oxygen quicker than the woodlice, the quicker & faster the oxygen was the faster the coloured water moved ! "]).
answer(number(12),part(c),subpart(ii),[189, 0 ,"	Because it shows you how much oxygen maggots breathe in and how much oxygen woodlice breathe in. There results are different because one Animal must of taken more oxygen than the other. "]).
answer(number(12),part(c),subpart(ii),[190,	1	," because maggots respite quicker than woodlice there for creating more carbon dioxide.   
"]).
answer(number(12),part(c),subpart(ii),[191, 0 ,"	The two sets of results differ because the maggots don't use as much oxygen as the woodlice do, therefore the water doesn't travel as far down the tubing. "]).
answer(number(12),part(c),subpart(ii),[192,	1 ,"	They were different because the amount of oxygen used and the amount of carbon dioxide used was different between the woodlice and the maggots "]).
answer(number(12),part(c),subpart(ii),[193, 1 ,"	The fly maggots use more oxygen than the woodlice therefore they give off more carbon dioxide "]).
answer(number(12),part(c),subpart(ii),[194,noanswer]).
answer(number(12),part(c),subpart(ii),[195,noanswer]).
answer(number(12),part(c),subpart(ii),[196,noanswer]).
answer(number(12),part(c),subpart(ii),[197, 0 ,"	the distance coloured water moves in cm on the woodlice chart goes up in the 2 times table and the fly maggots go up in the 3 times table "]).
answer(number(12),part(c),subpart(ii),[198, 1	," The maggots need more oxygen than the woodlice for respiration so the coloured water gets nearer to the syringe quicker "]).
answer(number(12),part(c),subpart(ii),[199,	0 ,"	check offer the results again "]).
answer(number(12),part(c),subpart(ii),[200, 0	," Because each creature has different jenes meaning they'll be a difference in movement  "]).
answer(number(12),part(c),subpart(ii),[201, 0 ,"   
The two sets of results are different because the woodlice use oxygen whereas the fly maggots don't therefore that affected the results and made them different  
 "]).
answer(number(12),part(c),subpart(ii),[202, 1 ,"   
the maggots use more oxygen than the woodlice: makes the coloured water move more quickly  
 "]).
