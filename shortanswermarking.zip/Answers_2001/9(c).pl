:- multifile answer/4.

answer(number(9),part(c),subpart(0),[1,0	,"You can detect it in a vain because the hart pumps faster "]).
answer(number(9),part(c),subpart(0),[2,1	,"You can detect the pulse on the wrist. It is caused by the heart pumping blood round your body by doing exercise for example "]).
%answer(number(9),part(c),subpart(0),[3,2	,"You can detect the pulse in your rist. It's caused by how fast your hearts beating "]).
answer(number(9),part(c),subpart(0),[3,2	,"You can detect the pulse in your wrist. It's caused by how fast your hearts beating "]).
answer(number(9),part(c),subpart(0),[4,2	,"You can detect the pulse in the wrist and neck and it is caused by the pulses from our heart. "]).
answer(number(9),part(c),subpart(0),[5,1	,"you could detect a pulse on your neck, back of your ear, your thumb, or your wrist. It is here you'r heart beats faster and blood is pumping around your body quicker, therefore you breath faster. "]).
answer(number(9),part(c),subpart(0),[6,1	,"You could detect your pulse on your wrist or on your chest. When you excersice your heart needs to work faster. "]).
answer(number(9),part(c),subpart(0),[7,2	,"you can detect the pulse in the wrist the reason for this is because you are working your heart so hard and fast it sends pulses around your body "]).
answer(number(9),part(c),subpart(0),[8,0	,"A suden burst of exercise caused the high pulse rate. "]).
%answer(number(9),part(c),subpart(0),[9,1	,"you could detect the pulse on your rist "]).
answer(number(9),part(c),subpart(0),[9,1	,"you could detect the pulse on your wrist "]).
answer(number(9),part(c),subpart(0),[10,1	,"you could detect your pulse on your inside because this is where your pressure point is. "]).
answer(number(9),part(c),subpart(0),[11,1	,"You would detect the pulse in your wrist it is caused when the blood pumps blood around the body. "]).
answer(number(9),part(c),subpart(0),[12,1	,"You could detect a pulse on your wrist the faster the pulse the easier it is to find because if you are using alot of energy the heart etc has to work quicker to get oxygen around the body. "]).
answer(number(9),part(c),subpart(0),[13,1	,"Your neck and your wrist "]).
answer(number(9),part(c),subpart(0),[14,0	,"everytime the it decreases you can detect the pulse, this is because exercise speeds up exercise so after the body slow goes back to normal. "]).
answer(number(9),part(c),subpart(0),[15,2	,"You could detect the pulse on your wrist, it is caused by fast heart beats when you have done a activity which has taken some energy. "]).
%answer(number(9),part(c),subpart(0),[16,2	,"You can detect your pulse at your wrist or knack, your heat beat causes it by pumping blood "]).
answer(number(9),part(c),subpart(0),[16,2	,"You can detect your pulse at your wrist or knack, your heart beat causes it by pumping blood "]).
answer(number(9),part(c),subpart(0),[17,1	,"You can detect your pulse on the neck and on your wrist. Here you can feel the blood being pumped through the artery or vein. "]).
answer(number(9),part(c),subpart(0),[18,1	,"Your wrist or your neck. A pulse is caused by a muscle which pumps the blood around the body at these points you can feel the muscle that helps the heart pump the blood. "]).
answer(number(9),part(c),subpart(0),[19,2	,"The heart beat causes it and you can detect it in your left wrist. "]).
answer(number(9),part(c),subpart(0),[20,2	,"Your pulse is in your wrist or your neck and is caused by the heart pumping blood around the body. "]).
answer(number(9),part(c),subpart(0),[21,2	,"You could detect the pulse on the wrist using your first two fingers. It is caused by the heart beating faster and trying to pump blood quicker around the body. "]).
answer(number(9),part(c),subpart(0),[22,1	,"Exercise causes the pulse rate to increase, and it can be detected on the underside of your wrist. "]).
%answer(number(9),part(c),subpart(0),[23,1	,"On the rist "]).
answer(number(9),part(c),subpart(0),[23,1	,"On the wrist "]).
answer(number(9),part(c),subpart(0),[24,noanswer]).
answer(number(9),part(c),subpart(0),[25,1	,"you could detect the pulse at the wrist. The pulse is blood- oxygenated blood around the body - you can feel it in the veins. "]).
answer(number(9),part(c),subpart(0),[26,1	,"Your wrist. its the blood going through your veins  "]).
answer(number(9),part(c),subpart(0),[27,1	,"U could detect your pulse on your neck below your ear's. the need for oxygen means your artery's and heart pump faster.  "]).
answer(number(9),part(c),subpart(0),[28,1	,"In your wrist. It is caused by the body pumping blood around your veins, in accordance with your levels of activity.  "]).
answer(number(9),part(c),subpart(0),[29,1	,"You can detect the pulse at the wrist. It is caused by the blood flow.  "]).
answer(number(9),part(c),subpart(0),[30,1	,"on your neck, blood being pumped around your body  "]).
answer(number(9),part(c),subpart(0),[31,0	,"Exercise causes it to beat faster. "]).
%answer(number(9),part(c),subpart(0),[32,1	,"pulse rate is found in you neak, whrist, this casase it if you ran to fast and you are out of breath. "]).
answer(number(9),part(c),subpart(0),[32,1	,"pulse rate is found in you neak, wrist, this casase it if you ran to fast and you are out of breath. "]).
answer(number(9),part(c),subpart(0),[33,2	,"You could detect your pulse either on inner part of wrist and on neck and when exercising body temp rises and heart beats faster to pump blood around faster which makes you sweat and sweat then cools you down. "]).
answer(number(9),part(c),subpart(0),[34,noanswer]).
answer(number(9),part(c),subpart(0),[35,2	,"You could detect the pulse on your wrist and it is caused by the heart pumping blood faster than it normally would. "]).
answer(number(9),part(c),subpart(0),[36,2	,"yor neck, the heart pumping blood in the brain"]).
answer(number(9),part(c),subpart(0),[37,2	,"You could detect the impule on your wrist following the side and angle of the thumb / on your neck. it is caused by the heart beating faster so more blood is flowing faster through your body. "]).
answer(number(9),part(c),subpart(0),[38,0	,"you could detect the pulse at 2 because doing more exercise is putting the pulse rate up."]).
answer(number(9),part(c),subpart(0),[39,0	,"If you do exercise the pulse will get faster and faster until you stop and then it slows down."]).
answer(number(9),part(c),subpart(0),[40,2	,"You can detect the pulse above your wrist. It tells you how beats per minute your heart is beating. So beats of the heart pumping the blood are causing."]).
answer(number(9),part(c),subpart(0),[41,1	,"On a vein in your wrist. It is caused by the speed of blood being pumped around your body by your heart."]).
answer(number(9),part(c),subpart(0),[42,1	,"You could detect your pulse in your wrist and your neck. It is made by the heart to show you are alive."]).
answer(number(9),part(c),subpart(0),[43, 2	,"You can find your pulse in your neck or your arm. When you exercise you breath faster so your heart and pulse have to move with your breathing in order for you to stay alive."]).
answer(number(9),part(c),subpart(0),[44,1	,"Your heart beat causes it rate's."]).
answer(number(9),part(c),subpart(0),[45,0	,"She was out of breath, she was taking up more oxygen than usual, she could detect it on how fast her heart was beating."]).
%answer(number(9),part(c),subpart(0),[46,1	,"by holding the rist"]).
answer(number(9),part(c),subpart(0),[46,1	,"by holding the wrist"]).
answer(number(9),part(c),subpart(0),[47,2	,"On the wrist just under the thumb the heart causes it as it pumps, it makes a pulse, or on your neck under you ear"]).
answer(number(9),part(c),subpart(0),[48,0	,"after 8 minutes her heart started to beat slower and slower ther exercise must had gone slower."]).
answer(number(9),part(c),subpart(0),[49,0	,"You could detect it because it went to a straighter line at the end, this is because the rate of her breathing went black to nomal"]).
answer(number(9),part(c),subpart(0),[50,1	,"th pouls is in th wrist and when she done exesize her puls rate went up."]).
answer(number(9),part(c),subpart(0),[51,1	,"you can detect it in your neck or arm it can be corsed by running to fast or something scared of you"]).
answer(number(9),part(c),subpart(0),[52,noanswer]).
answer(number(9),part(c),subpart(0),[53,2	,"The wrists and neck, because there is a large artery near the surface of the skin that pumps blood around the body."]).
answer(number(9),part(c),subpart(0),[54,noanswer]).
answer(number(9),part(c),subpart(0),[55,noanswer]).
answer(number(9),part(c),subpart(0),[56,1	,"the neck, rist Blood vesles. "]).
answer(number(9),part(c),subpart(0),[57,1	,"You can detect the pulse on your wrist or on your neck. It is caused by the the amount of oxygen takes in. If you breath heavily your pulse will be high.	"]).
answer(number(9),part(c),subpart(0),[58,1	,"In the wrist because it has a vain which has blood pumping around the body."]).
answer(number(9),part(c),subpart(0),[59,0	,"Neck because your heart is sending blood to your brain constantly."]).
answer(number(9),part(c),subpart(0),[60,0	,"115 the exercise she just did"]).
answer(number(9),part(c),subpart(0),[61,1	,"you can detect the pulse on your wrist and it is caused by blood being pumped around the body."]).
answer(number(9),part(c),subpart(0),[62,1	,"you can detect it on the inside of your wrist and it is caused by the vein pumping the blood round your body, as it pumps your heart bat the the vibration of it through your skin"]).
answer(number(9),part(c),subpart(0),[63, 2	,"You can detect the pulse at the neck (at the side of the wind pipe), in your thumb and on your wrist. It is caused by the blood being pumped around your body by your heart. "]).
answer(number(9),part(c),subpart(0),[64,	1	,"On your neck or your wrist, exersize cause the increase of your pulse rate "]).
answer(number(9),part(c),subpart(0),[65,1	,"two fingers on one of the wrists because the blood is beeing pumped through the veins so the pulse can be detected. "]).
answer(number(9),part(c),subpart(0),[66,2	,"You can detect the pulse at your wrist and it is caused by the heart pumping blood around your body."]).
answer(number(9),part(c),subpart(0),[67,2	,"You can detet the pulse by putting your finger tips on your wrist this is caused by the blood pumping faster round your body."]).
answer(number(9),part(c),subpart(0),[68,1	,"You could detect it at either her wrist or her neck. It is caused by the pumping of the blood. This happens in the veins."]).
answer(number(9),part(c),subpart(0),[69,1	,"the blood pumping around your body causes it. You can detect it from your heart, neck or your rist."]).
answer(number(9),part(c),subpart(0),[70,2	,"You could detect it in your wrist or neck. The heart pumping blood through veins is what causes it."]).
answer(number(9),part(c),subpart(0),[71,1	,"detect pulse on your wrist becauses it is near your vain"]).
answer(number(9),part(c),subpart(0),[72,0	,"Sometimes running anything what you"]).
answer(number(9),part(c),subpart(0),[73,1	,"You can detect your pulse in your neck or you could detect it in the underside of your wrist. You viens crossing cause you do feel your pulse rate."]).
answer(number(9),part(c),subpart(0),[74,1	,"Detect the pulse in her wrist. As you exercise harder blood is being pumped round the body more. Your pulse will get faster using because it's going more oxygen up."]).
answer(number(9),part(c),subpart(0),[75,2	,"in the neck, it is caused because the heart has to pump more blood quicker, and you can feel the blood squising through the vessels."]).
answer(number(9),part(c),subpart(0),[76,1	,"You can detect the pulse in the neck as the neck is close to your heart and the beat vibrates up to the neck."]).
answer(number(9),part(c),subpart(0),[77,1	,"you can detect a pulse on your wrist and it is caused by the blood being pumped around your body."]).
%answer(number(9),part(c),subpart(0),[78, 2	,"you can ditect your pulse in your rist and is caused by the heart when it pumps the blood around your body"]).
answer(number(9),part(c),subpart(0),[78, 2	,"you can ditect your pulse in your wrist and is caused by the heart when it pumps the blood around your body"]).
answer(number(9),part(c),subpart(0),[79,0	,"Jane may of bin breathing heaver at the last time it was taken "]).
answer(number(9),part(c),subpart(0),[80, 1	,"your heart beat causes the pulse and you could detect it by putting it by your heart."]).
answer(number(9),part(c),subpart(0),[81,	2	,"you can detect the pulse in the right part of your wrist. The pulse is caused by the amount of times your heart pumps."]).
answer(number(9),part(c),subpart(0),[82,	2	,"you can detect your pulse in your wrist, its caused by the heart pumping blood through the main arteries like in your wrist."]).
answer(number(9),part(c),subpart(0),[83,noanswer]).
answer(number(9),part(c),subpart(0),[84,2	,"You can detect the pulse one the wrist it is caused by the beating of the heart at the rate the blood is pumped through the heart."]).
answer(number(9),part(c),subpart(0),[85,2	,"you could detect the pulse on the side of your neck, the heart causes it to beat so many times, and also it the heart pumps blood around the body."]).
answer(number(9),part(c),subpart(0),[86,1	,"you could detect the pulse on your chest your neck or your wrist when you've been running around so much your pulse rate goes up."]).
answer(number(9),part(c),subpart(0),[87,2	,"You could get your pulse from you wrist underneath it - it is cause by the heart beat which travel down."]).
answer(number(9),part(c),subpart(0),[88,	2	,"You can detect the pulse on your wrist, when do exercise (vigourous) your heart pumps blood around the body faster. "]).
answer(number(9),part(c),subpart(0),[89,	2	,"You could detect your pulse on your arm (wrist) and on your neck, on top of the arteries, when they pump the blood through at high pressure."]).
answer(number(9),part(c),subpart(0),[90,1	," On your arm or neck your heart causes it when it is pumping blood.  
"]).
answer(number(9),part(c),subpart(0),[91,0	," around 2 minutes because it dropped quickly from 115 to 99 "]).
answer(number(9),part(c),subpart(0),[92,2	," The rist or the neck it is cause by high pressure in the ateries from the heart pumping blood around the body for respiration "]).
answer(number(9),part(c),subpart(0),[93,1	,"You can detect the pulse in the neck and in the rist it caused by blood pumping round the body. "]).
answer(number(9),part(c),subpart(0),[94,1	," you could detect the pulse in the wrist it is caused by blood pumping blood around the body at a faster rate than normal causing the heart and pulse to beat at a faster rate than normal. Blood is pumping faster, because of the exercise."]).
answer(number(9),part(c),subpart(0),[95,1	,"you can detect the pulse by putting your fingers on the neck or wrist and the veins cause this because they are the main veins that carry blood around the body. The heart pumps the blood at a certain rhythm."]).
answer(number(9),part(c),subpart(0),[96,0 ,"	0 minutes and non - stop exercise "]).
answer(number(9),part(c),subpart(0),[97,1	,"You can feel your pulse in your wrist or your neck. "]).
answer(number(9),part(c),subpart(0),[98,2	,"You can detect pulses on your wrist, temple (side of the forehead), heart. This is caused by the heart contracting to move the blood along, it is done mainly by the ventricles."]).
answer(number(9),part(c),subpart(0),[99,1	,"You could detect the pulse on the underside of your wrist, the blood pumping allows you too feel your pulse."]).
answer(number(9),part(c),subpart(0),[100, 2	,"The exercise increases the heartrate & blood being pumped around the body & therefore this increases your pulse."]).
answer(number(9),part(c),subpart(0),[101,1	,"In the wrist as it is the blood being pumped around the body from the heart  
"]).
%answer(number(9),part(c),subpart(0),[102,1	,"in your rist and it is caused by blood circulating faster "]).
answer(number(9),part(c),subpart(0),[102,1	,"in your wrist and it is caused by blood circulating faster "]).
answer(number(9),part(c),subpart(0),[103,2	," On you wrist when your out running or whatever your heart start beating fast  "]).
answer(number(9),part(c),subpart(0),[104,noanswer]).
answer(number(9),part(c),subpart(0),[105,1	,"it was a lack of exercise which caused this and and you can detect the pulse rate from the back of you arm near your hand and it is a vein you have to feel."]).
answer(number(9),part(c),subpart(0),[106,1	,"You can detect the pulse in your neck or wrist and it is caused by the arterys"]).
answer(number(9),part(c),subpart(0),[107, 2	,"In the wrist or in the neck it is caused by the heart beating and pumping blood around the body."]).
%answer(number(9),part(c),subpart(0),[108,1	," You can detect the pulse in the back of you rist by putting two fingers on it. And lack of oxygen when exercising cause your pulse rate to rise."]).
answer(number(9),part(c),subpart(0),[108,1	," You can detect the pulse in the back of you wrist by putting two fingers on it. And lack of oxygen when exercising cause your pulse rate to rise."]).
answer(number(9),part(c),subpart(0),[109,2	," In the bottom part of the jaw next to the wind pipe. The hearts beat is what causes it."]).
answer(number(9),part(c),subpart(0),[110,2	," Just in front of your hand or on your neck your heart go faster"]).
answer(number(9),part(c),subpart(0),[111,0	," at the start when they were decreasing all the time."]).
%answer(number(9),part(c),subpart(0),[112,1	,"rist - caused by exercise."]).
answer(number(9),part(c),subpart(0),[112,1	,"wrist - caused by exercise."]).
answer(number(9),part(c),subpart(0),[113,1	,"On the wrist or the neck and your heart rate causes it."]).
answer(number(9),part(c),subpart(0),[114,0	,"relaxing and reast"]).
answer(number(9),part(c),subpart(0),[115,2	," you can detect a pulse in your wrist or neck, your pulse starts to beat quicker when you do exercise because you are tyring your body out and your blood pumps around a lot faster"]).
answer(number(9),part(c),subpart(0),[116,0	,"after 4 min"]).
answer(number(9),part(c),subpart(0),[117,1	," Under the chin, the neck near the adams apple, because there is a blood vecel there."]).
answer(number(9),part(c),subpart(0),[118,1	," on the under-side of the wrist, as the blood is pumped round the body, you can feel it."]).
answer(number(9),part(c),subpart(0),[119,0	," When she started the exercises her puls rate was high but when she got into her puls rate dropped."]).
answer(number(9),part(c),subpart(0),[120,1	,"You could detect the pulse on the inside of your wrist, on your neck. The cause of your pulse is the blood as it gets pumped around your body"]).
answer(number(9),part(c),subpart(0),[121, 1	,"You can detect the pulse in your neck and it is caused by impulses sent round the body"]).
answer(number(9),part(c),subpart(0),[122,1	,"You can detect yor pulse in your neck and in your wrist. The flow of blood."]).
answer(number(9),part(c),subpart(0),[123,0	,"You can detect your pulse on your chest because your heart start beating faster and pumps blood through your body alot faster"]).
answer(number(9),part(c),subpart(0),[124,2	," You can detect the pulse on your wrists it's from the heart beats travelling round the body when exercise is done."]).
answer(number(9),part(c),subpart(0),[125,0	,"blood gets pumped around the body which makes it faster"]).
answer(number(9),part(c),subpart(0),[126,1	," On the wrist this is caused by blood being pumped rapidly around the body through the veins."]).
answer(number(9),part(c),subpart(0),[127,1	," You have to press down on your veins either in your neck or wrist. You have a pulse rate to see how fast your breathing and if its regular or iregular breathing"]).
answer(number(9),part(c),subpart(0),[128,2	,"You can detect your pulse in your neck and wrist, it is caused by the heart beating to push blood and oxygen around your body (means your alive)"]).
answer(number(9),part(c),subpart(0),[129,1	," you could detect it on you wrist it is caused by the heart."]).
answer(number(9),part(c),subpart(0),[130, 2	," you can detect it on your wrist and it is caused by your heart beating"]).
answer(number(9),part(c),subpart(0),[131,0	,"You could detect the pulse in your vains after you have ran or had an exercise "]).
answer(number(9),part(c),subpart(0),[132,noanswer]).
answer(number(9),part(c),subpart(0),[133,noanswer]).
answer(number(9),part(c),subpart(0),[134,1	," You can detect it on your back of your wrist, the blood going round and beating."]).
%answer(number(9),part(c),subpart(0),[135,1	," On your chest rist when you execise it starts to beat more and more faster."]).
answer(number(9),part(c),subpart(0),[135,1	," On your chest wrist when you execise it starts to beat more and more faster."]).
answer(number(9),part(c),subpart(0),[136,1	," You could detect the pulse on your wrist."]).
answer(number(9),part(c),subpart(0),[137,1	," You detect it on your wrist and on neck because moving so fast so that moves fast with you to."]).
answer(number(9),part(c),subpart(0),[138,0	,"after 2 minutes to go to the next one. The beats that go up each minute causes it."]).
answer(number(9),part(c),subpart(0),[139,0	,"On your thumb, neck heart etc: the heart causes it and the lungs, when breathing."]).
answer(number(9),part(c),subpart(0),[140,noanswer]).
answer(number(9),part(c),subpart(0),[141,2	,"The pulse can be detected in the wrist and is a measurment of how fast your heart is pumping to get blood round the body."]).
answer(number(9),part(c),subpart(0),[142,0	,"you could detect the pulse in the first couple of minutes and its the body that causes it and the muscles because they need oxygen pumped round the body and the harder you work the faster it has to pump. X "]).
answer(number(9),part(c),subpart(0),[143,1	,"you can detect the pulse in the rist neck and thumb. it is caused by blood pumping trough the vanes."]).
answer(number(9),part(c),subpart(0),[144,1	,"Exercise causes the pulse rate to increase. You can detect when your heart beat or pulse is racing fast, or speeding up."]).
answer(number(9),part(c),subpart(0),[145,0	,"as soon as see started exerciseing her pulse rate just went up and up "]).
answer(number(9),part(c),subpart(0),[146,0	,"You could detect the pulse after 3 minutes and this is caused by speeding up the bodys energy and body tempreature."]).
answer(number(9),part(c),subpart(0),[147,0	,"You could have a rest and the start again when your pulse as slowed down"]).
answer(number(9),part(c),subpart(0),[148,0	,"say if you run you get tied that make your heart work harder."]).
answer(number(9),part(c),subpart(0),[149,0	," If you are running then your pulse goes up RAPPIEDLY."]).
answer(number(9),part(c),subpart(0),[150,noanswer]).
answer(number(9),part(c),subpart(0),[151,1	," In the wrist, it is caused by the blood flowing very fast to reach you muscles."]).
answer(number(9),part(c),subpart(0),[152,1 ,"You could detect the pulse in your wrist or in your neck and the beats show the time how fast or slow your pulse is going."]).
answer(number(9),part(c),subpart(0),[153,1	," Near your neck or rist. When you exersice your blood starts moving faster and faster"]).
answer(number(9),part(c),subpart(0),[154,1	," You can detect the pulse in your wrist or neck and this is caused by the speed that the blood is being pumped around the body.  
"]).
answer(number(9),part(c),subpart(0),[155,1	," The pulse can be detected at the wrist. The pressure of the oxygenated blood is high so you can feel the blood being carried in the arteries"]).
answer(number(9),part(c),subpart(0),[156,1	,"you can detect the pulse in the wrist and exercise, being frightend embaressment etc can cause it."]).
%answer(number(9),part(c),subpart(0),[157,2	," A pulse can be detected on you rist and it shows that your heart is still beating."]).
answer(number(9),part(c),subpart(0),[157,2	," A pulse can be detected on you wrist and it shows that your heart is still beating."]).
answer(number(9),part(c),subpart(0),[158,0	," When she first started because her pulse went to 115, what caused this was not enough exercise."]).
answer(number(9),part(c),subpart(0),[159,2	," you can detect the pulse either in your neck or you wrist and its caused by the heat pumping more blood around your heart"]).
answer(number(9),part(c),subpart(0),[160,noanswer]).
answer(number(9),part(c),subpart(0),[161,1	," You can detect the pulse in your neck or on your rist the flow of blood causes the pulse."]).
answer(number(9),part(c),subpart(0),[162,2	," You can detect the pulse in your wrist or in your neck and it's caused by the heart beating and pumping blood around the body.  
"]).
answer(number(9),part(c),subpart(0),[163,1	,"On the back of your wrist the blood flow causes it."]).
answer(number(9),part(c),subpart(0),[164,1	,"You can detect in your neck, or wrist its caused by the blood being let back in the muclse expansd whiche causes the beat"]).
answer(number(9),part(c),subpart(0),[165, 1	,"You can detect a pulse rate at eathier the neck or wrist. The pulse can be found better after exiercise, as the pulse rate is faster."]).
answer(number(9),part(c),subpart(0),[166,0	,"her heart when she starts to breathe faster the lungs start to inflate and make your pulse faster"]).
answer(number(9),part(c),subpart(0),[167,1	,"On your wrist, the erratic heart beat caused when exercising needs more & more oxygenated blood so the pulses in the veins pump more blood to the hearts & lungs & rest of body"]).
answer(number(9),part(c),subpart(0),[168,1	,"You can detect the pulse in the wrist. What causes it is when you stand still and touch the middle of the wristle you will then feel the pulse pumping you been running. "]).
answer(number(9),part(c),subpart(0),[169, 2	,"You could detect your pulse on the wrist on the underside of your neck and under your arm. When your heart pumps oxygenated blood around the body it pushes it around as such high pressure the valves (that stop back flow of blood) thud and give the feeling of a pulse."]).
answer(number(9),part(c),subpart(0),[170,0	,"On the first 2 minutes you could detect the pulse"]).
answer(number(9),part(c),subpart(0),[171,noanswer]).
answer(number(9),part(c),subpart(0),[172,noanswer]).
answer(number(9),part(c),subpart(0),[173,noanswer]).
answer(number(9),part(c),subpart(0),[174,1	,"On your wrist to much exercise make the heart beat faster which makes the pulse faster to"]).
answer(number(9),part(c),subpart(0),[175, 0	,"exercise causes pulse rate to go, high and low."]).
answer(number(9),part(c),subpart(0),[176,noanswer]).
answer(number(9),part(c),subpart(0),[177, 0	,"because when you running to fast."]).
answer(number(9),part(c),subpart(0),[178, 2	,"near the jugular vein in the neck the heart cause blood to pump around the body"]).
answer(number(9),part(c),subpart(0),[179, 2	,"you can detect a pulse on any main artery eg wrist, the Heart beat causes it."]).
answer(number(9),part(c),subpart(0),[180, 1	,"On the back of the wrist, place two fingers on it, it is caused by aderline in the blood moving faster "]).
answer(number(9),part(c),subpart(0),[181, 2	,"The pulse can be detected anywhere, usually the neck or wrist. The cause of this is the speed at which the heart pumps blood around the body."]).
answer(number(9),part(c),subpart(0),[182,1	,"you can detect your pulse in your wrist and neck your pulse rate increases when your heart rate increases."]).
answer(number(9),part(c),subpart(0),[183, 0	,"what causes you pluse to be faster is when you are doing some that make you werk fast that cause your puls to go fast  
"]).
answer(number(9),part(c),subpart(0),[184,noanswer]).
answer(number(9),part(c),subpart(0),[185,	2	,"You could detect the pulse at the side of your neck or on your rist. It goes faster when you get your heart going like by running."]).
answer(number(9),part(c),subpart(0),[186,	2	,"You could detect it in the side of the neck and it is the amount of beats per minuite from the heart."]).
answer(number(9),part(c),subpart(0),[187,noanswer]).
answer(number(9),part(c),subpart(0),[188, 2	," Side of your neck, wrist, the cause is your heart, beating faster ! "]).
answer(number(9),part(c),subpart(0),[189, 2	," you could detect your pulse from your wrist. It happens because when you exercise your heart beats faster and your blood flows around your body quicker. "]).
answer(number(9),part(c),subpart(0),[190, 2	," you can detect the pulse and your neck and wrist this were the vains are close to the skin the pulse is caused when the heart pumps it sends a pulse of blood around the body and this is what you can feel.  
"]).
answer(number(9),part(c),subpart(0),[191, 2 ," You can detect the pulse in your neck or wrist. It is where an artery is close to the bone, we can feel the blood pumping around our body from the heart.   
"]).
answer(number(9),part(c),subpart(0),[192, 2 ,"	you can detect your pulse on your neck or wrist, it is caused by the hart pumping the blood around the body "]).
answer(number(9),part(c),subpart(0),[193, 2	," You can detect the pulse in your neck or wrist. It is caused by your heart pumping blood round your body "]).
answer(number(9),part(c),subpart(0),[194,noanswer]).
answer(number(9),part(c),subpart(0),[195,noanswer]).
answer(number(9),part(c),subpart(0),[196, 	1	," When yor heart beats it causes your pulse rate. But when your heart beat stops then your pulse could stop too "]).
answer(number(9),part(c),subpart(0),[197,	2 ,"	at the wrist or neck because its the blood being pumped round the body from the heart. "]).
answer(number(9),part(c),subpart(0),[198, 2	," On your neck. It is caused by the heart pumping blood around the body and it increases when you exercise as more energy is required "]).
answer(number(9),part(c),subpart(0),[199, 0 ,"running doing sport "]).
answer(number(9),part(c),subpart(0),[200,	1 ,"	The arm and neck, it caused by a muscle vein reaction "]).
answer(number(9),part(c),subpart(0),[201, 2 ,"   
you can detect the pulse in the wrist neck area  
 Blood being pumped round the body by the heart is what causes it  
 "]).
answer(number(9),part(c),subpart(0),[202, 2 ,"   
You can detect the pulse in your left hand and your heart beat causes this, the faster your heart beats the faster your pulse gets  
 "]).
