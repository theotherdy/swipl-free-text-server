:- multifile answer/4.

answer(number(6),part(b),subpart(0),[1,	0	,"By vasoconstriction of the skin	"]).
answer(number(6),part(b),subpart(0),[2,	1	,"By making hairs stand on end.	"]).
answer(number(6),part(b),subpart(0),[3,	1	,"Shivering - movement creates heat so the body shakes rapidly.	"]).
answer(number(6),part(b),subpart(0),[4,	1	,"By contracting the hair muscles and standing the hairs up to trap warm air from the body."]).
answer(number(6),part(b),subpart(0),[5,	0	,"As explained above"]).
answer(number(6),part(b),subpart(0),[6,	1	,"Shivering"]).
answer(number(6),part(b),subpart(0),[7,	1	,"Hairs stand upright."]).
answer(number(6),part(b),subpart(0),[8,	0	,"traps air between hairs on skin"]).
answer(number(6),part(b),subpart(0),[9,	1	,"Shivering"]).
answer(number(6),part(b),subpart(0),[10,	1	,"The muscles twitch, this movement requires energy, the respiration also releases heat warming up the body.  The muscle twitch is shivering. "]).
answer(number(6),part(b),subpart(0),[11,	0	,"The hairs on the body relax acting as an insulator."]).
answer(number(6),part(b),subpart(0),[12,	0	,"By sweating"]).
answer(number(6),part(b),subpart(0),[13,	1	,"the hair muscles move the hair to an upright position to trap warm air"]).
answer(number(6),part(b),subpart(0),[14,	1	,"Shivering"]).
answer(number(6),part(b),subpart(0),[15,	1	,"The hair muslces contract to make the hairs stand up to trap heat leaving the body."]).
answer(number(6),part(b),subpart(0),[16,	0	,"will stand up to make you warm"]).
answer(number(6),part(b),subpart(0),[17,	0	,"it pumps blood around your body quicker"]).
answer(number(6),part(b),subpart(0),[18,	0	,"the fat layer starts to move as a solid to try and create heat."]).
answer(number(6),part(b),subpart(0),[19,	1	,"By making you shiver"]).
answer(number(6),part(b),subpart(0),[20,	1	,"By making the body shiver, the exercises the muscles which makes them heat up."]).
answer(number(6),part(b),subpart(0),[21,	1	,"Shivering"]).
answer(number(6),part(b),subpart(0),[22,	1	,"The body warms up by 'shivering'"]).
answer(number(6),part(b),subpart(0),[23,	1	,"The muscles continuously contract and relax to use more energy + generate heat - shivering."]).
answer(number(6),part(b),subpart(0),[24,	1	,"The Body can shiver."]).
answer(number(6),part(b),subpart(0),[25,	1	,"Shivering"]).
answer(number(6),part(b),subpart(0),[26,	1	,"Hair muscle lifts hair upright - combined, hairs trap a layer of air which is an excellent insulator.	"]).
answer(number(6),part(b),subpart(0),[27,	1	,"shivering"]).
answer(number(6),part(b),subpart(0),[28,	1	,"The muscles shiver which uses energy and produces slightly more heat.	"]).
answer(number(6),part(b),subpart(0),[29,	1	,"Increases metabolism by producing heat energy in shivering."]).
answer(number(6),part(b),subpart(0),[30,	1	,"the body's metabolism rate increases in order to generate energy."]).
answer(number(6),part(b),subpart(0),[31,	1	,"Increases Liver Activity also we generates more heat by increasing metcholism."]).
answer(number(6),part(b),subpart(0),[32,	1	,"The hairs in the skin become erect due to the hair muscle contracting - this helps to reduce heat loss that could other wise escape. "]).
answer(number(6),part(b),subpart(0),[33,	0	,"vassoconstriction"]).
answer(number(6),part(b),subpart(0),[34,	1	,"It sends impulses to the muscles which start to shiver to increase energy using so increasing temperature"]).
answer(number(6),part(b),subpart(0),[35,	0	,"faster blood circulation"]).
answer(number(6),part(b),subpart(0),[36,	0	,"Sweat pores close.	"]).
answer(number(6),part(b),subpart(0),[37,	1	,"The muscles start contracting to produce heat.  This is known as Shivering, this helps warm up the body"]).
answer(number(6),part(b),subpart(0),[38,	1	,"By shivering"]).
answer(number(6),part(b),subpart(0),[39,	1	,"The body's metabolism rate increases."]).
answer(number(6),part(b),subpart(0),[40,	1	,"The hairs on the skin stand upright."]).
answer(number(6),part(b),subpart(0),[41,	1	,"One way it does this is by shivering"]).
answer(number(6),part(b),subpart(0),[42,	0	,"It tries to get sweat gland to increase and increase the blood flow."]).
answer(number(6),part(b),subpart(0),[43,	1	,"hairs stand on end so that air can get trapped, warming the body up."]).
answer(number(6),part(b),subpart(0),[44,	1	,"By shivering which causes muscles to twitter which causes respiration where heat is released"]).
answer(number(6),part(b),subpart(0),[45,	1	,"The muscles cause us to shiver in order to increase our metabolism"]).
answer(number(6),part(b),subpart(0),[46,	1	,"Shivering - the muscles contract producing heat."]).
answer(number(6),part(b),subpart(0),[47,	1	,"making the hairs stand on end."]).
answer(number(6),part(b),subpart(0),[48,	0	,"More blood is pumped around the body."]).
answer(number(6),part(b),subpart(0),[49,	0	,"vasoconstriction"]).
answer(number(6),part(b),subpart(0),[50,	1	,"The sweat pore closes and the gland doesn't release as much water."]).
answer(number(6),part(b),subpart(0),[51,	1	,"We shiver"]).
answer(number(6),part(b),subpart(0),[52,	0	,"The heart pumps faster so warmer blood is being provided."]).
answer(number(6),part(b),subpart(0),[53,	1	,"Hairs stand on end - trap air.  trapped air is a poor conductor of heat"]).
answer(number(6),part(b),subpart(0),[54,	0	,"The muscles shake to create warmth."]).
answer(number(6),part(b),subpart(0),[55,	1	,"The hairs stand up on end to trap heat inside."]).
answer(number(6),part(b),subpart(0),[56,	0	,"You breathe quicker to pump more blood around your body."]).
answer(number(6),part(b),subpart(0),[57,	0	,"Not to lose water from your body."]).
answer(number(6),part(b),subpart(0),[58,	1	,"by shivering - the body respires more releasing more energy which it uses as heat energy."]).
answer(number(6),part(b),subpart(0),[59,	0	,"By supplying more blood to the vital organs to get those warm first which will in turn warm up the rest of the body."]).
answer(number(6),part(b),subpart(0),[60,	1	,"One way to increase body temperature would be shivering (Random contractions of the muscles in your body)"]).
answer(number(6),part(b),subpart(0),[61,	1	,"It makes the hair muscle contract so that the hair stands on end."]).
answer(number(6),part(b),subpart(0),[62,	1	,"increase liver activity to produce heat."]).
answer(number(6),part(b),subpart(0),[63,	1	,"by the muscles working (shivering)"]).
answer(number(6),part(b),subpart(0),[64,	1	,"by shivering"]).
answer(number(6),part(b),subpart(0),[65,	1	,"Shivering, the rapid contraction + relaxation of muscles."]).
answer(number(6),part(b),subpart(0),[66,	1	,"By shivering"]).
answer(number(6),part(b),subpart(0),[67,	1	,"By shivering - this increases the metabolism ie the conversion into energy"]).
answer(number(6),part(b),subpart(0),[68,	0	,"Because your body is use to its normal temperature. Even though your skin is cold, your body is still warm inside trying to increase its temperature."]).
answer(number(6),part(b),subpart(0),[69,	1	,"It shivers and metabolic reactions increase, both of these processes produce heat energy in an attempt to increase the body' temperature."]).
answer(number(6),part(b),subpart(0),[70,	1	,"Shivering makes us move which increases our metabolism"]).
answer(number(6),part(b),subpart(0),[71,	1	,"Shivering - the muscles detect that your body is too cold and so they start to produce energy by shivering to warm us up."]).
answer(number(6),part(b),subpart(0),[72,	1	,"the hairs on your skin stand on end trapping heat."]).
answer(number(6),part(b),subpart(0),[73,	0	,"The body sweats"]).
answer(number(6),part(b),subpart(0),[74,	1	,"Shivering as it makes the body move and heat up	"]).
answer(number(6),part(b),subpart(0),[75,	1	,"metabolism works faster"]).
answer(number(6),part(b),subpart(0),[76,	1	,"The body muscles shiver to warm the body this makes the muscles work creating warmth"]).
answer(number(6),part(b),subpart(0),[77,	0	,"The liver releases heat."]).
answer(number(6),part(b),subpart(0),[78,	1	,"The hairs stand up on end, trapping air which insulates."]).
answer(number(6),part(b),subpart(0),[79,	1	,"Your muscles shiver"]).
answer(number(6),part(b),subpart(0),[80,	1	,"hairs erect trapping a layer of air on the skin as insulation"]).
answer(number(6),part(b),subpart(0),[81,	1	,"The body starts to shiver which creates energy in the form of heat."]).
answer(number(6),part(b),subpart(0),[82,	1	,"Shivers"]).
answer(number(6),part(b),subpart(0),[83,	1	,"makes its hairs stand up to create an insulation."]).
answer(number(6),part(b),subpart(0),[84,	1	,"The hair muscle relaxes, erecting the hair which traps a layer of insulating air around the skin."]).
answer(number(6),part(b),subpart(0),[85,	1	,"The hairs on the skins surface stand up inoder to find any heat which happens to be in the air around the body."]).
answer(number(6),part(b),subpart(0),[86,	1	,"By shivering it makes the muscles contract and starts working. "]).
answer(number(6),part(b),subpart(0),[87,	1	,"The erecter hair muscles constrict, pulling the hair upright till the hairs that are upright trap a layer of air - which is a good insulator - meaning less body heat is lost to the surroundings."]).
answer(number(6),part(b),subpart(0),[88,	0	,"The fat layer gives off heat	"]).
answer(number(6),part(b),subpart(0),[89,	0	,"Making sure the blood is not near the skin surface so that the air doesn't cool it down"]).
answer(number(6),part(b),subpart(0),[90,	1	,"The hairs on our skin stand on end"]).
answer(number(6),part(b),subpart(0),[91,	0	,"The hair folds back traping warm air close to the skin."]).
answer(number(6),part(b),subpart(0),[92,	0	,"the blood pumps faster"]).
answer(number(6),part(b),subpart(0),[93,	1	,"Hairs at the surface of the skin become erect to insulate the body by trapping air."]).
answer(number(6),part(b),subpart(0),[94,	1	,"Shivering"]).
answer(number(6),part(b),subpart(0),[95,	0	,"The muscles vibrate, and create heat all over the body."]).
answer(number(6),part(b),subpart(0),[96,	1	,"shivering"]).
answer(number(6),part(b),subpart(0),[97,	1	,"By making hairs protude more from the body catching a layer of air around the skin."]).
answer(number(6),part(b),subpart(0),[98,	1	,"The hairs stand erect so that they can trap small heat particles and bring them close to the surface.	"]).
answer(number(6),part(b),subpart(0),[99,	0	,"it increases its metabolism."]).
answer(number(6),part(b),subpart(0),[100,	1	,"You shake, the muscle shake to increase temperature."]).
answer(number(6),part(b),subpart(0),[101,	1	,"The hairs Straighten up."]).
answer(number(6),part(b),subpart(0),[102,	1	,"Shivering movement makes heat energy therefore warming body up."]).
answer(number(6),part(b),subpart(0),[103,	1	,"Hairs stand upright for air between them to trap heat."]).
answer(number(6),part(b),subpart(0),[104,	1	,"Increases liver activity, which produces heat by increasing metabolism."]).
answer(number(6),part(b),subpart(0),[105,	1	,"The muscles contract and relax quickly, shivering, in order to gain energy resulting in warmth."]).
answer(number(6),part(b),subpart(0),[106,	1	,"Hairs stand up from surface of the skin."]).
answer(number(6),part(b),subpart(0),[107,	0	,"The blood vessel contract in order to keep them from losing heat."]).
answer(number(6),part(b),subpart(0),[108,	1	,"Shivering muscles respire producing heat "]).
answer(number(6),part(b),subpart(0),[109,	0	,"the blood vessels move further away from the skin to try and warm up"]).
answer(number(6),part(b),subpart(0),[110,	1	,"The muscles start shivering causing friction and heat to be generated	"]).
answer(number(6),part(b),subpart(0),[111,	1	,"Shivering"]).
answer(number(6),part(b),subpart(0),[112,	1	,"the muscles expand and contract quickly (shivering) this makes it warmer."]).
answer(number(6),part(b),subpart(0),[113,	1	,"Shivering by moving very quickly to generate friction"]).
answer(number(6),part(b),subpart(0),[114,	1	,"The hair on your bodies stand on end forming a layer of air."]).
answer(number(6),part(b),subpart(0),[115,	1	,"uses hair to erect itself and catch as much heat as possible (so there is a thin layer of gas heat on the skin)."]).
answer(number(6),part(b),subpart(0),[116,	1	,"The muscles shiver to produce heat energy."]).
answer(number(6),part(b),subpart(0),[117,	1	,"by shivering which causes the musuls to have jurky movements"]).
answer(number(6),part(b),subpart(0),[118,noanswer]).
answer(number(6),part(b),subpart(0),[119,	0	,"The heart will pump the blood containing the oxygen much more quickly round the body.	"]).
answer(number(6),part(b),subpart(0),[120,	1	,"By shivering - relaxing and contracting muscles under the skin causing friction and thus heat."]).
answer(number(6),part(b),subpart(0),[121,	1	,"The body shivers. This happens so that there is more respiration needing to happen so more energy is produced and there will be more heat produced if there is more energy."]).
answer(number(6),part(b),subpart(0),[122,	1	,"By shivering.  The muscles are made to contract helping the body to warm up."]).
answer(number(6),part(b),subpart(0),[123,	1	,"hairs on you body stand on end to trap air and heat it."]).
answer(number(6),part(b),subpart(0),[124,	1	,"shivering"]).
answer(number(6),part(b),subpart(0),[125,	1	,"Shivers - muscles move so this produces heat."]).
answer(number(6),part(b),subpart(0),[126,	1	,"The body will start to shiver."]).
answer(number(6),part(b),subpart(0),[127,	1	,"shivers"]).
answer(number(6),part(b),subpart(0),[128,	1	,"It shuts down its sweat pores so it doesn't loose any heat."]).
answer(number(6),part(b),subpart(0),[129,	1	,"By shivering"]).
answer(number(6),part(b),subpart(0),[130,	1	,"The hairs muscles all over your body allow them to stand - this enables you to keep a warm layer of air circulating around your body"]).
answer(number(6),part(b),subpart(0),[131,	1	,"The hairs on the skin are raised to trap an insulating air layer"]).
answer(number(6),part(b),subpart(0),[132,	1	,"The hairs stand on end to give a protective layer much like a coat of fur on an animal."]).
answer(number(6),part(b),subpart(0),[133,	1	,"By shivering."]).
answer(number(6),part(b),subpart(0),[134,	0	,"goosebumps, helps insulate the body."]).
answer(number(6),part(b),subpart(0),[135,	1	,"The hairs effect to trap air so that the air can produce a layer of warmth to try and increase temp.  Also stops any heat from escaping."]).
answer(number(6),part(b),subpart(0),[136,	1	,"To increase it's temperature the body shivers (muscles vibrate to produce heat)."]).
answer(number(6),part(b),subpart(0),[137,	1	,"The hair erector muscle contracts and the hair becomes erect"]).
answer(number(6),part(b),subpart(0),[138,	1	,"The hairs contract higher to collect heat."]).
answer(number(6),part(b),subpart(0),[139,	1	,"by shivering"]).
answer(number(6),part(b),subpart(0),[140,	1	,"the body can shiver making the muscles move to warm up the body."]).
answer(number(6),part(b),subpart(0),[141,	0	,"Capilaries flow with blood"]).
answer(number(6),part(b),subpart(0),[142,	0	,"The hairs on the skin help the temperature to increase."]).
answer(number(6),part(b),subpart(0),[143,	1	,"shivering, this is a quick jerky movement of the muscles which generates heat."]).
answer(number(6),part(b),subpart(0),[144,	1	,"Shivering - creates kinetic energy throughout the body."]).
answer(number(6),part(b),subpart(0),[145,	1	,"It shivers - this muscle activity generates heat which is used by the body."]).
answer(number(6),part(b),subpart(0),[146,	0	,"by growing more hair?	"]).
answer(number(6),part(b),subpart(0),[147,	0	,"pumps more blood"]).
answer(number(6),part(b),subpart(0),[148,	0	,"the fat layers thicken up so less cold can get to the vessels	"]).
answer(number(6),part(b),subpart(0),[149,	0	,"Produces blood cells which cause your skin to go red, hence red cheeks in winter."]).
answer(number(6),part(b),subpart(0),[150,	0	,"you get energy and start to sweat"]).
answer(number(6),part(b),subpart(0),[151,	1	,"by shivering"]).
answer(number(6),part(b),subpart(0),[152,	0	,"Pumps blood around your body faster."]).
answer(number(6),part(b),subpart(0),[153,	1	,"The hairs stand on end"]).
answer(number(6),part(b),subpart(0),[154,	1	,"Shivering - muscles contract and go into spasms as muscle activity generates heat."]).
answer(number(6),part(b),subpart(0),[155,	1	,"all the hair muscles tense and all the hairs on a persons body stand up right trapping a layer of warm air around the persons body."]).
answer(number(6),part(b),subpart(0),[156,	1	,"Shivering"]).
answer(number(6),part(b),subpart(0),[157,	1	,"Hair (erectile) musle contracts - raising hair for extra layer of insulation"]).
answer(number(6),part(b),subpart(0),[158,	0	,"It contracts allowing less heat to escape."]).
answer(number(6),part(b),subpart(0),[159,	1	,"shivering "]).
answer(number(6),part(b),subpart(0),[160,	1	,"It sends nervous impulses to the muscles, making them contract and relax in quick succession - shivering. Shivering produces heat energy."]).
answer(number(6),part(b),subpart(0),[161,	1	,"It shivers flowing blood around quickly"]).
answer(number(6),part(b),subpart(0),[162,	0	,"It creates more urine which is warm"]).
answer(number(6),part(b),subpart(0),[163,	1	,"It increases liver activity (:increase metabolic rate)"]).
answer(number(6),part(b),subpart(0),[164,	0	,"Making your heart pump faster	"]).
answer(number(6),part(b),subpart(0),[165,	1	,"The hair muscle contracts making the hairs on your skin stand on end.	"]).
answer(number(6),part(b),subpart(0),[166,	1	,"The hair will become erect so as to trap as thick and still a layer of air next to the skin for insulation."]).
answer(number(6),part(b),subpart(0),[167,	1	,"The muscles move quickly making the body shiver."]).
answer(number(6),part(b),subpart(0),[168,	1	,"Shivering - makes the muscles move"]).
answer(number(6),part(b),subpart(0),[169,	1	,"by shivering."]).
answer(number(6),part(b),subpart(0),[170,	1	,"shivering"]).
answer(number(6),part(b),subpart(0),[171,	0	,"Hair muscles relax allowing your hair to stand on end and catch warm air particles"]).
answer(number(6),part(b),subpart(0),[172,	0	,"All the muscles will make fast little contractions to make heat."]).
answer(number(6),part(b),subpart(0),[173,	0	,"The body stops producing sweat to prevent heat loss.	"]).
answer(number(6),part(b),subpart(0),[174,	1	,"It makes the hairs on your body stand up to trap in the heat.	"]).
answer(number(6),part(b),subpart(0),[175,	0	,"The body moves the hair on the skin so it is horizontal. This allows warm air to be trapped in an insulating layer.	"]).
answer(number(6),part(b),subpart(0),[176,	1	,"One way to increase temperature is by shivering."]).
answer(number(6),part(b),subpart(0),[177,	1	,"shivering"]).
answer(number(6),part(b),subpart(0),[178,	1	,"shivering to produce friction."]).
answer(number(6),part(b),subpart(0),[179,	1	,"The hairs on our body go erect to trap the heat and trap hot air."]).
answer(number(6),part(b),subpart(0),[180,	1	,"Our hairs stick on and."]).
answer(number(6),part(b),subpart(0),[181,	1	,"The hairs stand on end to trap air and insulate the body."]).
answer(number(6),part(b),subpart(0),[182,	1	,"By shivering"]).
answer(number(6),part(b),subpart(0),[183,	1	,"It shivers."]).
answer(number(6),part(b),subpart(0),[184,	1	,"Increased metabolic rate: the liver increase it rate of metabolism and the muscle shiver."]).
answer(number(6),part(b),subpart(0),[185,	1	,"Shivering - the muscles shake to provide heat energy	"]).
answer(number(6),part(b),subpart(0),[186,	1	,"makes the mussels contract and relax quickly - shivering"]).
answer(number(6),part(b),subpart(0),[187,	1	,"Shivering"]).
answer(number(6),part(b),subpart(0),[188,	0	,"Pushes the blood round faster.	"]).
answer(number(6),part(b),subpart(0),[189,	1	,"By making muscles spazm which is called shivering."]).
answer(number(6),part(b),subpart(0),[190,	1	,"body hair stands on end and traps a layer of air close to the skin for insulation"]).
answer(number(6),part(b),subpart(0),[191,	1	,"hair muscle contracts which erects the hair attempting to trap oxygen and stay warm"]).
answer(number(6),part(b),subpart(0),[192,	0	,"Our glands rush around trying to get more water or Sugar, by doing this they are colliding with other blood cells or cells.  This produces heat."]).
answer(number(6),part(b),subpart(0),[193,	1	,"It causes our hairs to stand on end and the body starts to shiver."]).
answer(number(6),part(b),subpart(0),[194,	0	,"It increases the speed in which blood is pumped around your body	"]).
answer(number(6),part(b),subpart(0),[195,	1	,"The hair on your body stand on end to conserve heat."]).
answer(number(6),part(b),subpart(0),[196,	0	,"It pumps more blood around the body"]).
answer(number(6),part(b),subpart(0),[197,	1	,"hair stand up."]).
answer(number(6),part(b),subpart(0),[198,	1	,"It makes surface hair stand on end trapping a layer of air next to the skin."]).
answer(number(6),part(b),subpart(0),[199,	0	,"By increasing the fat layer above the blood vessels"]).
answer(number(6),part(b),subpart(0),[200,	1	,"The muscles in the body contract causing shivering which heats up the body."]).
answer(number(6),part(b),subpart(0),[201,	0	,"goosebumps"]).
answer(number(6),part(b),subpart(0),[202,	1	,"Hairs on your skin stand on end to try and trap air pockets to heat you up."]).

