:- multifile answer/4.

answer(number(8),part(b),subpart(0),[1,	1	,"The heat from the mother is transferred in the milk to the baby, the heat then is transferred to the baby's body, and so heating them."]).
answer(number(8),part(b),subpart(0),[2,	1	,"the warm milk warms up the insides of their bodies and keeps the vital organs warm enough to work."]).
answer(number(8),part(b),subpart(0),[3,	0	,"They store it under their fur as insulation to prevent heat coming out through the skin. It also maintains their body temperature (part of homeostasis.)"]).
answer(number(8),part(b),subpart(0),[4,	0	,"The mothers milk would contain alot of nutrients and fat this would help build the baby up so not to get cold as the fat would be thermal under his thick skin."]).
answer(number(8),part(b),subpart(0),[5,	1	,"The mothers milk would be warm so therefore the baby polar bear does not have to use energy to heat it up. If the baby polar bear drank cold liquids it would cool them down & use much energy having to heat them & the liquid up."]).
answer(number(8),part(b),subpart(0),[6,	2	,"the milk is very fatty so they use this fat as insulators."]).
answer(number(8),part(b),subpart(0),[7,	1	,"They drink from the mother which has kept the milk warm. This is transfered to them, creating more fat and ultimately more heat and warmth"]).
answer(number(8),part(b),subpart(0),[8,noanswer]).
answer(number(8),part(b),subpart(0),[9,	1	,"Because the heat energy is transferred through the milk and into the baby which is an efficient way of obtaining energy through not having to create it her himself"]).
answer(number(8),part(b),subpart(0),[10,	1	,"The mothers body will always be kept at a constant temperature and therefore so to will the milk, so as the baby drinks it, it is receiving extra warmth."]).
answer(number(8),part(b),subpart(0),[11,	1	,"This happens due to the mother having such a thick coat of fur making it quite hard for her to get cold.  This allows her to have warm milk.  The milk is warm due to the polar bears being warm blooded animals."]).
answer(number(8),part(b),subpart(0),[12,noanswer]).
answer(number(8),part(b),subpart(0),[13,	1	,"The milk contains fats and the baby polar bear can produce insulation in the form of fatty layers."]).
answer(number(8),part(b),subpart(0),[14,	1	,"The milk comes from inside the mother and will be very warm for the baby."]).
answer(number(8),part(b),subpart(0),[15,	0	,"All mammals drink milk"]).
answer(number(8),part(b),subpart(0),[16,	1	,"The mother's milk is warm, so when the babys drink it, the heat is transferred from the milk to inside their bodies"]).
answer(number(8),part(b),subpart(0),[17,	1	,"The milk from the mother is warm, when it enters the babys system it heats up the oesophagus and some of the rest to the digestive system this in turn heats up the blood, spreading the warmth around the body."]).
answer(number(8),part(b),subpart(0),[18,	2	,"The mothers milk is Stored under layers of fat and thick fur.  This will mean the milk will be warm and full of fat.  When the baby drinks this it will warm it and help it to put on weight and grow	"]).
answer(number(8),part(b),subpart(0),[19,	1	,"The milk has been inside the mother's body, which is well insulated due to the thick fur so it is at body temperature, therefore when the baby polar bear drinks the milk it will be drinking warm liquid so the bear will keep warm."]).
answer(number(8),part(b),subpart(0),[20,	1	,"The inside of your body and polar bears bodies is alot warmer than your outside. e.g fur or skin therefore when the baby polar bear feeds on his / her mothers milk it will warm him her up further."]).
answer(number(8),part(b),subpart(0),[21,	0	,"Because they use the milk to give them energy their metabilism speeds up which makes them produce more heat."]).
answer(number(8),part(b),subpart(0),[22,	1	,"When the baby bears take in the milk the heat energy is transfered from the mother into the baby."]).
answer(number(8),part(b),subpart(0),[23,	0	,"Because there mothers milk contains everything they need to be able to survive including warmth"]).
answer(number(8),part(b),subpart(0),[24,	2	,"When they drink their mothers milk it is warm and gives them the nutrients they need as well as enabling them to grow a layer of fat to keep them warm."]).
answer(number(8),part(b),subpart(0),[25,	1	,"the milk comes from the breast which is generally warm due to the core temperature this gets past and keeps the baby warm"]).
answer(number(8),part(b),subpart(0),[26,	1	,"While they are taking milk, they can be close to their mothers body, keeping them warm, and the milk itself is warm."]).
answer(number(8),part(b),subpart(0),[27,	1	,"Because the mother's milk is warm and when she gives it to her baby the warmth is then past on."]).
answer(number(8),part(b),subpart(0),[28,	1	,"The milk comes from within their mothers and will therefore be warm, when the baby suckles the milk, the milk is warming the babys stomach."]).
answer(number(8),part(b),subpart(0),[29,noanswer]).
answer(number(8),part(b),subpart(0),[30,	2	,"The mothers milk is rich in fat and nutrients, the fat helps the baby to increase the fat layer under the skin which helps to keep the body heat from escaping."]).
answer(number(8),part(b),subpart(0),[31,	1	,"The mothers milk is kept at body temperature because it is inside the mother. And it also contains nutrients which will help his fur grow thick."]).
answer(number(8),part(b),subpart(0),[32,	1	,"As the inside of a mammel is warm (warm blooded) it's milk tends to be warm aswell because it has been produced by her body"]).
answer(number(8),part(b),subpart(0),[33,	0	,"This is a method of heat transfer.  The heat and energy from the mother is passed to her offspring through feeding, it may be critical for survival."]).
answer(number(8),part(b),subpart(0),[34,	1	,"The mothers milk will be fresh from the mothers body.  Her body will be warm so the milk will be heated by the body temperature keeping the milk warm."]).
answer(number(8),part(b),subpart(0),[35,	1	,"They use the energy contained in the milk as heat energy so they keep warm."]).
answer(number(8),part(b),subpart(0),[36,	1	,"The milk is warm, therefore the milk warms the baby when it drinks it."]).
answer(number(8),part(b),subpart(0),[37,	1	,"The milk will take some of the mother's heat energy with it. The baby bear will be warmer because of the warm milk."]).
answer(number(8),part(b),subpart(0),[38,	1	,"Because body heat from the mother can be transferred to the baby polar bears through the milk which was kept inside the mother polar bear."]).
answer(number(8),part(b),subpart(0),[39,	1	,"There mothers milk is their only source of food as they are too young to go out and hunt, but it is also very fatty so therefore helps them put weight on to keep warm."]).
answer(number(8),part(b),subpart(0),[40,	1	,"Milk contains fat, which makes an insulating layer for the bears in cold climates, the fat can also be used for energy and increasing activity will give faster metabolic rate."]).
answer(number(8),part(b),subpart(0),[41,	0	,"They will get natural warmth from their mother to help them survive"]).
answer(number(8),part(b),subpart(0),[42,	1	,"The milk goes in and warms the stomach and mouth. This is because the milk is warm and gets around the circulation"]).
answer(number(8),part(b),subpart(0),[43,	2	,"The mother's milk should be quite fatty so therefore should help them to gain an insulating layer more quickly to keep warm (insulating layer of fat). Also the milk should be warm from the mother, so it should warm them up also in that way."]).
answer(number(8),part(b),subpart(0),[44,	1	,"Keeping warm requires energy - energy is used in respiration- respiration uses glucose, - milk contains glucose (in the form of fats)"]).
answer(number(8),part(b),subpart(0),[45,	1	,"Their mothers milk is warm when they drink it, it circulates their body helping to keep them warm."]).
answer(number(8),part(b),subpart(0),[46,	1	,"The polar bears milk would be at her own body standard temperature - warm. This acts as an aditional heater through their system and body."]).
answer(number(8),part(b),subpart(0),[47,	1	,"To babies drink the milk from the mother. The milk is slightly warm from being inside a highly fatty body and processing the milk will increase the heat. Keeps warm in babies stomach."]).
answer(number(8),part(b),subpart(0),[48,	0	,"They will be warmed up from the milk inside there body."]).
answer(number(8),part(b),subpart(0),[49,	0	,"Because they are young, the babies cannot generate much of their own heat, so they rely on their mother's warm milk for this."]).
answer(number(8),part(b),subpart(0),[50,	1	,"The mother is very warm due to her thick coat and fatty insulation layer. This means the milk she produces is warm, therefore when the baby drinks the milk it too will be warmed up."]).
answer(number(8),part(b),subpart(0),[51,	0	,"The milk they use provides nutrients required for warmth."]).
answer(number(8),part(b),subpart(0),[52,	1	,"The milk is converted to fat which causes an insulating layer of skin to form around the bear, under the fur. This prevents heat loss."]).
answer(number(8),part(b),subpart(0),[53,	0	,"The mother has more energy to produce and feed her young"]).
answer(number(8),part(b),subpart(0),[54,	1	,"The body's temperature of the mother, adult, polar bear would be higher than the childs as it would have a stronger / more developed internal system, thus providing milk of a higher temperature."]).
answer(number(8),part(b),subpart(0),[55,	1	,"the milk inside the mothers body is warm as mammals blood is warm so it stays warm when the baby drinks it."]).
answer(number(8),part(b),subpart(0),[56,	1	,"well inside the body we a warm blooded.  So the milk should come out warm which would warm the baby's up."]).
answer(number(8),part(b),subpart(0),[57,	0	,"Polar bears are warm blooded so they need milk to keep them warm and alive."]).
answer(number(8),part(b),subpart(0),[58,	0	,"Because the milk is broken down and is used in respiration by the polar bear to give energy to the muscles and the movement of the muscles gives out heat to heat the bear."]).
answer(number(8),part(b),subpart(0),[59,	1	,"The milk contains fats which are able to give the small bears a layer of blubber which will insulate their body heat."]).
answer(number(8),part(b),subpart(0),[60,	2	,"Polar bears are adapted to keep as warm as possible in cold conditions so if the milk comes from inside the mother it will be warm and heat will be transferred to the young.  Milk also contains fat which will create a fatty layer of insulation on the young which the mother has already built up."]).
answer(number(8),part(b),subpart(0),[61,noanswer]).
answer(number(8),part(b),subpart(0),[62,	1	,"The milk is coming out of the mother which is warm to heat the baby polar bear."]).
answer(number(8),part(b),subpart(0),[63,	1	,"because the warm milk heats the body blood when digested"]).
answer(number(8),part(b),subpart(0),[64,	1	,"the milk insulates the baby polar bear as it contains fats and also provides heat energy."]).
answer(number(8),part(b),subpart(0),[65,	1	,"Their mother's milk is very warm as it has been within the mothers body.  * Thus when drunk from, the baby polar bear is provided with heat within its body."]).
answer(number(8),part(b),subpart(0),[66,	2	,"Their mothers milk contains all nutrients needed including fat for insulation and also energy which can be converted to heat energy"]).
answer(number(8),part(b),subpart(0),[67,	2	,"The milk produced by the mother and suckled by the young is warm when produced. It also contains alot of fat which is important for insulation."]).
answer(number(8),part(b),subpart(0),[68,	2	,"because the baby polar bears mothers milk comes out warmer so that warmth passes on to the baby polar bear also it contains a lot of fat which the baby can store underneath its fur to help it stay warm."]).
answer(number(8),part(b),subpart(0),[69,	1	,"The mothers have more fur so their milk is warm.  When it passes into the baby heat is also transferred in the milk."]).
answer(number(8),part(b),subpart(0),[70,	1	,"The mothers milk is warm the baby polar bear then drinks the milk which helps warm up his blood, which is circulated round the body."]).
answer(number(8),part(b),subpart(0),[71,noanswer]).
answer(number(8),part(b),subpart(0),[72,	0	,"warmth, nutrients and food are passed along to the baby in the milk"]).
answer(number(8),part(b),subpart(0),[73,	1	,"during pregnancy hormones released allow milk to produce - it contains fats and other important nutrients needed to develop (baby) a layer of fat then lies under the skin for insulation."]).
answer(number(8),part(b),subpart(0),[74,	1	,"Because they milk is more warmer and more furry insulation to reduce heat loss."]).
answer(number(8),part(b),subpart(0),[75,	0	,"The milk of the mother helps keep polar bears warm because inside the immune system keeps the polar bear warm.  So the milk helps do this."]).
answer(number(8),part(b),subpart(0),[76,	1	,"The milk is warm in which comes from the mother so the bears are warmer"]).
answer(number(8),part(b),subpart(0),[77,	1	,"The milk gives the baby warm because the milk has just come from inside the mothers body were it very warm."]).
answer(number(8),part(b),subpart(0),[78,	1	,"Because the mothers milk gives the babies energy so they can increase their metabolic rate and also the milk could be warm from the mothers body"]).
answer(number(8),part(b),subpart(0),[79,	0	,"The warm milk"]).
answer(number(8),part(b),subpart(0),[80,	1	,"Its like drinking a hot cup of tea etc, the baby is drinking warm milk from it mother which gives is energy and also allows it to warm its insides up and grow stronger."]).
answer(number(8),part(b),subpart(0),[81,	1	,"The mother's milk will contain fat so as the milk is digested and the fat is absorbed into the skin producing a layer of insulation to help keep the baby polar bear warm. "]).
answer(number(8),part(b),subpart(0),[82,	0	,"The milk that they provided with gives them nutrients and energy for their growth and survival."]).
answer(number(8),part(b),subpart(0),[83,	1	,"The heat from the mother is conducted to the milk which is warmed - the cubs drink the milk and are warmed by heat radiation from the milk - also their fur isn't as thick as the mother's - also they can't eat meat yet so they can't get heat from that."]).
answer(number(8),part(b),subpart(0),[84,	1	,"The fat contained in the mothers milk is useful to the baby as it is a good source of energy. It needs alot of energy to fight the cold."]).
answer(number(8),part(b),subpart(0),[85,	1	,"the mother's milk gives them everything they need to survive. the baby turns the food into energy & this is what keeps them warm"]).
answer(number(8),part(b),subpart(0),[86,	0	,"The mothers milk comes out of the mother polar bear at body temperature and the milk also has chemicals in it to increase the babies imun system"]).
answer(number(8),part(b),subpart(0),[87,	0	,"They are able to store the milk which can be kept warm by them until they need it."]).
answer(number(8),part(b),subpart(0),[88,	1	,"The body has a constant temperature (37�C) the milk will be at this temperature and therefore will then give the heat to the baby."]).
answer(number(8),part(b),subpart(0),[89,	0	,"The polar bears are warm and the milk is coming from the body when the baby polar bears drink the milk they get more energy which keeps the blood flowing keeping them warm."]).
answer(number(8),part(b),subpart(0),[90,	1	,"The milk would have been kept warm inside the mother because of the thick layers of fat on the polar bears."]).
answer(number(8),part(b),subpart(0),[91,	1	,"The milk is already warm because it has been insulated by layers of fat on the mother bear. The milk warms up the baby once it is inside it."]).
answer(number(8),part(b),subpart(0),[92,	0	,"Babies are smaller so will have a larger surface area to volume ratio.  This means they loose heat quickly compared to an adult.  They will use their moters milk to warm themselves up as it will be easy to digest so energy can be obtained from it easily and quickly."]).
answer(number(8),part(b),subpart(0),[93,	0	,"The milk contains protein and calcium and they feed."]).
answer(number(8),part(b),subpart(0),[94,	1	,"the temperature of the mothers heat will increase the temperature of the milk so the baby bears get warm milk which will heat them up."]).
answer(number(8),part(b),subpart(0),[95,noanswer]).
answer(number(8),part(b),subpart(0),[96,noanswer]).
answer(number(8),part(b),subpart(0),[97,	2	,"The milk produced is warm and in the baby polar bear's body it is used to make energy which heats up the body."]).
answer(number(8),part(b),subpart(0),[98,	1	,"The mother's milk is already warmed by her own body temperature.  Baby bears do not have thick fur or blubber and so need warm milk to compensate."]).
answer(number(8),part(b),subpart(0),[99,	1	,"The milk is warmed up by the mother and passed on to the baby. The baby then drinks the milk and it flows all the way through their body through their digestive system. This warms up their inside and the heat radiates to the other organs in their body warming them up."]).
answer(number(8),part(b),subpart(0),[100,	1	,"When baby polar bears drink their mother's milk, it is warm.  Layers of fat beneath their thick fur allow their bodies to remain warm thus keeping the milk warm - while it is in their bodies, it maintains their body temperature."]).
answer(number(8),part(b),subpart(0),[101,	1	,"Because their mothers milk will have been inside the body so will be warm when the baby drinks it. This heat will be passed to the baby therefore helping it stay warm."]).
answer(number(8),part(b),subpart(0),[102,	2	,"By then drinking the milk Which warms them up and makes the fat so it can be insulated in the winter"]).
answer(number(8),part(b),subpart(0),[103,	0	,"The mothers milk will keep them warm because when they are born, they are born without hair."]).
answer(number(8),part(b),subpart(0),[104,	1	,"the energy and nutrients from their mothers milk help them to metabolise properly and fat from the milk can be stored in an insulating layer of blubber."]).
answer(number(8),part(b),subpart(0),[105,	0	,"Babies make an enzyme called Renin which makes milk solid so that it can stay longer in their bodies. This would enable them to produce more energy from it so it would keep them warm."]).
answer(number(8),part(b),subpart(0),[106,	1	,"Young polar bears would become cold quickly due to not being fully developed.  Their mothers milk being warm helps to keep their body Temperature warm enough to survive until their older."]).
answer(number(8),part(b),subpart(0),[107,	0	,"because it gives them energy"]).
answer(number(8),part(b),subpart(0),[108,	1	,"Mammals have milk which comes at body temperature so when it enters the body it is already warm, and then flows around their body, warming them all over."]).
answer(number(8),part(b),subpart(0),[109,	1	,"the milk is inside the polar bears body and so gets warm, this heat is then transferred to the baby when they drink it."]).
answer(number(8),part(b),subpart(0),[110,	1	,"They can digest the glucose from the milk and convert it into the heat energy through respiration."]).
answer(number(8),part(b),subpart(0),[111,	0	,"From milk you can get energy and this energy will keep them warm"]).
answer(number(8),part(b),subpart(0),[112,	1	,"The mothers milk as been insulated by layers of fat & fur so remains warm this heat is transferred into cubs (baby polar bears) when they swallow it warming the inards."]).
answer(number(8),part(b),subpart(0),[113,	0	,"It helps insulation."]).
answer(number(8),part(b),subpart(0),[114,	1	,"The milk from the mother is warm because it is at her body temperature so when the baby drinks the milk the baby absorbs the heat."]).
answer(number(8),part(b),subpart(0),[115,	1	,"Because it is stored in the mother polar bear at a warm temperature and therefore the baby will retrieve it and it will warm up the baby.  It will also help the baby grow and have strong bones and teeth and give thick fur."]).
answer(number(8),part(b),subpart(0),[116,	1	,"This is because the milk is stored inside the polar bear - at the higher body temp of the bear. When the baby drinks this liquid the energy in the milk is transferred to the body - this energy is in the form of heat."]).
answer(number(8),part(b),subpart(0),[117,	0	,"As babies have milk in order for bones to grow, as they drink milk their fur grows to keep them warm"]).
answer(number(8),part(b),subpart(0),[118,	2	,"As the milk is from inside the mother's body it will be warmed by the mothers body heat, when the baby bear drinks it, it will become warm. Also the milk is very high in fat, meaning that the baby will become fat, the fat helps to insulate the babies body keeping it warm."]).
answer(number(8),part(b),subpart(0),[119,	1	,"The mothers milk that is produced is warm and by drinking it the baby can heat itself from the inside."]).
answer(number(8),part(b),subpart(0),[120,	1	,"The warm milk of the mother keep it warm because it stimulates the body causing it to warm up."]).
answer(number(8),part(b),subpart(0),[121,	2	,"Milk contains fat and is warm: due to it coming from the mother. the fat is stored up in the baby which helps to insulate it."]).
answer(number(8),part(b),subpart(0),[122,	1	,"The baby polar bear will suck the milk from its mother. The milk will be warm because it has come from the mothers body which is warm due to all of the metabolic activity in her."]).
answer(number(8),part(b),subpart(0),[123,noanswer]).
answer(number(8),part(b),subpart(0),[124,	2	,"The milk is physically warm which warms the bear up but also the fat and energy in the milk goes to insulating and creating heat for the bear."]).
answer(number(8),part(b),subpart(0),[125,	2	,"Milk contains lots of fat, as the baby polar bears drink their mother's milk, the fat is stored as blubber in the adipose tissue.  The fat reduces heat loss from the polar bear and insulates the polar bear from the cold."]).
answer(number(8),part(b),subpart(0),[126,noanswer]).
answer(number(8),part(b),subpart(0),[127,	0	,"Baby polar bears use the milk as energy this keeps the bears warm as it is food for the muscles this allows the muscles to contract to keep the bear warm"]).
answer(number(8),part(b),subpart(0),[128,	0	,"The milk contains all the natural nutrients, vitamins proteins etc. that the baby needs to help it own body keep it warm."]).
answer(number(8),part(b),subpart(0),[129,	0	,"The milk has proteins and carbohytes in and is also warm when it comes from the mother which provides them with heat"]).
answer(number(8),part(b),subpart(0),[130,	1	,"Milk is produced inside the mother.  Inside the mother it is warm i.e. bloodstream and organs.  As the milk is passed on to the baby it is warmer than the cold air outside and therefore warms the insides of the baby."]).
answer(number(8),part(b),subpart(0),[131,	1	,"The inside of a polar bear is warm and so is the milk, however if the baby polar bear drank from somewhere else it would be too cold for it too handle as it is still young."]).
answer(number(8),part(b),subpart(0),[132,noanswer]).
answer(number(8),part(b),subpart(0),[133,	1	,"The mother passes her milk to her children. The milk is stored in her body which is larger and has more fur so she is warmer this heat is passed through the milk to the children."]).
answer(number(8),part(b),subpart(0),[134,	0	,"the mothers milk contains proteins which are used for the growth of fat cells to insulate them and keep them warm."]).
answer(number(8),part(b),subpart(0),[135,	1	,"Baby polar bears do not produce as much hair / fur as large fully grown polar bears when they are born. So they keep warm by drinking their mother's milk which is also warm because it came from the mother bear which has more fur."]).
answer(number(8),part(b),subpart(0),[136,noanswer]).
answer(number(8),part(b),subpart(0),[137,	0	,"Their mothers milk warms them up, because in their digestion system, energy is being used up, so heat it produced, warming the young polar bear"]).
answer(number(8),part(b),subpart(0),[138,noanswer]).
answer(number(8),part(b),subpart(0),[139,	1	,"the milk is from inside the mothers body. Inside the body the temperature should be about 37�C roughly so the milk should be warm."]).
answer(number(8),part(b),subpart(0),[140,	0	,"This would be the only source of food, and as the polar bears keep themselves warm due to certain features, their contents will also be warm."]).
answer(number(8),part(b),subpart(0),[141,	1	,"The inside (internal) of an animal is much warmer than outside. The milk inside the mother warms up because of this. When the baby drinks it the heat is transfered to the baby because the milk is warm."]).
answer(number(8),part(b),subpart(0),[142,	1	,"Because of their thick skin the milk is warm.  So when the baby drinks it and it goes into her digestive system and heats it up from the inside"]).
answer(number(8),part(b),subpart(0),[143,	1	,"There mothers milk will be fairley warm from the mothers internal temperature. When the baby drinks the mothers milk it can also heat the baby up internally."]).
answer(number(8),part(b),subpart(0),[144,	1	,"The mothers milk will be warm because of the mothers body heat. The milk will be digested and move through all parts of the baby bear so that the whole of the baby bear gets warm."]).
answer(number(8),part(b),subpart(0),[145,	2	,"The mother's milk will contain energy, which the baby polar bear can then use as heat energy to keep warm. It also contains sugars, which the baby polar bear can use in respiration."]).
answer(number(8),part(b),subpart(0),[146,	0	,"It alls liquid into it body so this keep them warm because it does not have to lose an liquid."]).
answer(number(8),part(b),subpart(0),[147,	1	,"The mothers milk has been inside her so it is warm. This warmth is passed to the baby so that it keeps warm."]).
answer(number(8),part(b),subpart(0),[148,	1	,"They feed off their mother, the mother has high insulation from her fur so the milk the baby drinks has been kept warm, it then when transfered into the baby keeps it warm."]).
answer(number(8),part(b),subpart(0),[149,	0	,"Their mothers milk contains energy created by respiration. The bear absorbs some of this energy to keep warm."]).
answer(number(8),part(b),subpart(0),[150,	1	,"Liquid conducts heat.  The milk inside the mother will be warm, since the mother will be. The milk drunk by the babys will be taken into their body the heat will then be inside the baby and diffuse out"]).
answer(number(8),part(b),subpart(0),[151,	1	,"The mother polar bear is warm inside due to all the fur the milk would be warm for the baby bear. Also, the mothers milk is also adapted to feed the baby bear."]).
answer(number(8),part(b),subpart(0),[152,	1	,"The milk helps them to build up their layer of fat which keeps them warm and provides insulation."]).
answer(number(8),part(b),subpart(0),[153,	0	,"The blood from the mother will be warm so when the drink it, the milk flows round their body in their bloodstream so it keeps them warm."]).
answer(number(8),part(b),subpart(0),[154,	2	,"Milk is very fatty.  This helps to increase the amount of fat in the baby polar bears body.  The fat acts as insulin."]).
answer(number(8),part(b),subpart(0),[155,	0	,"Because this is a form of food which can be turned into energy which can then be transformed in to heat hence keeping the baby polar bears warm."]).
answer(number(8),part(b),subpart(0),[156,	1	,"The baby polar bears don't have much fur on them and there mothers milk has been kept warm by the body heat the mother produces."]).
answer(number(8),part(b),subpart(0),[157,	1	,"The mothers milk is warm whitch therefore warms up the baby polar bears as the mothers milk is kept warm but the insulation of the polar bears hair."]).
answer(number(8),part(b),subpart(0),[158,	1	,"Baby polar bears drink their mother's milk-.  part of which is converted into blubber-.  polar bears use this layer of blubber for insulation"]).
answer(number(8),part(b),subpart(0),[159,	0	,"energy from mothers tissue goes into the milk which she then gives to her young.  The energy transfered from the milk into young baby's tissues/cells"]).
answer(number(8),part(b),subpart(0),[160,	1	,"this milk is a fat and so keeps them warm when they drink it. Also the milk is from the mother so it is warmed up from her."]).
answer(number(8),part(b),subpart(0),[161,	1	,"Inside the mother all its organs are warm so it would keep all inside warm and its milk is warm because all the mechanisms are warm aroun."]).
answer(number(8),part(b),subpart(0),[162,	0	,"Baby polar bears use their mothers milk to keep them warm by circulating around the body and warming the blood stream."]).
answer(number(8),part(b),subpart(0),[163,	0	,"The milk comes from the mother's body, so will be at the mother's body temperature. It also contains vital nutrients to help them build up layers of fat."]).
answer(number(8),part(b),subpart(0),[164,	2	,"Milk contains fat. It is a very good energy source and when the bear is inactive unused energy can be stored as fat. This keeps the baby warm."]).
answer(number(8),part(b),subpart(0),[165,noanswer]).
answer(number(8),part(b),subpart(0),[166,	0	,"The milk is well insulated in the polar bear because of the fur and when the milk  it is fed to the Child, it keeps them warm because at birth, baby polar bears don't have much fur "]).
answer(number(8),part(b),subpart(0),[167,	0	,"Because milk contains protein which is used to produce energy and energy is what the polar bear uses to keep warm."]).
answer(number(8),part(b),subpart(0),[168,	0	,"In milk their are many vital ingredients which help the baby polar bear. Calcium is one which helps the blood circulate better and make it's bone stronger enabling it too keep warmer."]).
answer(number(8),part(b),subpart(0),[169,	1	,"The milk that the mother has produced would be at exactly the right temperature the same temperature as the mother's body which would be slightly higher than the baby as she is bigger so it will be warm for the baby."]).
answer(number(8),part(b),subpart(0),[170,noanswer]).
answer(number(8),part(b),subpart(0),[171,	0	,"The mother's milk would contain energy from it's nutrients that with help from enzymes would produce energy for the baby polar bear > some would be given off by heat energy but trapped by fur > keep the polar bear warm."]).
answer(number(8),part(b),subpart(0),[172,	0	,"Liquids and solids act as insulators. The insulator will keep their body heat in, preventing them from feeling cold."]).
answer(number(8),part(b),subpart(0),[173,	1	,"the mother's milk is kept warm inside it's body so when the baby recieves it it is warm an keeps it warm."]).
answer(number(8),part(b),subpart(0),[174,	1	,"They store the milk as fat under the skin to have an insulation layer to keep warm."]).
answer(number(8),part(b),subpart(0),[175,	0	,"The mother's milk is naturally warm because of the energy, so when the baby polar bear suckles, it will become warmer, and because of its small surface area and thick skin it will, only slowly, lose the heat."]).
answer(number(8),part(b),subpart(0),[176,	0	,"the milk is food for the baby polar bears.  Also the obtaining of the mother's milk requires movement, producing heat."]).
answer(number(8),part(b),subpart(0),[177,	1	,"They absorb the nutritional contents of the milk, such as starch, glucose and proteins and fats. They break it down to form energy as glucose and aerobically respirate which creates heat."]).
answer(number(8),part(b),subpart(0),[178,	2	,"The milk is fatty so produces fat layers underneath the skin and is at body temperature of the mother."]).
answer(number(8),part(b),subpart(0),[179,	1	,"When it is feeding it is very close to its mother so there fur keeps warm through body heat and the milk is warm because it has just come out of the mothers Body."]).
answer(number(8),part(b),subpart(0),[180,	2	,"They drink the milk it is probably quite creamy + fatty so will help them build up a layer of insulation. Also it will be warm when they drink it so it'll warm them that way"]).
answer(number(8),part(b),subpart(0),[181,noanswer]).
answer(number(8),part(b),subpart(0),[182,	1	,"Because mummies are warm blooded the bodies are warm too so the milk from the mother would be warm, therefore keeping the body warm."]).
answer(number(8),part(b),subpart(0),[183,	1	,"Baby polar bears are smaller and have less fat to keep them warm compared to an adult polar bear. The mothers milk will be at her body temp. 37�  so it will warm up the baby polar bear."]).
answer(number(8),part(b),subpart(0),[184,	0	,"The mothers milk keeps the baby warm by giving it all the nutrients and minerals it needs to be healthy and providing it with insulation."]).
answer(number(8),part(b),subpart(0),[185,	1	,"because the milk is keep warm because here body temperatues kept high by the fur coat so the mothers milk is passed to the baby to keep it warm"]).
answer(number(8),part(b),subpart(0),[186,	1	,"This is because the baby bears cant feed on their own so they spend most of their time feeding from the mother so it doesn't get enough sunlight to keep it at the appropriate temperate whereas the mothers body heat warms up the milk for the cub."]).
answer(number(8),part(b),subpart(0),[187,	0	,"Mother may breast feed baby covered with thick coat of hair"]).
answer(number(8),part(b),subpart(0),[188,	1	,"The milk will be from inside the mother so will be warm this will be passed to the baby."]).
answer(number(8),part(b),subpart(0),[189,	0	,"The milk contains starch and other nutrients the baby needs. It can convert starch into glucose to use in respiration for releasing energy for heat."]).
answer(number(8),part(b),subpart(0),[190,	1	,"The body temperature is higher than the temperature outside so the milk is warm and the heat transfers to the baby polar bear."]).
answer(number(8),part(b),subpart(0),[191,	1	,"This is their only form of nutrition it keeps them warm because the milk, derived from the mammary glands of the mother is heated from the internal body heat as polar bears (mamals) are warm blooded. This heat from the mothers body is then transfered to the young."]).
answer(number(8),part(b),subpart(0),[192,noanswer]).
answer(number(8),part(b),subpart(0),[193,	0	,"The milk that is inside the larger polar will be warm as it acts as a convection current inside the body, which is then transferred to the baby polar bear."]).
answer(number(8),part(b),subpart(0),[194,	1	,"The milk the baby polar bears drink is digested and then the glucose goes to the cells where respiration takes place, this gives off heat which the polar bears use to keep themselves warm."]).
answer(number(8),part(b),subpart(0),[195,	1	,"Since the mothers milk is warm to start of with it travels down to the small intestine and then the energy here is transferred into the blood cells in the body."]).
answer(number(8),part(b),subpart(0),[196,	0	,"the milk is absorbed into the blood via the small intestine after digestion and the chemical energy from the food is connected  to thermal energy in the body."]).
answer(number(8),part(b),subpart(0),[197,noanswer]).
answer(number(8),part(b),subpart(0),[198,	0	,"the milk gives the polar bear energy to warm itself."]).
answer(number(8),part(b),subpart(0),[199,	1	,"The milk inside the mother is warm which when drunk by the baby is then helped to keep the bear warm.	"]).
answer(number(8),part(b),subpart(0),[200,	1	,"The mothers milk has been made and stored inside of her so it will be warm. When the baby polar bears drink it it warms their insides.	"]).
answer(number(8),part(b),subpart(0),[201,	1	,"The mothers milk will be warm so as it enters the baby it will warm him up."]).
answer(number(8),part(b),subpart(0),[202,	1	,"It comes from the inside of it's mother which is kept warm by fur and skin.  The milk also gives the baby nutrients and energy to run around, and this results in increased temperature"]).
answer(number(8),part(b),subpart(0),[203,	1	,"As the polar bear is a mammal, the baby feeds through its mother teat. The body of polar bear's are warm (37� ) and therefore the milk coming out of the mother is warm for the baby"]).
