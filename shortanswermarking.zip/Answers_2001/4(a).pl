:- multifile answer/4.

answer(number(4),part(a),subpart(0),[1,0	,"Plants do it by pollian and seed's "]).
answer(number(4),part(a),subpart(0),[2,1	,"It only has one plant and sexual has two. It grows from a bulb "]).
answer(number(4),part(a),subpart(0),[3,0	,"Plants have seeds which get scattered around by birds or wind. "]).
answer(number(4),part(a),subpart(0),[4,1	,"asexual reproduction means that the plant does not need to be fertilised by the pollen of a different plant because it fertilises itself. asexual plants contain both sexual organs rather than just one. "]).
answer(number(4),part(a),subpart(0),[5,0	,"* asexual reproduction is used for cell devision (mitosis) * asexual reproduction uses chemical products where as sexual reproduction is more natural "]).
answer(number(4),part(a),subpart(0),[6,0	,"Sexual reproduction is to do with humans and asexual is to do with plants "]).
answer(number(4),part(a),subpart(0),[7,2	,"to produce asexualy you only need one parent. the offspring are exactly the same as the parent.  "]).
answer(number(4),part(a),subpart(0),[8,1	,"It does it alone without the other sex. It stay joined with the plant. "]).
answer(number(4),part(a),subpart(0),[9,noanswer]).
answer(number(4),part(a),subpart(0),[10, 2	,"Asexual plants are identical from the plant they came from and sexual reproduction they are not. You only need one plant for asexual you need two for sexual reproduction "]).
answer(number(4),part(a),subpart(0),[11,2	,"There is only one parent (of type / sex). All off-spring are genetically identical "]).
answer(number(4),part(a),subpart(0),[12,0	,"The plant has both male and female productive systems to produce off spring.  the off spring grows on the side of the plant which can later be potted seperately  "]).
answer(number(4),part(a),subpart(0),[13,noanswer]).
answer(number(4),part(a),subpart(0),[14,2	,"the plant made asexually is identical to its parent. "]).
answer(number(4),part(a),subpart(0),[15,1	,"asexual reproduction in plants grow two of the same eg clones of the actual plant this is what is different from sexual reproduction. "]).
answer(number(4),part(a),subpart(0),[16,0	,"They don't have sex. The polen moves from plant to plant. "]).
answer(number(4),part(a),subpart(0),[17,2	,"Asexual reproduction makes an identical replica of itself it only needs one to reproduce rather than needing two sets of eggs.  "]).
answer(number(4),part(a),subpart(0),[18,1	,"asexual reproductive plants is that they have both male and female parts, therefore can make new plants themselves. "]).
answer(number(4),part(a),subpart(0),[19,0	,"In asexual reproduction it doesn't matter about the sex eg. m / f. The plant dosen't decide when it just happens. "]).
answer(number(4),part(a),subpart(0),[20,0	,"Asexual means the plant can reproduct by its self. It only needs the pollun / seeds from that plant to reproduct. "]).
answer(number(4),part(a),subpart(0),[21,2	,"Asexual reproduction involved only one plant. The genetics of the new plant will be identical to the ones of its parent it is a clone. "]).
answer(number(4),part(a),subpart(0),[22,0	,"Plants can reproduce by themselves plants can produce lots of offspring "]).
answer(number(4),part(a),subpart(0),[23,0	,"When plants reproduce, they do not come in contact with each other. "]).
answer(number(4),part(a),subpart(0),[24,noanswer]).
answer(number(4),part(a),subpart(0),[25,1	,"you dont need two plants its just another part growing differently "]).
answer(number(4),part(a),subpart(0),[26,0	,"they have both male and female parts and also "]).
answer(number(4),part(a),subpart(0),[27,0	,"The 'young' are produced on the 'mother'. They do not need to sexually reproduce like humans and Animals there seed is transported either by wind or animal etc. "]).
answer(number(4),part(a),subpart(0),[28,0	,"They produce their own seed through self fertilisation "]).
answer(number(4),part(a),subpart(0),[29,2	,"Asexual reproduction only involves one parent. The offspring is exactly the same as the parent. "]).
answer(number(4),part(a),subpart(0),[30,noanswer]).
answer(number(4),part(a),subpart(0),[31,0	,"They don't have to have intercourse for reproduction to happen, like humans have too. "]).
answer(number(4),part(a),subpart(0),[32,0	,"The grow move faster and quicker and they are larger and more bigger "]).
answer(number(4),part(a),subpart(0),[33,0	,"Sexual reproduction to reproduce  "]).
answer(number(4),part(a),subpart(0),[34,0	,"plants need sun and water to make sexual reproduction and if we different have plants people wouldn't be alive because they give of certain gasses they need to live on"]).
answer(number(4),part(a),subpart(0),[35,0	,"In plants the pollen from the flower blows away causing a new plant to grow. It could also be when wasps or bees take it and drop it somewhere "]).
answer(number(4),part(a),subpart(0),[36,1	,"it doesn't need another plant to reproduce sell polonates"]).
answer(number(4),part(a),subpart(0),[37,2	,"Asexual reproduction has come from only one plant and sexual reproduct has two. The plant produced by asexual reproduction will look identical to the one it has come from (unless it gets a desease)"]).
answer(number(4),part(a),subpart(0),[38,noanswer]).
answer(number(4),part(a),subpart(0),[39,0	,"They make food and then they have new leaves growing out of the inside of the plant."]).
answer(number(4),part(a),subpart(0),[40,1	,"Asexual reproduction will grow identical plants from itself. The plant will also have same problem as the mother plants such as the state it is in know "]).
answer(number(4),part(a),subpart(0),[41,0	,"asexual reproduction, the plant impregnates itself, and therefore will not need to rely on the pollen of other plants. Sucklings are made, which will then grow into bigger plants"]).
answer(number(4),part(a),subpart(0),[42,1	,"It is done by one plant and not by two working together."]).
answer(number(4),part(a),subpart(0),[43,0	,"asexual reproduction in plants is all about the seeds. When the plant has died the seeds move in the air and plant themselves in a different area. They are not pollenated. "]).
answer(number(4),part(a),subpart(0),[44,0	,"it asexual in to a big or small plant. Water and sunlight help's it grow and live."]).
answer(number(4),part(a),subpart(0),[45,0	,"When there is 1 plant and 1 vegetable  
"]).
answer(number(4),part(a),subpart(0),[46,noanswer]).
answer(number(4),part(a),subpart(0),[47,0	,"Asexual reproduction in plants is that they can produce more leaves or flowers without sex, and they can grow in different seasons e.g daisies, weeds, grass etc. "]).
answer(number(4),part(a),subpart(0),[48,0	,"asexual reproduction is when the set is not due as for sexual reproduction take place"]).
answer(number(4),part(a),subpart(0),[49,0	,"It isn't colour and shade that the people want it to be, + it is'nt the size and shape they would like it, as they won't know"]).
answer(number(4),part(a),subpart(0),[50,0	,"plants reproduction is when they spread the seed every week."]).
answer(number(4),part(a),subpart(0),[51,0	,"Asexual plant is freshly seeded"]).
answer(number(4),part(a),subpart(0),[52,noanswer]).
answer(number(4),part(a),subpart(0),[53,1	,"Only one plant is needed, and the offspring is grown out of the original plant"]).
answer(number(4),part(a),subpart(0),[54,0	,"there is not no sexualing "]).
answer(number(4),part(a),subpart(0),[55,noanswer]).
answer(number(4),part(a),subpart(0),[56,noanswer]).
answer(number(4),part(a),subpart(0),[57,0	,"Asexual reproduction in plants is not done by photosynthesis. And it is not done naturally like sexual reproduction."]).
answer(number(4),part(a),subpart(0),[58,noanswer]).
answer(number(4),part(a),subpart(0),[59,0	,"The plants can get blown by the wind and burried to make more or they can get droopy and drop to the floor to make more which is different because there is only one way for humans."]).
answer(number(4),part(a),subpart(0),[60,0	,"they drop there seads and are blown to different places by wind. plant have both male and female systems"]).
answer(number(4),part(a),subpart(0),[61,0	,"Asexual reproduction takes part by the wind or by an insect transfering pollen to another plant and asexual reproduction shows a plant growing on the side or apart from the other plant"]).
answer(number(4),part(a),subpart(0),[62,0	,"asexual reproduction is where the plant is the man and the women. It does not take weeks for the offspring to become a living thing it happens fairly quickly."]).
answer(number(4),part(a),subpart(0),[63,	1	,"Asexual reproduction can be with one parent. Asexual reproduction doesn't require movement of the plant.  
"]).
answer(number(4),part(a),subpart(0),[64,	0	,"they can firtalize by themself "]).
answer(number(4),part(a),subpart(0),[65,1	,"asexual reproduction only needs one parent and there is no intercourse during asexual reproduction."]).
answer(number(4),part(a),subpart(0),[66,0	,"Asexual reproduction is different from sexual reproduction it is reproducing itself without another plant, to help it. "]).
answer(number(4),part(a),subpart(0),[67,0	,"The plant does not need anything to grow it's new plant because it comes off the main stem so the plant can keep reproducing without the need of seeds. "]).
answer(number(4),part(a),subpart(0),[68,2	,"You only need one plant for asexual reproduction. The plant produced has identical genetic make-up to its parent."]).
answer(number(4),part(a),subpart(0),[69,0	,"They grow more plants next to them when they get anougth sunlight, oxygen, food and water. "]).
answer(number(4),part(a),subpart(0),[70,0	,"Asexual reproduction can only be done by one thing whereas sexual reproduction needs two"]).
answer(number(4),part(a),subpart(0),[71,0	,"They only have to touch, or take cuttings"]).
answer(number(4),part(a),subpart(0),[72,0	,"It grows root give's it water let sun shine on it to give it oxygen."]).
answer(number(4),part(a),subpart(0),[73,1	,"asexual reproduction is the use of oxygen in plants. Asexual reproduction also only happens in one plant where sexual reproduction needs two living organisms. "]).
answer(number(4),part(a),subpart(0),[74,1	,"Asexual reproduction have no gamotes and no fertilisation, which in sexual reproduction, you have fertilisation and gemotes."]).
answer(number(4),part(a),subpart(0),[75,0	,"you don't need to plants to make a new one grow, there is no pregnancy. "]).
answer(number(4),part(a),subpart(0),[76,1	,"With asexual plants if you tear apart it will grow back and They reproduce on their own "]).
answer(number(4),part(a),subpart(0),[77,0	,"the plants have both male and female parts, polon and stigma, cuttings can be taken and the plant will grow."]).
answer(number(4),part(a),subpart(0),[78,0	,"the young plant stays atached to the main plant to make a larger plant. Also they do not detach from the main plant"]).
answer(number(4),part(a),subpart(0),[79, 0	,"Asexual reproduction is different because the plants can died easy."]).
answer(number(4),part(a),subpart(0),[80,	0	,"The sexual way you do not have to feed it water to keep it alive and to have more plants it does not have to be with another plant."]).
answer(number(4),part(a),subpart(0),[81,noanswer]).
answer(number(4),part(a),subpart(0),[82,	0	,"asexual doesn't require any pollen to reproduce unlike sexual reproduction the new growth is still part of the old plant in asexual unlike where there is a whole new plant."]).
answer(number(4),part(a),subpart(0),[83,noanswer]).
answer(number(4),part(a),subpart(0),[84,1	,"A plant that can reproduce Asexually doesn't need a 'mate', and also, the offspring grows on the plant, rather than on its own."]).
answer(number(4),part(a),subpart(0),[85,0	,"Asexual reproduction is used if you want to regrow parts of a leave, but sexual reproduction is used in another form like this."]).
answer(number(4),part(a),subpart(0),[86,0	,"because one plant can be a female and another plant could be a male so they make toggether."]).
answer(number(4),part(a),subpart(0),[87, 2	,"In asexual reproduction you only need one parent, to do it. And also genes are only taken into account from that parent."]).
answer(number(4),part(a),subpart(0),[88,	2	,"Asexual reproduction only involves one parent and the plant which developes from asexual reproduction is an exact replica of its parent."]).
answer(number(4),part(a),subpart(0),[89,2 ,"The offspring (baby plant) is identical to parent only one parent is needed. "]).
answer(number(4),part(a),subpart(0),[90,0	," There is no actual physical contact. Plants need something to transport the plants seed around.  
"]).
answer(number(4),part(a),subpart(0),[91,0	,"they are always conected to the plant look simulur to the plant connected  
"]).
answer(number(4),part(a),subpart(0),[92,0	," The flower can reproduce by itself The flower has both sex organs"]).
answer(number(4),part(a),subpart(0),[93,0	,"The plant can reproduce without even touching another. The plant has male & female parts to it."]).
answer(number(4),part(a),subpart(0),[94,2	,"there does not have to be 2 parents there can be one parent and exact copies of that parent can be made identical."]).
answer(number(4),part(a),subpart(0),[95,0 ,"	the plants are pollinated by bees and other insects. The wind blows seeds and bits of the plant over to another plant and then it starts to grow again "]).
answer(number(4),part(a),subpart(0),[96,0	," asexual reproduction means something has two sex cells male and female so it can reproduct on it's own "]).
answer(number(4),part(a),subpart(0),[97,2	,"They reproduce by themself. The offspring will be identical to the parent. In sexual reproduction two organisms are needed and the offspring will not be identical to the original organisms."]).
answer(number(4),part(a),subpart(0),[98,0	,"It happens naturally and you can't prevent it."]).
answer(number(4),part(a),subpart(0),[99,2	,"Only one parent (one producer) in asexual reproduction. Sexual reproduction has 2 producers produces identical offspring. Sexual reproduction does'nt produce identical offspring. "]).
answer(number(4),part(a),subpart(0),[100,1	,"Gametes are not involved. The plants don't come in contact with other plants like humans have to "]).
answer(number(4),part(a),subpart(0),[101,1	,"Photosynethsis. The plant does it on its own weather it's male or female "]).
answer(number(4),part(a),subpart(0),[102,noanswer]).
answer(number(4),part(a),subpart(0),[103,noanswer]).
answer(number(4),part(a),subpart(0),[104,noanswer]).
answer(number(4),part(a),subpart(0),[105, 0	,"In a sexual reproduction the seed of the plant doesn't reproduct and plant with a bed and it doesn't fall off"]).
answer(number(4),part(a),subpart(0),[106,2	,"Asexual reproduction is were there is only one plant and that the plant produced a clone"]).
answer(number(4),part(a),subpart(0),[107, 0	,"Plants don't have intercourse and don't actually go inside one another, and they get put together to reproduce, whereas in sexual reproduction you choose to."]).
answer(number(4),part(a),subpart(0),[108,1	," When using Asexual reproduction you get an exact copy for example using the plant at the top, when the other plant is fully grown it will be exactly the same as the first plant"]).
answer(number(4),part(a),subpart(0),[109,0	," Asexual reproduction does not need a male or female part in order to be fertilised. As it can fertilise itself."]).
answer(number(4),part(a),subpart(0),[110,0	," The top of the right one opens up to let rain in And it can grow a lot bigger"]).
answer(number(4),part(a),subpart(0),[111,0	," plants have babies but not the sex its the roots"]).
answer(number(4),part(a),subpart(0),[112,noanswer]).
answer(number(4),part(a),subpart(0),[113, 0	,"They haven't got no sperm to make baby and haven't got the organs of a humans sexual organs."]).
answer(number(4),part(a),subpart(0),[114,noanswer]).
answer(number(4),part(a),subpart(0),[115,0	,"plants reproduce by the stem of the plant."]).
answer(number(4),part(a),subpart(0),[116,0	,"The plants dont make phisical contact and plants use other lifeforms to reproduct."]).
answer(number(4),part(a),subpart(0),[117,0	," A asexua reproduction in plants is when the one plant makes and fertilises its seads, and so each of its offspring are identical to the parent and so no vareatcon occours, in sexual reproduction the plant needs to cross polinate with another to firtilise its seads, and so variation takes place from two diffrent plants, so no ofspring is identiced to the parent"]).
answer(number(4),part(a),subpart(0),[118,1	," plants reproduce on there own without help. No fertilization is need in the plant. "]).
answer(number(4),part(a),subpart(0),[119,0	," asexual reproduction this is when the plant grows down to the floor and runs away to start of somewhere else both plants will stay atach this takes place in strewberres."]).
answer(number(4),part(a),subpart(0),[120, 0	,"Asexual reproduction occurs when insects carry things from one plant to another. The plants do not actually come into contact with each other."]).
answer(number(4),part(a),subpart(0),[121,1	,"Its not biological and can be done at anytime"]).
answer(number(4),part(a),subpart(0),[122,0	,"because it is no fun and takes time, and"]).
answer(number(4),part(a),subpart(0),[123,0	," Asexual reproduction is when the plants grow new stems, branches or leaves and sexual reproduction is when you make new things e.g baby's"]).
answer(number(4),part(a),subpart(0),[124,0	,"Asexual reproduction just happens by growth from the roots where as sexual reproduction is physical needs sperm to fertilise an egg can cut the plant to make reproduction it's alot easier."]).
answer(number(4),part(a),subpart(0),[125,0	,"because it has a vacude and"]).
answer(number(4),part(a),subpart(0),[126,0	," They dont have to have sex they release a spread of pollen which is blown to the female not inserted."]).
answer(number(4),part(a),subpart(0),[127,0	,"The plants grow in a compleletly different way they have much thinner leaves and they take much longer to grow asexually as they do sexually - Use cloning to make more of the same kind"]).
answer(number(4),part(a),subpart(0),[128,1	,"The plants don't have to touch each other or have sexual intercourse for it to happen. One part grows for it to happen. One part grows another plant on it, two plants are not needed."]).
answer(number(4),part(a),subpart(0),[129, 1	,"It doesn't need to flower, it doesn't need pollen.  
"]).
answer(number(4),part(a),subpart(0),[130,0	," The plants do not need to touch in asexual but they do in sexual. Asexual is easier than sexual reproduction."]).
answer(number(4),part(a),subpart(0),[131,0	,"Asexual reproduction plants cannot reproduce again and again lik the other sexual plants. They also are weak and do die very quickly.  
"]).
answer(number(4),part(a),subpart(0),[132,noanswer]).
answer(number(4),part(a),subpart(0),[133,noanswer]).
answer(number(4),part(a),subpart(0),[134,0	,"asexual reproduction in plants makes the plants leep down and may die as well as it starts to smell"]).
answer(number(4),part(a),subpart(0),[135,0	,"When the seed fall out and go into the soil and then the seed start to grow again and again"]).
answer(number(4),part(a),subpart(0),[136,0	," asexual reproduction is more than one and it also make more food. It takes cutting in plants."]).
answer(number(4),part(a),subpart(0),[137, 0	," It is different because it does reproduce. It is also different because it keeps growing it self so theres no need for pollon or seed."]).
answer(number(4),part(a),subpart(0),[138,0	,"because in both of the plants you can't tell if it's a male's reproduction or female's reproduction. Not growing healthy / not enough sunlight."]).
answer(number(4),part(a),subpart(0),[139, 0	,"The plant doesn't lasts longer. easy to die."]).
answer(number(4),part(a),subpart(0),[140,noanswer]).
answer(number(4),part(a),subpart(0),[141,2	,"Asexual reproduction is were the new plant made is genetically identical to the original and it only needs the one plant's genetic material instead of two."]).
answer(number(4),part(a),subpart(0),[142,0	," They are not on alive (blossomed) and take longer to reproduct."]).
answer(number(4),part(a),subpart(0),[143,0	,"the plants reproduction organs are little stigma on the end of the buds and the birds and the bees carry the polen around and inpregnate on the plant."]).
answer(number(4),part(a),subpart(0),[144, 0	,"The plant reproducer asexually meaning it does not have to have sexual intercourse with another plant. A very similar or exact same grows beside the plant that reproduced."]).
answer(number(4),part(a),subpart(0),[145, 0	," taking cuting from a plant "]).
answer(number(4),part(a),subpart(0),[146,noanswer]).
answer(number(4),part(a),subpart(0),[147,0	," The stamen and stoma reproduct in plants which make it different from sexual reproduction "]).
answer(number(4),part(a),subpart(0),[148,0	," the plant are growing and when the sun is not their the fall down"]).
answer(number(4),part(a),subpart(0),[149, 0	," Asexual reproduction is were water comes in and the plant starts to reproduce  
"]).
answer(number(4),part(a),subpart(0),[150,noanswer]).
answer(number(4),part(a),subpart(0),[151,0	," The plant drops the seeds or the wind carrys the seed when it hits the ground the seed will grow."]).
answer(number(4),part(a),subpart(0),[152,0	,"  
asexual reproduction in plants is when things like photosynthesis take place and new leaves or flowers form it is different from sexual reproduction because the plants don't have any physical envolvement"]).
answer(number(4),part(a),subpart(0),[153,noanswer]).
answer(number(4),part(a),subpart(0),[154, 1 ,"	it produces the exact same thing and it produces the organs for asexual reproduction"]).
answer(number(4),part(a),subpart(0),[155, 0	," It does have flowers which stand upright. It does have many roots therefore does take in much water + minerals."]).
answer(number(4),part(a),subpart(0),[156,0	," they don't have a penis they dont make sperm."]).
answer(number(4),part(a),subpart(0),[157,0	," Asexual reproduction is different because you are just using a plant that is been alive before and you are not using a plant that is new. This way the same plant will always be used and nothing new will be grown."]).
answer(number(4),part(a),subpart(0),[158,noanswer]).
answer(number(4),part(a),subpart(0),[159,0	," Plants dont actually have sex. Plant dont get pregnant"]).
answer(number(4),part(a),subpart(0),[160,0	," The plants are cut, and are then able to grow faster."]).
answer(number(4),part(a),subpart(0),[161,0	," asexual reproduction is where plants take pollon from another plant this is how a plant can reproduction asexual reproduction no touching will be in volved. "]).
answer(number(4),part(a),subpart(0),[162,0	,"Asexual reproduction is when the plants either die and then new seeds grown or when seeds are 'popped' out of a bud onto the ground and new plants are grown."]).
answer(number(4),part(a),subpart(0),[163,0	,"They grow of food and"]).
answer(number(4),part(a),subpart(0),[164,0	,"asexual is were the plants let there own seeds out and taking cuttings"]).
answer(number(4),part(a),subpart(0),[165, 2	,"Asexual plant does not need to have any contact with another plant in order for it to become fertilized. Asexual plant produces copies of its self, the new plant are no different."]).
answer(number(4),part(a),subpart(0),[166, 0	,"It doesn't need to produce anything to go into the plant. It doesn't release eggs into it's body"]).
answer(number(4),part(a),subpart(0),[167,1	," the can reproduce by them selves also male asexual plants also reproduce."]).
answer(number(4),part(a),subpart(0),[168,noanswer]).
answer(number(4),part(a),subpart(0),[169, 2	,"there is only one parent. The parent fertilises the offspring itself. The offspring are toatly the same to the parents its a clone of the parent"]).
answer(number(4),part(a),subpart(0),[170,0	,"the sexual production have plants on them the asexual production has no leafs"]).
answer(number(4),part(a),subpart(0),[171,noanswer]).
answer(number(4),part(a),subpart(0),[172, 1	,"you don't need a male it will produce on its own don't produce an egg"]).
answer(number(4),part(a),subpart(0),[173,noanswer]).
answer(number(4),part(a),subpart(0),[174,noanswer]).
answer(number(4),part(a),subpart(0),[175, 0	,"If taking cutting, that means its a asexual reproduction in plants. it becomes apart."]).
answer(number(4),part(a),subpart(0),[176, 0	,"Asexual reproduction is completely different from sexual reproduction because they are both formed in different ways."]).
answer(number(4),part(a),subpart(0),[177, 0	,"They haven't got the parts of the body like any other human has"]).
answer(number(4),part(a),subpart(0),[178, 1	,"It can fertalize its self on it's own and it doesn't need another plant to fertalize it."]).
answer(number(4),part(a),subpart(0),[179, 0	,"Plants use pollon to reproduce This is carries by insects or by the wind. Seeds are produced which then grow, and reproduce. "]).
answer(number(4),part(a),subpart(0),[180, 0	,"1) the two living things don't have to physically touch one another. 2 ) asexual organisms don't have to care for the produced (offspring) feed etc keep warm "]).
answer(number(4),part(a),subpart(0),[181, 1	,"There is only one living oranism involved. There are no 'male' or 'female' parts."]).
answer(number(4),part(a),subpart(0),[182, 1	,"In sexual reproduction an egg has to be fertised & sperm has to actually enter the vagina. This does not happen in plants  
"]).
answer(number(4),part(a),subpart(0),[183,noanswer]).
answer(number(4),part(a),subpart(0),[184, 0	,"because it is netual for plants to asexual reproduction then it is for sexual reproduction plant's are different to people when it come's to it"]).
answer(number(4),part(a),subpart(0),[185,	0	,"It drops seeds so a nother plant can grow from that seed."]).
answer(number(4),part(a),subpart(0),[186, 2	,"Only one organism is used and the new plant is exactly the same as the old one it is a colone."]).
answer(number(4),part(a),subpart(0),[187,noanswer]).
answer(number(4),part(a),subpart(0),[188, 1	," Asexual reproduction only occurs with one parents (one off-spring) it doesn't have 2 parents / the thing that produced them but 1 "]).
answer(number(4),part(a),subpart(0),[189, 0 ," an asexual reproduction is different to a sexual reproduction because A- an asexual reproduction is dry and doesn't look in good condition. B-a sexual reproduction is fresh and is good condition.  
 "]).
answer(number(4),part(a),subpart(0),[190, 0 ," The plants do not have to actually make contact for fertilisation to take place. Plants are fitted with both male female parts   
"]).
answer(number(4),part(a),subpart(0),[191, 0	," Asexual reproduction can take place by taking a cutting or by branching of to form another plant. Sexual reproduction you cant !   
"]).
answer(number(4),part(a),subpart(0),[192, 1 ,"	Asexual reproduction only takes 1 living thing to produce it, were as sexual reproduction takes 2 living things. Asexual is a clone of something and is always the same and sexual reproduction will never turn out the same. "]).
answer(number(4),part(a),subpart(0),[193,	0 ,"	A plant can make of itself by itself it does not need anything from other plants/ animals "]).
answer(number(4),part(a),subpart(0),[194, 0 ,"	it can reproduct by itself "]).
answer(number(4),part(a),subpart(0),[195,noanswer]).
answer(number(4),part(a),subpart(0),[196, 0 ,"	The asexual one is more different to the sexual one because it looks more bender than the sexual plant is more healther. "]).
answer(number(4),part(a),subpart(0),[197, 0 ,"	taking cuttings, plant above have a little one just like the big plant thats asexual reproduction when they get bigger we cut them and plant them elsewhere. "]).
answer(number(4),part(a),subpart(0),[198, 	0 ,"	It is used to make smaller versions of the plant and only part of the plant is used to produce it "]).
answer(number(4),part(a),subpart(0),[199,noanswer]).
answer(number(4),part(a),subpart(0),[200, 0	,"They dont have intercourse. They are already preginated "]).
answer(number(4),part(a),subpart(0),[201, 1 ,"   
It can reproduce by itself, it doesn't need a partner. The product of asexual reproduction is not a certain sex. Where in sexual reproduction male and females are the products  
 "]).
answer(number(4),part(a),subpart(0),[202, 0  ," asexual reproduction is when a plant reproduces the same plant again but they are attatched together and it isn't separate from the origianal plant "]).
