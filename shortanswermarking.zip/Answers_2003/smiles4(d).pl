:- multifile answer/4.

answer(number(4),part(d),subpart(0),[1,2,"Producing human cell clones will be useful for people with incurrable diseases such as cancer, which can only be cured by receiving a healthy organ through transplant. "]).
answer(number(4),part(d),subpart(0),[1,2,"healthy organs (tissue) will always be available for transplant. "]).
answer(number(4),part(d),subpart(0),[2,1,"people disagree with this because they belive its playing God with some one life."]).
answer(number(4),part(d),subpart(0),[3,2,"make exact coppies of our blood incase a blood transfusion was needed "]).
answer(number(4),part(d),subpart(0),[4,2,"we can replace or damage cell with good ones that work "]).
answer(number(4),part(d),subpart(0),[4,2,"ethical problems because in the process alot of embroys are destroyed"]).
answer(number(4),part(d),subpart(0),[4,2,"process alot of embroys are destroyed"]).
answer(number(4),part(d),subpart(0),[5,1,"diseAses which cAn be cured by replAcing the infected cells. "]).
answer(number(4),part(d),subpart(0),[5,1,"Some people mAy object to this As they Are religious And believe thAt god should be the only one to creAte life."]).
answer(number(4),part(d),subpart(0),[6,3,"useful for organ transplants., "]).
answer(number(4),part(d),subpart(0),[6,3,"as the organ would be made from the cells of the recipient, there would be almost no risk of rejection. "]).
answer(number(4),part(d),subpart(0),[6,3,"However, some people object to this, as there are many moral issues involved. "]).
answer(number(4),part(d),subpart(0),[6,3,"Some may argue that it is wrong for scientists to 'play God'. "]).
answer(number(4),part(d),subpart(0),[6,3,"Others may be worried that this could allow the creation of things such as \'designer\' babies, or replacements for dead children, "]).
answer(number(4),part(d),subpart(0),[7,1,"believe that making another human by hand is not right, that is like saying they are good, they are messing with nature. And it is only god who can bring or take lifes, "]).
answer(number(4),part(d),subpart(0),[8,1,"Some people object to this process because they believe it is playing god and messing with nature."]).
answer(number(4),part(d),subpart(0),[9,1,". many people object due to ethical reasons "]).
answer(number(4),part(d),subpart(0),[10,2,"This may be useful if someone needs a transplant but has no matching doner. "]).
answer(number(4),part(d),subpart(0),[10,2,"People also think it is wrong to 'Play God' (so to speak)"]).
answer(number(4),part(d),subpart(0),[11,1,""]).
answer(number(4),part(d),subpart(0),[12,0,""]).
answer(number(4),part(d),subpart(0),[13,1,"It may be useful because people who are ill and need cells to be replaced can have the correct cells cloned and inserted so they become well. "]).
answer(number(4),part(d),subpart(0),[14,2,""]).
answer(number(4),part(d),subpart(0),[15,0,""]).
answer(number(4),part(d),subpart(0),[16,1,""]).
answer(number(4),part(d),subpart(0),[17,0,""]).
answer(number(4),part(d),subpart(0),[18,2,"possible to clone the working kidney and replace the damaged kidney. "]).
answer(number(4),part(d),subpart(0),[18,2,". Organs would be easily replaced. "]).
answer(number(4),part(d),subpart(0),[18,2,". it is tampering with nature and is not God's doing. "]).
answer(number(4),part(d),subpart(0),[19,3,"would greatly facilitate organ transplants since there would be no danger of the body rejecting the organ. "]).
answer(number(4),part(d),subpart(0),[19,3,"morally wrong to create something just for organs. "]).
answer(number(4),part(d),subpart(0),[20,3,"It is possible to build a new organ for someone whose original one is defective "]).
answer(number(4),part(d),subpart(0),[20,3,"possible to clone entire humans for an infertile couple. "]).
answer(number(4),part(d),subpart(0),[20,3,". However this means the child will be a replica of its parent which may offend its individuality."]).
answer(number(4),part(d),subpart(0),[21,0,""]).
answer(number(4),part(d),subpart(0),[22,0,"human body cell clones are useful for seriously ill people who need them to survive. "]).
answer(number(4),part(d),subpart(0),[23,1,"often religious people object as they see cloning as 'Playing God.' "]).
answer(number(4),part(d),subpart(0),[24,0,""]).
answer(number(4),part(d),subpart(0),[25,2,""]).
answer(number(4),part(d),subpart(0),[26,1,""]).
answer(number(4),part(d),subpart(0),[27,2,"effectively kills or causes risk to the cloned human's life, which can be seen as inhumane."]).
answer(number(4),part(d),subpart(0),[28,2,"Producing clones of body cells, such as liver or kidney cells could provide healthy copies of damaged organs,"]).
answer(number(4),part(d),subpart(0),[28,2,"Some people object to this as unethical as it seems to be 'playing God'."]).
answer(number(4),part(d),subpart(0),[29,2,"there would be very little genetic variation in the human race, "]).
answer(number(4),part(d),subpart(0),[29,2,"not a moral thing to do. "]).
answer(number(4),part(d),subpart(0),[30,2,"questionable whether it is morally right to do such a thing "]).
answer(number(4),part(d),subpart(0),[30,2,"means loss of identity for clones and those they have been cloned from. "]).
answer(number(4),part(d),subpart(0),[30,2,"wrong to ''create'' a person unlikely to survive and without a true identity."]).
answer(number(4),part(d),subpart(0),[31,2,"able to grow organs for transplants. "]).
answer(number(4),part(d),subpart(0),[32,0,""]).
answer(number(4),part(d),subpart(0),[33,1,""]).
answer(number(4),part(d),subpart(0),[34,1,""]).
answer(number(4),part(d),subpart(0),[35,1,""]).
answer(number(4),part(d),subpart(0),[36,3,"vital organs could be produced, for transplants "]).
answer(number(4),part(d),subpart(0),[37,3,"organ diseases, whereby they need a new organ it can be hard to find a doner"]).
answer(number(4),part(d),subpart(0),[37,3,", if they use cloning, then a healthy organ could be created. "]).
answer(number(4),part(d),subpart(0),[37,3,"ethically wrong to clone."]).
answer(number(4),part(d),subpart(0),[38,1,"Some people may object as they feel it would be ''ethically immoral''"]).
answer(number(4),part(d),subpart(0),[39,3,"be used to provide organs for people who need organ transplants"]).
answer(number(4),part(d),subpart(0),[39,3,"However, there is an ethical issue in that people consider this 'playing god', "]).
answer(number(4),part(d),subpart(0),[39,3,"and think that creating a human merely to destroy it for its organs is wrong."]).
answer(number(4),part(d),subpart(0),[40,1,"because of some religious reasons "]).
answer(number(4),part(d),subpart(0),[41,2,". However some people object as they feel it is like playing gd."]).
answer(number(4),part(d),subpart(0),[42,1,""]).
answer(number(4),part(d),subpart(0),[43,1,""]).
answer(number(4),part(d),subpart(0),[44,2,"people may object to it because it can be seen as unethecial. "]).
answer(number(4),part(d),subpart(0),[44,2,"It can reduce the gene pool if performed on a wide scale "]).
answer(number(4),part(d),subpart(0),[44,2,"lack of diversity a specific disease could affect more people due to genetic identicality than had cloning not have been performed. "]).
answer(number(4),part(d),subpart(0),[45,2,"But then the clone would be killed, and that what people object to."]).
answer(number(4),part(d),subpart(0),[46,1,"and is not what God wanted."]).
answer(number(4),part(d),subpart(0),[47,2,"procedures such as skin grafts, where new skin can be produced "]).
answer(number(4),part(d),subpart(0),[48,1,"would be playing god that is why a vast number of people object to this "]).
answer(number(4),part(d),subpart(0),[49,1,""]).
answer(number(4),part(d),subpart(0),[50,0,""]).
answer(number(4),part(d),subpart(0),[51,2,"Some people object to cloning as they think that scientists are trying to play the part of God. "]).
answer(number(4),part(d),subpart(0),[51,2,"It also may be useful as people who cannot have babies can use cloning to produce children. "]).
answer(number(4),part(d),subpart(0),[52,0,"cells can be beneficial for example cloning human insulin cells for diabetes sufferers. "]).
answer(number(4),part(d),subpart(0),[53,2,"replace broken or damaged cells. "]).
answer(number(4),part(d),subpart(0),[54,2,"Yes it is possible and this will be good people how need eg bone marow transplants. "]).
answer(number(4),part(d),subpart(0),[54,2,"Some people object to this as its like 'playing god' creatting humans for specific requirments."]).
answer(number(4),part(d),subpart(0),[55,1,""]).
answer(number(4),part(d),subpart(0),[56,1,"it is morally innapropriate "]).
answer(number(4),part(d),subpart(0),[57,1,""]).
answer(number(4),part(d),subpart(0),[58,1,"ethical reasons, "]).
answer(number(4),part(d),subpart(0),[59,1,"People object, however, due to its moral issues. "]).
answer(number(4),part(d),subpart(0),[60,0,""]).
answer(number(4),part(d),subpart(0),[61,0,"grow body parts for people who needed it. "]).
answer(number(4),part(d),subpart(0),[62,2,"useful for transplant operations where the organs are not available"]).
answer(number(4),part(d),subpart(0),[62,2,"many people on waiting lists for organs would be treated more quickly "]).
answer(number(4),part(d),subpart(0),[62,2,"cloning is like 'playing God' and that doctors should not have this power."]).
answer(number(4),part(d),subpart(0),[63,2,"ethical wrong "]).
answer(number(4),part(d),subpart(0),[64,2,", people who have lost parts of their body could have them replaced "]).
answer(number(4),part(d),subpart(0),[64,2,"transplants won't be as difficult to have due to matches. "]).
answer(number(4),part(d),subpart(0),[64,2,"ethics of cloning mean that people fear the idea of clones. "]).
answer(number(4),part(d),subpart(0),[65,0,""]).
answer(number(4),part(d),subpart(0),[66,1,""]).
answer(number(4),part(d),subpart(0),[67,1,""]).
answer(number(4),part(d),subpart(0),[68,0,""]).
answer(number(4),part(d),subpart(0),[69,1,"whether playing god is the right thing to do"]).
answer(number(4),part(d),subpart(0),[70,1,""]).
answer(number(4),part(d),subpart(0),[71,2,"skin grafts "]).
answer(number(4),part(d),subpart(0),[71,2,"replacement of an organ lost in a accident. "]).
answer(number(4),part(d),subpart(0),[71,2,"there wouldn't be a shortage as there is now, with donor organs. "]).
answer(number(4),part(d),subpart(0),[72,1,"seen as morally wrong."]).
answer(number(4),part(d),subpart(0),[73,2,"This is useful for situations such as heart transplants as spare hearts are not always available, "]).
answer(number(4),part(d),subpart(0),[73,2,"many moral issues."]).
answer(number(4),part(d),subpart(0),[74,1,"re-grow human body parts, eg breasts after breast cancer "]).
answer(number(4),part(d),subpart(0),[75,2,"to clone skin cells because you could grow a lot at a fast rate "]).
answer(number(4),part(d),subpart(0),[76,2,"believe it is ethical to 'produce' life in this way."]).
answer(number(4),part(d),subpart(0),[77,1,"unethical and 'playing God'. "]).
answer(number(4),part(d),subpart(0),[78,1,""]).
answer(number(4),part(d),subpart(0),[79,3,"the cells of organs which have failed in patients can be cloned"]).
answer(number(4),part(d),subpart(0),[79,3,"The use of embryos ie. a new life is seen as immoral. "]).
answer(number(4),part(d),subpart(0),[79,3,"Some people also object as they do not believe that humans should interfere with nature an 'play God'."]).
answer(number(4),part(d),subpart(0),[80,0,""]).
answer(number(4),part(d),subpart(0),[81,0,""]).
answer(number(4),part(d),subpart(0),[82,1,""]).
answer(number(4),part(d),subpart(0),[83,1,"possible for infertile people to have children. "]).
answer(number(4),part(d),subpart(0),[84,1,""]).
answer(number(4),part(d),subpart(0),[85,3,"also help infertile couples produce offspring. "]).
answer(number(4),part(d),subpart(0),[86,3,"useful for making donor organs "]).
answer(number(4),part(d),subpart(0),[86,3,"object on a moral level, "]).
answer(number(4),part(d),subpart(0),[87,2,"not ethical "]).
answer(number(4),part(d),subpart(0),[88,1,""]).
answer(number(4),part(d),subpart(0),[89,3,"people who need organ transplants "]).
answer(number(4),part(d),subpart(0),[89,3,"feel it is morally wrong "]).
answer(number(4),part(d),subpart(0),[90,1,""]).
answer(number(4),part(d),subpart(0),[91,2,""]).
answer(number(4),part(d),subpart(0),[92,2,"clone harts and other organs "]).
answer(number(4),part(d),subpart(0),[92,2,"however people (mostly religeouse) who believe it is wrong for people to tamper with nature and ''gods creations''"]).
answer(number(4),part(d),subpart(0),[93,1,"useful to a person who needs a transplant "]).
answer(number(4),part(d),subpart(0),[94,0,""]).
answer(number(4),part(d),subpart(0),[95,2,"to clone body parts and organs, so that transplants would be a lot easier. "]).
answer(number(4),part(d),subpart(0),[95,2,". Religious people would especially object, as they would see it as going against one of God's processes - birth."]).
answer(number(4),part(d),subpart(0),[96,0,""]).
answer(number(4),part(d),subpart(0),[97,0,""]).
answer(number(4),part(d),subpart(0),[98,2,"an organ transplant needed to happen, it would be able to without searching for a donor. "]).
answer(number(4),part(d),subpart(0),[99,2,"Many people do have objections because the clones would in many cases be used solely as test objects and what right do we have to use other human beings for such a process. "]).
answer(number(4),part(d),subpart(0),[99,2,"against many relegious beliefs"]).
answer(number(4),part(d),subpart(0),[100,3,"used for badly needed organ transplants"]).
answer(number(4),part(d),subpart(0),[100,3,"women who can't conceive their own child. "]).
answer(number(4),part(d),subpart(0),[100,3,"it is said by religious people - against the act of god and mother nature."]).
answer(number(4),part(d),subpart(0),[101,2,"we could make bone marrow or new organs to be implanted into ill people. "]).
answer(number(4),part(d),subpart(0),[101,2,"People object to this because they fear that whole people would be cloned which would be unethical."]).
answer(number(4),part(d),subpart(0),[102,2,"Yet some may object as some regard the process as de-humanising and acting as though they are ''Playing God''"]).
answer(number(4),part(d),subpart(0),[103,0,""]).
answer(number(4),part(d),subpart(0),[104,1,"Some say it is morally wrong and goes against beliefs of being created and remaining as you are."]).
answer(number(4),part(d),subpart(0),[105,3,"Its useful for medical reasons, for example blood transfusions or transplants "]).
answer(number(4),part(d),subpart(0),[106,2,"organs for transplants. "]).
answer(number(4),part(d),subpart(0),[106,2,"object because it is wrong to play god, "]).
answer(number(4),part(d),subpart(0),[107,2,"a clone of a good organ would be made to replace bad one. "]).
answer(number(4),part(d),subpart(0),[107,2,"People object because they think it's messing with god, "]).
answer(number(4),part(d),subpart(0),[108,2,"very useful for transplants and blood transfusions. "]).
answer(number(4),part(d),subpart(0),[109,0,""]).
answer(number(4),part(d),subpart(0),[110,2,"useful to produce clones of human body cells as they could be used in medicin as donar body parts "]).
answer(number(4),part(d),subpart(0),[111,1,"Some people are against it because they believe it is un-Holy!"]).
answer(number(4),part(d),subpart(0),[112,1,"they could be used for transplants, "]).
answer(number(4),part(d),subpart(0),[113,1,"produce organs in which they could use to save the dying by giving them organ transplants"]).
answer(number(4),part(d),subpart(0),[114,2,"infertile couples could still produce a child of their own "]).
answer(number(4),part(d),subpart(0),[114,2,"morally wrong. "]).
answer(number(4),part(d),subpart(0),[114,2,"They may also object for religious reasons."]).
answer(number(4),part(d),subpart(0),[115,0,""]).
answer(number(4),part(d),subpart(0),[116,2,"however people object as it is morally wrong as people think those who clone things are playing God."]).
answer(number(4),part(d),subpart(0),[117,3,"It may be useful to produce human clones if a couple cannot conceive and have children naturally. "]).
answer(number(4),part(d),subpart(0),[117,3,"Also if a person experienced an accident and lots of tissues are destroyed. Cloning some body cells can substitute the damaged cells."]).
answer(number(4),part(d),subpart(0),[117,3,"and cloning of humans are going against nature (and some people believe - God)."]).
answer(number(4),part(d),subpart(0),[118,3,""]).
answer(number(4),part(d),subpart(0),[119,0,""]).
answer(number(4),part(d),subpart(0),[120,0,""]).
answer(number(4),part(d),subpart(0),[121,2,"Cloning cells means organs can be produced to help save lives. "]).
answer(number(4),part(d),subpart(0),[122,1,""]).
answer(number(4),part(d),subpart(0),[123,1,""]).
answer(number(4),part(d),subpart(0),[124,2,"to produce organs that can then be used in medicine to save people lives. "]).
answer(number(4),part(d),subpart(0),[124,2,"many people feel it is unethical "]).
answer(number(4),part(d),subpart(0),[125,2,", cloning humans causes many ethical dilemmas, "]).
answer(number(4),part(d),subpart(0),[126,1,"can be used for skin grafts "]).
answer(number(4),part(d),subpart(0),[127,2,"If someone was not able to have a child, cloning could be useful as you could form a zygote from using the cells from a person. "]).
answer(number(4),part(d),subpart(0),[128,1,""]).
answer(number(4),part(d),subpart(0),[129,1,"as the cells would be able to grow a new into the place of the lost or damaged tissue."]).
answer(number(4),part(d),subpart(0),[130,2,"to regenerate a kidney, or grow a body part of someone's who was born without one, or is very ill "]).
answer(number(4),part(d),subpart(0),[130,2,"Some object to this process as it is playing with the hands of GOD, "]).
answer(number(4),part(d),subpart(0),[130,2,"and some see it as immoral. "]).
answer(number(4),part(d),subpart(0),[131,2,"some religous people will not like the fact it goes aganist them"]).
answer(number(4),part(d),subpart(0),[132,2,"possible to generate new body parts for people with defective organs or amputees. "]).
answer(number(4),part(d),subpart(0),[133,2,"This may be useful as replacement organs or body parts could be grown. "]).
answer(number(4),part(d),subpart(0),[133,2,"Fewer donors would be needed as the organs would be manufactured rather than donated. "]).
answer(number(4),part(d),subpart(0),[134,0,""]).
answer(number(4),part(d),subpart(0),[135,0,"because it will seem like the scientist are trying to play God with real life humans."]).
answer(number(4),part(d),subpart(0),[136,1,"The cloning of human body cells would be useful if someone needs a transplant to save them, "]).
answer(number(4),part(d),subpart(0),[137,0,""]).
answer(number(4),part(d),subpart(0),[138,0,""]).
answer(number(4),part(d),subpart(0),[139,1,""]).
answer(number(4),part(d),subpart(0),[140,1,"People object because it is not for us to play God."]).
answer(number(4),part(d),subpart(0),[141,2,"a human cell you can produce another body part eg a liver or lung. "]).
answer(number(4),part(d),subpart(0),[141,2,"people may protest against this because it is playing 'god'"]).
answer(number(4),part(d),subpart(0),[142,1,""]).
answer(number(4),part(d),subpart(0),[143,3,"It will be useful for people that are ill and need organ transplants "]).
answer(number(4),part(d),subpart(0),[144,1,"Some people object to cloning because they believe it is wrong and against the will of God."]).
answer(number(4),part(d),subpart(0),[145,1,""]).
answer(number(4),part(d),subpart(0),[146,2,"Cloning human body cells can be used to grow new organs for use in transplants. "]).
answer(number(4),part(d),subpart(0),[146,2,"they believe that it is immoral "]).
answer(number(4),part(d),subpart(0),[147,2,"A clone could be grown to donate organs to an ill human. Because the organs would be identical,  "]).
answer(number(4),part(d),subpart(0),[147,2,"it is wrong to intefere with nature and ' play God' "]).
answer(number(4),part(d),subpart(0),[148,2,"because clones can be produced of a healthy organ and transplanted into person with a damaged organ."]).
answer(number(4),part(d),subpart(0),[148,2,"they think that humans should not play the role of God "]).
answer(number(4),part(d),subpart(0),[149,2,"It can be useful as we can recreate an organ or specific skin tissue for those injured or disabled. "]).
answer(number(4),part(d),subpart(0),[150,2,"It may be useful if somebody was trying for a baby, but couldn't have one therefore they would have a test tube baby, "]).
answer(number(4),part(d),subpart(0),[151,2,"This may be useful because if somebody has a genetic defect or problem, for example blindness, replacement organs can be 'grown'. "]).
answer(number(4),part(d),subpart(0),[151,2,"Similarly, the replacement of kidneys, hearts and lost limbs will become possible. "]).
answer(number(4),part(d),subpart(0),[151,2,"What's more, they object the disruption of nature and the idea of some people 'playing God'."]).
answer(number(4),part(d),subpart(0),[152,2,"This may be useful if a person is missing a limb, such as an arm, scientiests can 'grow' another one. "]).
answer(number(4),part(d),subpart(0),[152,2,"Some people object to exact replicas / clones of a whole complete person as all individuality would be lost."]).
answer(number(4),part(d),subpart(0),[153,0,""]).
answer(number(4),part(d),subpart(0),[154,0,""]).
answer(number(4),part(d),subpart(0),[155,0,""]).
answer(number(4),part(d),subpart(0),[156,0,""]).
answer(number(4),part(d),subpart(0),[157,1,"It could be useful in organ transplantation"]).
answer(number(4),part(d),subpart(0),[158,1,""]).
answer(number(4),part(d),subpart(0),[159,1,""]).
answer(number(4),part(d),subpart(0),[160,0,""]).
answer(number(4),part(d),subpart(0),[161,0,""]).
answer(number(4),part(d),subpart(0),[162,1,""]).
answer(number(4),part(d),subpart(0),[163,2,"This can be useful for medical developments such as clone specific healthy cells to replace diseased or damaged cells, "]).
answer(number(4),part(d),subpart(0),[163,2,"However this presents ethical dilemmas as to how moral it is to clone humans "]).
answer(number(4),part(d),subpart(0),[164,1,""]).
answer(number(4),part(d),subpart(0),[165,1,""]).
answer(number(4),part(d),subpart(0),[166,2,"This can be useful to grow organs and body parts which are damaged on people so that they can be replaced. "]).
answer(number(4),part(d),subpart(0),[166,2,"Some people object to this through ethical issues such as "]).
answer(number(4),part(d),subpart(0),[167,0,""]).
answer(number(4),part(d),subpart(0),[168,2,"People who need transplants would be able to get them more easily if organs/body cells could be made on demand. "]).
answer(number(4),part(d),subpart(0),[168,2,"Some people object as they say it is interfering too much with evolution and with God."]).
answer(number(4),part(d),subpart(0),[169,0,""]).
answer(number(4),part(d),subpart(0),[170,2,"some people think it is morally wrong to have genetically identical humans "]).
answer(number(4),part(d),subpart(0),[171,3,"The main use would be for transplants. "]).
answer(number(4),part(d),subpart(0),[171,3,"If a person needed any organ transplant (eg. heart, liver) by cloning an exact replica of the original organ can be grown and the body will except this organ "]).
answer(number(4),part(d),subpart(0),[171,3,"Cloning may also be considered unethical "]).
answer(number(4),part(d),subpart(0),[171,3,"By cloning, therefore, the embryo is being killed and a life taken away."]).
answer(number(4),part(d),subpart(0),[172,3,"It may be useful to find ''matches'' for certain transplants "]).
answer(number(4),part(d),subpart(0),[172,3,"cloning them is immoral and wrong."]).
answer(number(4),part(d),subpart(0),[173,0,""]).
answer(number(4),part(d),subpart(0),[174,3,"because it could help couples that can't have kids have a kid. "]).
answer(number(4),part(d),subpart(0),[175,3,"This may be useful because it means that tissues and organs can grown. These can greatly benefit people who have illnesses that require transplants. "]).
answer(number(4),part(d),subpart(0),[175,3,"Cloning is also useful because it means that infertile couples can have children. "]).
answer(number(4),part(d),subpart(0),[175,3,"Some people may, however object to cloning because it eradicates natural variation "]).
answer(number(4),part(d),subpart(0),[175,3,"Some people also object to cloning because they believe it to be unethical."]).
answer(number(4),part(d),subpart(0),[176,3,"it would provide organs for organ transplants "]).
answer(number(4),part(d),subpart(0),[176,3,"childless couples could have children made from their own cells rather than relying on egg or sperm donors. "]).
answer(number(4),part(d),subpart(0),[176,3,"for religious people; cloning is viewed as playing the role of their god(s). "]).
answer(number(4),part(d),subpart(0),[177,3,"Some people would object to this because it is unnatural and does not allow evolution and less variation."]).
answer(number(4),part(d),subpart(0),[178,0,""]).
answer(number(4),part(d),subpart(0),[179,0,""]).
answer(number(4),part(d),subpart(0),[180,3,"This may be useful to couples who are infertile and wish to have children "]).
answer(number(4),part(d),subpart(0),[180,3,"morally wrong and many say it is''Playing God''"]).
answer(number(4),part(d),subpart(0),[181,3,"allow scientists to produce human organs or other body parts for transplantation"]).
answer(number(4),part(d),subpart(0),[181,3,"Some people believe that this process may lead to the cloning of human beings in their entirety, the ethical value of which is highly contested."]).
answer(number(4),part(d),subpart(0),[182,3,"Cloning human body cells would mean that organs could be grown to provide more organs for transplants. "]).
answer(number(4),part(d),subpart(0),[182,3,"People who could not have children could grow clones of themselves "]).
answer(number(4),part(d),subpart(0),[182,3,"but some people feel this is interfering to much into nature / Gods laws."]).
answer(number(4),part(d),subpart(0),[183,3,"If clones could be made of humans it would help in making organs for people needed organ transplants"]).
answer(number(4),part(d),subpart(0),[183,3,"however, believe that it is morally wrong to create life, we should not 'play God'."]).
answer(number(4),part(d),subpart(0),[184,3,"Human body cells could possibly be used to grow organs "]).
answer(number(4),part(d),subpart(0),[184,3,"or help infertile parents produce children. "]).
answer(number(4),part(d),subpart(0),[184,3,"produces ethical dilemmas, "]).
answer(number(4),part(d),subpart(0),[185,3,"Producing clones could be useful as it could provide body parts for people who need them. As they are clones of themselves they will not be rejected. "]).
answer(number(4),part(d),subpart(0),[185,3,"they think it is wrong to 'play god' "]).
answer(number(4),part(d),subpart(0),[186,0,""]).
answer(number(4),part(d),subpart(0),[187,3,"possible to clone organs which then could be used in organ transplants.. "]).
answer(number(4),part(d),subpart(0),[187,3,"However many feel cloning is unethical. "]).
answer(number(4),part(d),subpart(0),[188,0,""]).
answer(number(4),part(d),subpart(0),[189,3,"Some people object to this because the variation in the world would decrease "]).
answer(number(4),part(d),subpart(0),[190,3,"People who are unable to have children will be able to have them. "]).
answer(number(4),part(d),subpart(0),[190,3,". they could be used if someone is medically ill and needs an organ. "]).
answer(number(4),part(d),subpart(0),[190,3,"and you are also playing God."]).
answer(number(4),part(d),subpart(0),[191,3,"all over the world there are many people who are unable to have children. Cloning human cells could give those people the chance to have babies "]).
answer(number(4),part(d),subpart(0),[191,3,"healthy organs could be grown which could be used in transplants "]).
answer(number(4),part(d),subpart(0),[191,3,"they think that it is immoral "]).
answer(number(4),part(d),subpart(0),[191,3,"almost as if people were ' playing god' "]).
answer(number(4),part(d),subpart(0),[192,3,"used to create tissue or organs for implantation. "]).
answer(number(4),part(d),subpart(0),[192,3,". Also, the cells can be used to produce an embryo for a couple who have difficulty conceiving. "]).
answer(number(4),part(d),subpart(0),[193,3,"to produce organs, such as the heart, which are often needed for transplants,."]).
answer(number(4),part(d),subpart(0),[193,3,"However, it is objected to because some people believe it would lead to the cloning of humans themselves,which may remove the sanctity of life and people would no longer be individuals if someone is made in their image. "]).
answer(number(4),part(d),subpart(0),[193,3,"They believe it is unethical and could have damaging consequences"]).
answer(number(4),part(d),subpart(0),[194,3,""]).
answer(number(4),part(d),subpart(0),[195,3,"creating new organs for those who need them "]).
answer(number(4),part(d),subpart(0),[195,3,"creating children for those who can't have them. "]).
answer(number(4),part(d),subpart(0),[195,3,"against natural law and religion objects to it, because it would be ''playing God''."]).
answer(number(4),part(d),subpart(0),[196,3,"creating a 'life' just to kill it is ethically wrong' "]).
answer(number(4),part(d),subpart(0),[196,3,"there are huge debates about the ethics of cloning "]).
answer(number(4),part(d),subpart(0),[197,3,""]).
answer(number(4),part(d),subpart(0),[198,3,"However some people object because they feel that individuality is lost "]).
answer(number(4),part(d),subpart(0),[198,3,"Cloning may be useful to those people who cannot have children (due to infertility). "]).
answer(number(4),part(d),subpart(0),[199,3,"This may be useful for transplanting organs,  - people's bodies would be more likely to accept organs cloned from their own body. "]).
answer(number(4),part(d),subpart(0),[199,3,"people think it is morally wrong "]).
answer(number(4),part(d),subpart(0),[199,3,"as it would be creating a life and then killing it for our own selfish purposes - (ie. playing god)."]).
answer(number(4),part(d),subpart(0),[200,3,"cloned as people will illnesses because they are missing cells (like bone marrow) can be cloned to produce new cells "]).
answer(number(4),part(d),subpart(0),[200,3,"humans should not play God or make "]).
