:- multifile answer/4.

answer(number(2),part(a),subpart(0),[1,1,"to pump blood around are entire body"]).
answer(number(2),part(a),subpart(0),[2,1,"pump the blood around the body"]).
answer(number(2),part(a),subpart(0),[3,1,"pump blood around the body."]).
answer(number(2),part(a),subpart(0),[4,1,"pumps the blood around the body."]).
answer(number(2),part(a),subpart(0),[5,1,"pumps de-oxygenated blood to the lungs and the left pumps oxygenated blood around the body."]).
answer(number(2),part(a),subpart(0),[6,1,"to pump blood around the body."]).
answer(number(2),part(a),subpart(0),[7,1,"The heart is a muscle which pumps blood round the body by constricting forming high pressure, forcing blood round along arteies"]).
answer(number(2),part(a),subpart(0),[8,1,"to pump blood around the body."]).
answer(number(2),part(a),subpart(0),[9,1,"To pump blood round the body."]).
answer(number(2),part(a),subpart(0),[10,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[11,1,"The heart is a muscle which pumps blood both to the lungs & to the rest of the body through arteries, veins & capillaries."]).
answer(number(2),part(a),subpart(0),[12,1,"The heart pumps blood all around the body."]).
answer(number(2),part(a),subpart(0),[13,1,"The heart pumps blood around the body,"]).
answer(number(2),part(a),subpart(0),[14,1,"to pump oxygenated blood from the lungs around the body and remove deoxygenated blood."]).
answer(number(2),part(a),subpart(0),[15,1,"to circulate blood around the body."]).
answer(number(2),part(a),subpart(0),[16,1,"The job is to pump blood to all parts of the body where it is required"]).
answer(number(2),part(a),subpart(0),[17,1,"The heart pumps blood around the body."]).
answer(number(2),part(a),subpart(0),[18,1,"The job of the heart is to pump blood around the body."]).
answer(number(2),part(a),subpart(0),[19,1,"The heart pumps oxygenated and deoxygenated blood around the body."]).
answer(number(2),part(a),subpart(0),[20,1,"to pump the blood around the body"]).
answer(number(2),part(a),subpart(0),[21,1,"To pump blood oxygen, Glucose ect around the body."]).
answer(number(2),part(a),subpart(0),[22,1,"To keep the blood going around the body."]).
answer(number(2),part(a),subpart(0),[23,1,"Pump round blood in your body, which controls parts of breathing."]).
answer(number(2),part(a),subpart(0),[24,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[25,1,"To pump blood to all parts of the body."]).
answer(number(2),part(a),subpart(0),[26,1,"to act as a pump and pump blood around the body."]).
answer(number(2),part(a),subpart(0),[27,1,"The heart pumps blood around the body."]).
answer(number(2),part(a),subpart(0),[28,1,"to pump blood to the lungs and then oxygenated blood around the body"]).
answer(number(2),part(a),subpart(0),[29,1,"The job of the heart is to pump blood around the body"]).
answer(number(2),part(a),subpart(0),[30,1,"The heart pumps blood to your head and all around your body."]).
answer(number(2),part(a),subpart(0),[31,1,"to pump blood around your body."]).
answer(number(2),part(a),subpart(0),[32,1,"The heart has to pump the blood that carries oxygen around the whole body"]).
answer(number(2),part(a),subpart(0),[33,1,"The job of the heart is to pump blood around the body."]).
answer(number(2),part(a),subpart(0),[34,1,"To pump the blood around the body"]).
answer(number(2),part(a),subpart(0),[35,1,"It pumps oxygenated blood around the human body."]).
answer(number(2),part(a),subpart(0),[36,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[37,1,"The heart pumps blood around the body, so that oxygen, nutrients, and waste materials are transported to and from every cell."]).
answer(number(2),part(a),subpart(0),[38,1,"To make sure blood is pumped round the whole body."]).
answer(number(2),part(a),subpart(0),[39,1,"To pump blood around the body"]).
answer(number(2),part(a),subpart(0),[40,1,"The heart helps pump blood around the whole body. It does this by contracting"]).
answer(number(2),part(a),subpart(0),[41,1,"to pump the blood around your body"]).
answer(number(2),part(a),subpart(0),[42,1,"The heart is a muscle which pumps the blood around the human body."]).
answer(number(2),part(a),subpart(0),[43,1,"It has a double circulatory system which pumps blood around the body."]).
answer(number(2),part(a),subpart(0),[44,1,"to pump blood around the body"]).
answer(number(2),part(a),subpart(0),[45,1,"To pump blood around the body to various other body parts."]).
answer(number(2),part(a),subpart(0),[46,1,"to pump blood around the body"]).
answer(number(2),part(a),subpart(0),[47,1,"To pump oxegenated blood around the body."]).
answer(number(2),part(a),subpart(0),[48,1,"The heart is the pump that pushes blood around the body"]).
answer(number(2),part(a),subpart(0),[49,1,"The heart pumps blood around the body which keeps you alive."]).

answer(number(2),part(a),subpart(0),[50,1,"the pump blood around the body, so that substances which are held in the blood can be transported to where they are required."]).
answer(number(2),part(a),subpart(0),[51,1,"To pump blood around our whole body."]).
answer(number(2),part(a),subpart(0),[52,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[53,1,"to pump blood around the body."]).
answer(number(2),part(a),subpart(0),[54,1,"To pump blood around the body, so ensuring oxgenation of all cells."]).
answer(number(2),part(a),subpart(0),[55,1,"To pump oxygenated blood around the body"]).
answer(number(2),part(a),subpart(0),[56,1,"The heart pumps oxogenated blood around the body and deoxogenated blood to the lungs"]).
answer(number(2),part(a),subpart(0),[57,1,"pumps blood around the body"]).
answer(number(2),part(a),subpart(0),[58,1,"the job are heart is to pump blood all around our body"]).
answer(number(2),part(a),subpart(0),[59,1,"Pump blood around the body."]).
answer(number(2),part(a),subpart(0),[60,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[61,1,"To pump blood around the body, delivering oxygen and nutrients where they are needed"]).
answer(number(2),part(a),subpart(0),[62,1,"The heart is a muscle which pumps blood around the body to organs and muscles"]).
answer(number(2),part(a),subpart(0),[63,1,"pump blood around the body."]).
answer(number(2),part(a),subpart(0),[64,1,"To pump blood around the body. To provide the body with oxygen"]).
answer(number(2),part(a),subpart(0),[65,1,"To pump blood round the body."]).
answer(number(2),part(a),subpart(0),[66,1,"To pump blood around the body"]).
answer(number(2),part(a),subpart(0),[67,1,"The heart pumps blood to the lungs and all the way around the body in order to supply cells with oxygen needed for respiration."]).
answer(number(2),part(a),subpart(0),[68,1,"The heart pumps blood to the lungs and all parts of the body (so that the cells get the nutrients they need and waste products can be removed)"]).
answer(number(2),part(a),subpart(0),[69,1,"To pump blood to the lungs to be oxygenated + all over the rest of the body"]).
answer(number(2),part(a),subpart(0),[70,1,"to pump blood around our body"]).
answer(number(2),part(a),subpart(0),[71,1,"to pump oxygenated blood through the body."]).
answer(number(2),part(a),subpart(0),[72,1,"It pumps blood around the body where it is needed."]).
answer(number(2),part(a),subpart(0),[73,1,"The heart pumps the blood around the body."]).
answer(number(2),part(a),subpart(0),[74,1,"to keep you alive & pump blood round the body"]).
answer(number(2),part(a),subpart(0),[75,1,"The heart pumps blood around the body, and to the lungs to recieve oxygen."]).
answer(number(2),part(a),subpart(0),[76,1,"The heart pumps oxygenated blood to the body and organs so that they can function and one can live"]).
answer(number(2),part(a),subpart(0),[77,1,"The heart pumps blood to the lungs to oxygenate it then pumps this oxygenated blood around the body."]).
answer(number(2),part(a),subpart(0),[78,1,"to pump oxygenated blood around the body"]).
answer(number(2),part(a),subpart(0),[79,1,"TO 'pump' blood to all the different parts of the body."]).
answer(number(2),part(a),subpart(0),[80,1,"The heart is a pump. It's job is to pump blood around the whole body."]).
answer(number(2),part(a),subpart(0),[81,1,"To pump blood cells around the body."]).
answer(number(2),part(a),subpart(0),[82,1,"to pump blood to the lungs and other parts of the body."]).
answer(number(2),part(a),subpart(0),[83,1,"To pump blood around the body"]).
answer(number(2),part(a),subpart(0),[84,1,"Pumps blood to our mucsles"]).
answer(number(2),part(a),subpart(0),[85,1,"The heart pumps blood round your body"]).
answer(number(2),part(a),subpart(0),[86,1,"the heart sends oxygenated blood to all body organs, it pumps blood around the body."]).
answer(number(2),part(a),subpart(0),[87,1,"The job of the heart is to pump oxygenated blood around to the rest of the body."]).
answer(number(2),part(a),subpart(0),[88,1,"pumps blood around the body"]).
answer(number(2),part(a),subpart(0),[89,1,"The hearts job is to pump blood around the body"]).
answer(number(2),part(a),subpart(0),[90,1,"Pump blood around body."]).
answer(number(2),part(a),subpart(0),[91,1,"The heart is the bodys pump which pumps blood to the whole of the body"]).
answer(number(2),part(a),subpart(0),[92,1,"The heart pumps blood around the body to our organs ie lungs"]).
answer(number(2),part(a),subpart(0),[93,1,"The heart is a double circulating system which pumps blood around the body."]).
answer(number(2),part(a),subpart(0),[94,1,"To pump the blood around the body"]).
answer(number(2),part(a),subpart(0),[95,1,"To pump blood around the body"]).
answer(number(2),part(a),subpart(0),[96,1,"to keep the blood pumping around the body"]).
answer(number(2),part(a),subpart(0),[97,1,"To get blood around the whole body, to pump it around the body."]).
answer(number(2),part(a),subpart(0),[98,1,"The heart pumps blood round the body and helps a person live."]).
answer(number(2),part(a),subpart(0),[99,1,"the heart pumps oxygenated blood around you body."]).
answer(number(2),part(a),subpart(0),[100,1,"The job of the heart is to pump blood round the body."]).
answer(number(2),part(a),subpart(0),[101,1,"The heart is a double pump which pumps blood around the body"]).
answer(number(2),part(a),subpart(0),[102,1,"The job of the heart is to pump oxygenated and deoxygenated blood around the body"]).
answer(number(2),part(a),subpart(0),[103,1,"To pump blood around the body to the vital organs."]).
answer(number(2),part(a),subpart(0),[104,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[105,1,"the job of the heart is to pump oxygenated blood round the body"]).
answer(number(2),part(a),subpart(0),[106,1,"the heart pumps blood around the body."]).
answer(number(2),part(a),subpart(0),[107,1,"The heart pumps deoxygenated blood to the lungs and oxygenated blood around the body."]).
answer(number(2),part(a),subpart(0),[108,1,"The job of the heart is to pump blood around the body."]).
answer(number(2),part(a),subpart(0),[109,1,"The heart acts as a pump, pumping blood through out the body"]).
answer(number(2),part(a),subpart(0),[110,1,"The heart pumps blood around the body so that oxygen can reach cells and vital organs."]).
answer(number(2),part(a),subpart(0),[111,1,"To pump blood at high pressure to every part of the body, all the organs."]).
answer(number(2),part(a),subpart(0),[112,1,"The heart pumps oxygenated blood through the body and also pumps deoxygenated blood to the lungs to get oxygen."]).
answer(number(2),part(a),subpart(0),[113,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[114,1,"The heart pumps blood around the body"]).
answer(number(2),part(a),subpart(0),[115,0,"bumps blood around the body"]).
answer(number(2),part(a),subpart(0),[116,1,"The heart is a pump and is used to circulate blood around the body"]).
answer(number(2),part(a),subpart(0),[117,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[118,1,"It pumps and circulates blood around the body."]).
answer(number(2),part(a),subpart(0),[119,1,"To pump blood to every part of the body. The blood carrys oxygen which needs to reach every part of the body"]).
answer(number(2),part(a),subpart(0),[120,1,"Job of the heart is to pump the blood around the body"]).
answer(number(2),part(a),subpart(0),[121,1,"To pump blood to the lungs and then pump the oxygenated blood around the body."]).
answer(number(2),part(a),subpart(0),[122,1,"To pump blood around the body"]).
answer(number(2),part(a),subpart(0),[123,1,"The heart controls the circulation of blood around the body."]).
answer(number(2),part(a),subpart(0),[124,1,"To pump blood around the circulatory system and continuasly beat. This keeps a person alive."]).
answer(number(2),part(a),subpart(0),[125,1,"The heart pumps oxygenated blood around the body and unoxygenated blood to the lungs."]).
answer(number(2),part(a),subpart(0),[126,1,"The heart pumps blood around the body through a double circulatory system, reaching the vital organs. It pumps de-oxygenated blood to lungs where it is oxygenated and having returned to the heart it goes round the whole body"]).
answer(number(2),part(a),subpart(0),[127,1,"To pump blood around the body and to the lungs."]).
answer(number(2),part(a),subpart(0),[128,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[129,1,"To Pump blood round the body"]).
answer(number(2),part(a),subpart(0),[130,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[131,1,"to pick up oxygenated blood from the lungs and pump it to the body and then take deoxygenated blood from body to the lungs (to pump blood around the body)"]).
answer(number(2),part(a),subpart(0),[132,1,"To pump blood around the body & to the lungs."]).
answer(number(2),part(a),subpart(0),[133,1,"The heart pumps blood to every part of are body"]).
answer(number(2),part(a),subpart(0),[134,1,"to pump blood around the body."]).
answer(number(2),part(a),subpart(0),[135,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[136,1,"It is to pump blood around the whole body, without it you would die."]).
answer(number(2),part(a),subpart(0),[137,1,"to pump blood around the body."]).
answer(number(2),part(a),subpart(0),[138,1,"To pump the blood around the body."]).
answer(number(2),part(a),subpart(0),[139,1,"It keeps the blood pumping around the body."]).
answer(number(2),part(a),subpart(0),[140,1,"The job of the heart is to pump blood around the body."]).
answer(number(2),part(a),subpart(0),[141,1,"to pump blood around our bodies."]).
answer(number(2),part(a),subpart(0),[142,1,"To pump blood around the body so that the blood can supply and removal material."]).
answer(number(2),part(a),subpart(0),[143,1,"To pump blood around the body"]).
answer(number(2),part(a),subpart(0),[144,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[145,1,"It pumps blood around the body."]).
answer(number(2),part(a),subpart(0),[146,1,"It pumps blood and oxygen around the body"]).
answer(number(2),part(a),subpart(0),[147,1,"The job of the heart is to pump blood around the body, the right side pumps deoxgenated blood to the lungs and left pumps oxygenated blood to the body."]).
answer(number(2),part(a),subpart(0),[148,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[149,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[150,1,"Heart pumps blood around body so you can move breath and work e.t.c"]).
answer(number(2),part(a),subpart(0),[151,1,"To pump oxygenated blood around the body."]).
answer(number(2),part(a),subpart(0),[152,1,"To pump blood around the body and lungs"]).
answer(number(2),part(a),subpart(0),[153,0,"The heart controls the flow of oxygenated and deoxygenated blood."]).
answer(number(2),part(a),subpart(0),[154,1,"The job of the heart is to pump blood around the body, thus delivering vital nutrients e.g. O2 to the cells"]).
answer(number(2),part(a),subpart(0),[155,1,"The heart pumps blood (oxygenated & Deoxygenated) around the body."]).
answer(number(2),part(a),subpart(0),[156,1,"It pumps blood round the body"]).
answer(number(2),part(a),subpart(0),[157,1,"The heart pumps blood round the body. This provides cells with food and oxygen."]).
answer(number(2),part(a),subpart(0),[158,1,"To pump oxygenated blood around the body and deoxygenated blood to the lungs"]).
answer(number(2),part(a),subpart(0),[159,1,"To pump blood around the body. To get blood to carry oxygen (and other materials) around the body, use it and collect more"]).
answer(number(2),part(a),subpart(0),[160,1,"To pump blood around the body and lungs. To pump deoxygenated blood to the lungs so that it can get oxygen and then pump it to the body."]).
answer(number(2),part(a),subpart(0),[161,1,"It pumps blood to the lungs where it is oxygenated and then pumps this blood around the body."]).
answer(number(2),part(a),subpart(0),[162,1,"To pump blood around the body"]).
answer(number(2),part(a),subpart(0),[163,1,"The heart pumps blood. It receives blood from the body and lungs and releases it to these parts. Supplying oxygen to the body & lungs."]).
answer(number(2),part(a),subpart(0),[164,1,"Rotates blood around the body."]).
answer(number(2),part(a),subpart(0),[165,1,"To pump blood around the body"]).
answer(number(2),part(a),subpart(0),[166,1,"it pumps blood around the body and also to the lungs."]).
answer(number(2),part(a),subpart(0),[167,1,"The heart pumps blood around the body (oxygenated as well as deoxygenated)"]).
answer(number(2),part(a),subpart(0),[168,1,"Pumps blood around the body."]).
answer(number(2),part(a),subpart(0),[169,1,"To pump the blood around the double circulation around the body and lungs."]).
answer(number(2),part(a),subpart(0),[170,1,"The heart is a cardiac muscle which pumps blood to all living cells in a body."]).
answer(number(2),part(a),subpart(0),[171,1,"To pump oxygenated blood around the body."]).
answer(number(2),part(a),subpart(0),[172,1,"The hearts job is to pump blood around the body to the organs (humans have a double circulatory system - heart > lungs > heart > body)"]).
answer(number(2),part(a),subpart(0),[173,1,"The heart pumps blood around the body."]).
answer(number(2),part(a),subpart(0),[174,1,"To pump blood to the lungs to collect oxygen and pump it round to the rest of the body."]).
answer(number(2),part(a),subpart(0),[175,1,"The hearts occupation is to pump blood around the body"]).
answer(number(2),part(a),subpart(0),[176,1,"The most important job is to pump blood around the body."]).
answer(number(2),part(a),subpart(0),[177,1,"To keep blood pumping round the body"]).
answer(number(2),part(a),subpart(0),[178,1,"It acts as a pump, pumping blood around the body, supplying the pressure needed."]).
answer(number(2),part(a),subpart(0),[179,1,"To pump oxygenated blood around the body"]).
answer(number(2),part(a),subpart(0),[180,1,"To pump the blood around the body"]).
answer(number(2),part(a),subpart(0),[181,1,"To pump blood containing substances necessary for life around the body to the tissues which need it."]).
answer(number(2),part(a),subpart(0),[182,1,"The heart pumps blood around the body to various organs."]).
answer(number(2),part(a),subpart(0),[183,1,"The heart pumps blood around the body so that the necessary nutrients and wastes can be transported to and from cells."]).
answer(number(2),part(a),subpart(0),[184,1,"The heart pumps oxygenated blood around the body and deoxygenated blood to the lungs"]).
answer(number(2),part(a),subpart(0),[185,1,"The heart is there to pump blood around the body"]).
answer(number(2),part(a),subpart(0),[186,1,"To pump blood around the body."]).
answer(number(2),part(a),subpart(0),[187,1,"To pump blood around the body oxygenated and deoxygenated blood around he body"]).
answer(number(2),part(a),subpart(0),[188,0,"the heart beats to keep us alive"]).
answer(number(2),part(a),subpart(0),[189,0,"The job of the heart to keep pumping oxygen it to the blood and keep the blood circulating the body."]).
answer(number(2),part(a),subpart(0),[190,0,"to carry oxygenated and deoxygenated blood to the plummatory artery and vein."]).
answer(number(2),part(a),subpart(0),[191,0,"the hear keeps the body working"]).
answer(number(2),part(a),subpart(0),[192,1,"Pumps the deoxygenated and oxygenated blood to other parts of the body organ."]).
answer(number(2),part(a),subpart(0),[193,0,"To transport blood to the lungs, so that it is oxygenated and can be used in all parts of the body."]).
answer(number(2),part(a),subpart(0),[194,1,"To pump blood into viens around my body to keep me alive."]).
answer(number(2),part(a),subpart(0),[195,0,"To supply the body with oxygenated blood."]).
answer(number(2),part(a),subpart(0),[196,0,"The heart can be used for breathing."]).
answer(number(2),part(a),subpart(0),[197,0,"the job of the heart is to"]).
answer(number(2),part(a),subpart(0),[198,1,"to keep pumping blood into veins which carry blood round our body."]).
answer(number(2),part(a),subpart(0),[199,0,"To pump the oxygen around the body keeping us alive."]).
answer(number(2),part(a),subpart(0),[200,0,"circulate blood around the body"]).

 
