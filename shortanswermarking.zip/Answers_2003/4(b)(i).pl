
:- multifile answer/4.
answer(number(4),part(b),subpart(i),[1,1,"hunting them"]).
answer(number(4),part(b),subpart(i),[2,1,"Hunting and shooting for food or sport."]).
answer(number(4),part(b),subpart(i),[3,1,"Killing it for its fur."]).
answer(number(4),part(b),subpart(i),[4,1,"Hunting the animal for its thick fur."]).
answer(number(4),part(b),subpart(i),[5,1,"The hunting and killing of bucardo's for meat."]).
answer(number(4),part(b),subpart(i),[6,1,"They may have been killing the goats for their meat or fur."]).
answer(number(4),part(b),subpart(i),[7,1,"Hunting."]).
answer(number(4),part(b),subpart(i),[8,1,"Hunting for its fur and for its hooves."]).
answer(number(4),part(b),subpart(i),[9,1,"Using their habitat (the mountains) as space building factories etc."]).
answer(number(4),part(b),subpart(i),[10,1,"Hunters could have been one of the reason why the Bucardos have decreased"]).
answer(number(4),part(b),subpart(i),[11,1,"hunting of the bucardo"]).
answer(number(4),part(b),subpart(i),[12,1,"Hunting"]).
answer(number(4),part(b),subpart(i),[13,1,"Building on land the bucardo used for grazing"]).
answer(number(4),part(b),subpart(i),[14,1,"humans may have eaten the bucardo"]).
answer(number(4),part(b),subpart(i),[15,1,"hunting for fur"]).
answer(number(4),part(b),subpart(i),[16,1,"Over hunting"]).
answer(number(4),part(b),subpart(i),[17,1,"cutting down trees so there is less food available for them."]).
answer(number(4),part(b),subpart(i),[18,1,"Hunting may have been one of those actions by man."]).
answer(number(4),part(b),subpart(i),[19,1,"Humans would have killed it."]).
answer(number(4),part(b),subpart(i),[20,1,"Hunting"]).
answer(number(4),part(b),subpart(i),[21,1,"Deforestation."]).
answer(number(4),part(b),subpart(i),[22,1,"Deforrestation by men"]).
answer(number(4),part(b),subpart(i),[23,1,"The bucardo's death could have been caused by foresters, cutting down a tree which then landed on the bucardo"]).
answer(number(4),part(b),subpart(i),[24,1,"hunting"]).
answer(number(4),part(b),subpart(i),[25,1,"killing them for their fur."]).
answer(number(4),part(b),subpart(i),[26,1,"By hunting them for food"]).
answer(number(4),part(b),subpart(i),[27,1,"Setting up buildings in their habitat"]).
answer(number(4),part(b),subpart(i),[28,1,"One may have been hunting the goat for its meat or for sport."]).
answer(number(4),part(b),subpart(i),[29,1,"1 of these actions would have been hunting"]).
answer(number(4),part(b),subpart(i),[30,1,"destroying there natural habitat (populating the mountains)"]).
answer(number(4),part(b),subpart(i),[31,1,"Hunting it for it's fur or hooves"]).
answer(number(4),part(b),subpart(i),[32,1,"Destroying its habitat"]).
answer(number(4),part(b),subpart(i),[33,1,"The goats may have been hunted for meat and fur."]).
answer(number(4),part(b),subpart(i),[34,1,"hunting."]).
answer(number(4),part(b),subpart(i),[35,1,"Local people using them for food."]).
answer(number(4),part(b),subpart(i),[36,1,"hunting and shooting the goat."]).
answer(number(4),part(b),subpart(i),[37,1,"Deforestation, - this has removed the animals habitat."]).
answer(number(4),part(b),subpart(i),[38,1,"Hunting, some people may have hunted this goat."]).
answer(number(4),part(b),subpart(i),[39,1,"The bucardo may have been hunted for their fur."]).
answer(number(4),part(b),subpart(i),[40,1,"hunting the animal"]).
answer(number(4),part(b),subpart(i),[41,1,"Destroying the bucardos habitat for their own benefit."]).
answer(number(4),part(b),subpart(i),[42,1,"one of these actions may have been increased temperatures due to global warming meaning the bucardo was unable to adapt."]).
answer(number(4),part(b),subpart(i),[43,1,"Hunting them down for things such as their skin and meat."]).
answer(number(4),part(b),subpart(i),[44,1,"hunting. They could have been hunted for their fur, meat etc."]).
answer(number(4),part(b),subpart(i),[45,1,"Hunting"]).
answer(number(4),part(b),subpart(i),[46,0,"a mountain clamber and to breed the goats (Farmer) (landslides)"]).
answer(number(4),part(b),subpart(i),[47,1,"climbers and tourists may have disturbed their habitat"]).
answer(number(4),part(b),subpart(i),[48,0,"They have blocked the mountain."]).
answer(number(4),part(b),subpart(i),[49,0,"natural"]).
answer(number(4),part(b),subpart(i),[50,1,"Hunted it for its meat."]).
answer(number(4),part(b),subpart(i),[51,1,"cutting down forestry."]).
answer(number(4),part(b),subpart(i),[52,1,"killed them for there thick fur and horn's"]).
answer(number(4),part(b),subpart(i),[53,1,"As the species were becoming rare the reward tor a bucardo would have been very great; due to poachers."]).
answer(number(4),part(b),subpart(i),[54,1,"Hunting - the burcado could have been used for meat to eat, or even in trophy hunting - perhaps before they became a protected species this was the reason for low numbers."]).
answer(number(4),part(b),subpart(i),[55,1,"Hunting for the thick fur."]).
answer(number(4),part(b),subpart(i),[56,1,"cutting down trees"]).
answer(number(4),part(b),subpart(i),[57,1,"one action could of been excessive hunting of the bucardo."]).
answer(number(4),part(b),subpart(i),[58,1,"from digging etc, this has caused landslides"]).
answer(number(4),part(b),subpart(i),[59,1,"hunting the bucardos and killing them for trade or sport"]).
answer(number(4),part(b),subpart(i),[60,1,"Hunting them for their fur."]).
answer(number(4),part(b),subpart(i),[61,1,"Killing or hunting the goats for food"]).
answer(number(4),part(b),subpart(i),[62,1,"man often hunts animals like bucardos, often for meat, but sometimes parts of their body eg. Horns, for decoration. By killing the bucardos, the population is obviously decreased."]).
answer(number(4),part(b),subpart(i),[63,1,"illegally hunted them for fur and meat."]).
answer(number(4),part(b),subpart(i),[64,1,"hunting"]).
answer(number(4),part(b),subpart(i),[65,1,"Hunting for there meat and other Parts of them"]).
answer(number(4),part(b),subpart(i),[66,1,"People hunt and shoot animals for their thick fur."]).
answer(number(4),part(b),subpart(i),[67,1,"deforestetion"]).
answer(number(4),part(b),subpart(i),[68,1,"Hunting the bucardo."]).
answer(number(4),part(b),subpart(i),[69,1,"mining causing landslides"]).
answer(number(4),part(b),subpart(i),[70,1,"hunting for the same prey the goat would have."]).
answer(number(4),part(b),subpart(i),[71,1,"killing them for the fur or the horns."]).
answer(number(4),part(b),subpart(i),[72,1,"The killing of the animal for it fur or horns. or meat."]).
answer(number(4),part(b),subpart(i),[73,1,"Hunting"]).
answer(number(4),part(b),subpart(i),[74,1,"Humans may have hunted them for their fur etc. Humans hunting too much could cause their numbers to drop dramatically."]).
answer(number(4),part(b),subpart(i),[75,1,"Hunting of the bucardo for meat."]).
answer(number(4),part(b),subpart(i),[76,1,"Some people may have hunted the bucardo, for pleasure."]).
answer(number(4),part(b),subpart(i),[77,1,"Cutting down mountain forests that was the bucardos habitat."]).
answer(number(4),part(b),subpart(i),[78,1,"Man have destroyed their natural habitat by cutting down trees with machinery that have crushed the species or not leaving them their natural food + diet."]).
answer(number(4),part(b),subpart(i),[79,1,"Hunting"]).
answer(number(4),part(b),subpart(i),[80,1,"The cutting down of tree's meant that they didn't have a home."]).
answer(number(4),part(b),subpart(i),[81,1,"building on the mountain"]).
answer(number(4),part(b),subpart(i),[82,1,"burning fossil fuels causing acid rain."]).
answer(number(4),part(b),subpart(i),[83,1,"Destroying their habitat by pollution thus reducing the amount of food available to them"]).
answer(number(4),part(b),subpart(i),[84,1,"because of hunting + wanting its fur"]).
answer(number(4),part(b),subpart(i),[85,1,"Deforestation - the cutting down of trees in alpine forests / woods"]).
answer(number(4),part(b),subpart(i),[86,1,"Deforestation, in which man could have destroyed the habitat of the bucardos, or in which trees wouldn't be holding the soil together and so a landslide would be caused by man."]).
answer(number(4),part(b),subpart(i),[87,1,"Hunting the bucardo, for leisure, or for food or its skin."]).
answer(number(4),part(b),subpart(i),[88,1,"Some hunt for the bucado and when they get them, they kill and eat them."]).
answer(number(4),part(b),subpart(i),[89,1,"hunting."]).
answer(number(4),part(b),subpart(i),[90,1,"hunting them for their fur."]).
answer(number(4),part(b),subpart(i),[91,1,"Destroying it's enviroment. Disrupting its general lifestyle by imposing their own on its."]).
answer(number(4),part(b),subpart(i),[92,1,"logging of trees in the mountain."]).
answer(number(4),part(b),subpart(i),[93,1,"Man could have killed the bucardo for its thick fur or meat."]).
answer(number(4),part(b),subpart(i),[94,0,"Climbing the mountains has scared the goats away."]).
answer(number(4),part(b),subpart(i),[95,1,"hunting"]).
answer(number(4),part(b),subpart(i),[96,1,"Deforestation or destroying habbat through pollution is a action which could have decreased the pollulaton"]).
answer(number(4),part(b),subpart(i),[97,1,"cutting down the trees and it fell on the bucardo."]).
answer(number(4),part(b),subpart(i),[98,1,"hunting - the hunter could then use its fur for making of clothes and such a rare fur would be costly."]).
answer(number(4),part(b),subpart(i),[99,1,"Hunting them for thier meat, could be a speciality or delicassy of some sort."]).
answer(number(4),part(b),subpart(i),[100,1,"It may have been hunting of bucardo."]).
answer(number(4),part(b),subpart(i),[101,1,"cutting down more trees and more carbon dioxide being produced."]).
answer(number(4),part(b),subpart(i),[102,1,"man could maybe shoot them for meat or for skins or for their fur."]).
answer(number(4),part(b),subpart(i),[103,1,"causing rocks to fall by surveying up their or climing"]).
answer(number(4),part(b),subpart(i),[104,1,"hunting the bucardos"]).
answer(number(4),part(b),subpart(i),[105,0,"the female brucado who has been crused under a tree"]).
answer(number(4),part(b),subpart(i),[106,1,"Cutting down trees"]).
answer(number(4),part(b),subpart(i),[107,1,"levelling of mountain sides to grow crops"]).
answer(number(4),part(b),subpart(i),[108,1,"Hunting for the fur to make clothes & accessories"]).
answer(number(4),part(b),subpart(i),[109,1,"Cutting down trees for fuel or for furniture."]).
answer(number(4),part(b),subpart(i),[110,1,"people could of killed the bucardo for food."]).
answer(number(4),part(b),subpart(i),[111,1,"Killing them for there fur"]).
answer(number(4),part(b),subpart(i),[112,1,"Hunting could have been one of these actions & would have decreased the number of bucardos."]).
answer(number(4),part(b),subpart(i),[113,1,"humans might of shot the bucardos to get their curved hooves."]).
answer(number(4),part(b),subpart(i),[114,1,"hunting"]).
answer(number(4),part(b),subpart(i),[115,1,"hunting of bucardos as sport or for its fur or meat."]).
answer(number(4),part(b),subpart(i),[116,1,"Hunting"]).
answer(number(4),part(b),subpart(i),[117,1,"hunting them for their thick fur."]).
answer(number(4),part(b),subpart(i),[118,1,"killing them for their fur."]).
answer(number(4),part(b),subpart(i),[119,1,"destruction of habitat."]).
answer(number(4),part(b),subpart(i),[120,1,"The killing of these goats for meat"]).
answer(number(4),part(b),subpart(i),[121,1,"shooting the bucardos"]).
answer(number(4),part(b),subpart(i),[122,1,"The goats may have been shot for food."]).
answer(number(4),part(b),subpart(i),[123,1,"killing a bucardo for it's thick fur. It cannot survive without it's fur."]).
answer(number(4),part(b),subpart(i),[124,0,"Too much waste products in the air, not enough oxygen for the bucardo in high mountains where more oxygen is needed."]).
answer(number(4),part(b),subpart(i),[125,1,"Cutting down trees, similar to deforestation"]).
answer(number(4),part(b),subpart(i),[126,1,"Putting up hotels or ski resorts on the mountain."]).
answer(number(4),part(b),subpart(i),[127,1,"Hunting the bucardo for food."]).
answer(number(4),part(b),subpart(i),[128,1,"deforestation (cutting down of trees)"]).
answer(number(4),part(b),subpart(i),[129,1,"hunting the bucardo either for sport or for its fur and other parts of its body."]).
answer(number(4),part(b),subpart(i),[130,1,"Building villages and mines."]).
answer(number(4),part(b),subpart(i),[131,1,"The tree may have been chopped down for wood to put on the fire."]).
answer(number(4),part(b),subpart(i),[132,1,"hunting"]).
answer(number(4),part(b),subpart(i),[133,1,"destroying it's habitat. (environmental change its chance of survival)"]).
answer(number(4),part(b),subpart(i),[134,1,"building and construction"]).
answer(number(4),part(b),subpart(i),[135,1,"cutting down trees in the mountains where they live."]).
answer(number(4),part(b),subpart(i),[136,1,"Hunting the bucardo for it's thick fur."]).
answer(number(4),part(b),subpart(i),[137,1,"Deforestation could have removed trees holding leaves which the Bucardos fed on."]).
answer(number(4),part(b),subpart(i),[138,1,"The actions of man may have involved deforestation which would have destroyed the bucardo's habitat and food supply."]).
answer(number(4),part(b),subpart(i),[139,1,"Man may have shoot the goat to eat or because it was not liked"]).
answer(number(4),part(b),subpart(i),[140,1,"Converting the goats homes in mountainous regions into skiing resorts."]).
answer(number(4),part(b),subpart(i),[141,1,"Destroying their habitat by cutting down the trees that are situated up the mountain."]).
answer(number(4),part(b),subpart(i),[142,1,"Building on the mountains and destroying the bucardos' habitats."]).
answer(number(4),part(b),subpart(i),[143,1,"traps for other animals have cought them instead"]).
answer(number(4),part(b),subpart(i),[144,1,"The bucardo's fur might have been soft enough for use in fur coats so the animal may have been hunted for its pelt; it is warm."]).
answer(number(4),part(b),subpart(i),[145,1,"Hunting / shooting them for food or sport."]).
answer(number(4),part(b),subpart(i),[146,1,"Man may have hunted the bucardo for food and for it's fur as it has nice thick fur, which would be good for fur coats."]).
answer(number(4),part(b),subpart(i),[147,1,"Over hunting to use for food and clothes. People may have killed more animals than they needed and the bucardo would have been unable to reproduce fast enough to bring their numbers back up."]).
answer(number(4),part(b),subpart(i),[148,1,"shooting the goats for meat."]).
answer(number(4),part(b),subpart(i),[149,1,"Hunting the bucardo."]).
answer(number(4),part(b),subpart(i),[150,1,"man could have used the bucardo for food."]).
answer(number(4),part(b),subpart(i),[151,1,"Man may have put roads in the mountains therefore destroying the bucardo's habitat and possibly running them over."]).
answer(number(4),part(b),subpart(i),[152,1,"Hunting"]).
answer(number(4),part(b),subpart(i),[153,1,"Hunting for sport"]).
answer(number(4),part(b),subpart(i),[154,1,"Hunting for their fur or horns for trade"]).
answer(number(4),part(b),subpart(i),[155,1,"Deforestation > destroys the natural habitat of the bucardo and their sources of food."]).
answer(number(4),part(b),subpart(i),[156,1,"developing towns and cities"]).
answer(number(4),part(b),subpart(i),[157,1,"The cutting down of trees."]).
answer(number(4),part(b),subpart(i),[158,1,"Hunting"]).
answer(number(4),part(b),subpart(i),[159,1,"cutting down of trees to maybe make a tourist resorte."]).
answer(number(4),part(b),subpart(i),[160,1,"Hunting"]).
answer(number(4),part(b),subpart(i),[161,1,"hunting, killing in order to eat their meet and sell their fur."]).
answer(number(4),part(b),subpart(i),[162,1,"Hunting of bucardos for meat and skins."]).
answer(number(4),part(b),subpart(i),[163,1,"killed for hunting or eating."]).
answer(number(4),part(b),subpart(i),[164,1,"hunting bucardos for their thick fur for clothing."]).
answer(number(4),part(b),subpart(i),[165,1,"the men might have hunted and ate the goats."]).
answer(number(4),part(b),subpart(i),[166,1,"Distroying trees and surrounding of bucardos habitate."]).
answer(number(4),part(b),subpart(i),[167,1,"killing the bucardo to use its fur to make clothing."]).
answer(number(4),part(b),subpart(i),[168,1,"The population of men in it's enviroment giving it no place to live or feed in peace."]).
answer(number(4),part(b),subpart(i),[169,1,"hunting."]).
answer(number(4),part(b),subpart(i),[170,1,"They could have been killed for their fur or hooves."]).
answer(number(4),part(b),subpart(i),[171,1,"Hunting"]).
answer(number(4),part(b),subpart(i),[172,1,"by building on the mountains and destroying their habitat."]).
answer(number(4),part(b),subpart(i),[173,1,"humans may have hunted the bucardos."]).
answer(number(4),part(b),subpart(i),[174,1,"Hunting them for food."]).
answer(number(4),part(b),subpart(i),[175,0,"landslides"]).
answer(number(4),part(b),subpart(i),[176,1,"hunting the bucardo for food."]).
answer(number(4),part(b),subpart(i),[177,1,"This decrease in bucardos could be due to hunting by man."]).
answer(number(4),part(b),subpart(i),[178,1,"Hunting for it, and acid rain could of killed it"]).
answer(number(4),part(b),subpart(i),[179,1,"Hunting, for it's fur, the hooves or for food."]).
answer(number(4),part(b),subpart(i),[180,1,"Destroying its habitat by cutting down trees etc so it looses sources of food and shelter."]).
answer(number(4),part(b),subpart(i),[181,1,"Kill them for their thick fur to make rugs."]).
answer(number(4),part(b),subpart(i),[182,1,"killing the bucardo for food or hunting reasons (enjoyment)"]).
answer(number(4),part(b),subpart(i),[183,1,"Killing it to eat it."]).
answer(number(4),part(b),subpart(i),[184,1,"killing then for food, experiments, fur etc."]).
answer(number(4),part(b),subpart(i),[185,1,"They may have been disturbed when men were climbing the mountains, leaving their young to survive by themselves, and dying."]).
answer(number(4),part(b),subpart(i),[186,1,"man may have begun building on the mountain which would have disrupted the bucardo's habitat."]).
answer(number(4),part(b),subpart(i),[187,1,"hunting the bucardos for sport."]).
answer(number(4),part(b),subpart(i),[188,1,"mountain climbing eating the goat for food."]).
answer(number(4),part(b),subpart(i),[189,1,"hunting for fur and meat."]).
answer(number(4),part(b),subpart(i),[190,1,"Deforestation"]).
answer(number(4),part(b),subpart(i),[191,1,"killing the goats and using the carcus for meat & the coat for clothing. Humans could have distroyed the goats habitat."]).
answer(number(4),part(b),subpart(i),[192,1,"hunting for goat's fur to make clothes and for the meat for food."]).
answer(number(4),part(b),subpart(i),[193,1,"killed for food"]).
answer(number(4),part(b),subpart(i),[194,1,"hunting the bucardo for its meat."]).
answer(number(4),part(b),subpart(i),[195,0,"mountain climbers would have scared the bucardo which could have moved them from their homes."]).
answer(number(4),part(b),subpart(i),[196,0,"1 action may have been nutrition"]).
answer(number(4),part(b),subpart(i),[197,0,"Trampling on the grass & vegetation that the goat would eat."]).
answer(number(4),part(b),subpart(i),[198,0,"growth of trees in the bucardo habitat."]).
answer(number(4),part(b),subpart(i),[199,0,"landslides a natural disaster."]).
answer(number(4),part(b),subpart(i),[200,0,"because of all the landslides"]).

 
