:- multifile answer/4.

answer(number(2),part(b),subpart(iii),[1,1,"In veins all over the circulartory system"]).
answer(number(2),part(b),subpart(iii),[2,1,"In veins that carry deoxygenated blood, this is also to prevent a backflow of blood."]).
answer(number(2),part(b),subpart(iii),[3,0,"bronchioles."]).
answer(number(2),part(b),subpart(iii),[4,0,"In the lungs."]).
answer(number(2),part(b),subpart(iii),[5,0,"in the artiries"]).
answer(number(2),part(b),subpart(iii),[6,1,"veins"]).
answer(number(2),part(b),subpart(iii),[7,0,"In the arteries."]).
answer(number(2),part(b),subpart(iii),[8,0,"lungs"]).
answer(number(2),part(b),subpart(iii),[9,0,"neck."]).
answer(number(2),part(b),subpart(iii),[10,1,"veins contain watch-pocket valves"]).
answer(number(2),part(b),subpart(iii),[11,1,"Veins"]).
answer(number(2),part(b),subpart(iii),[12,0,"through mouth"]).
answer(number(2),part(b),subpart(iii),[13,0,"lungs"]).
answer(number(2),part(b),subpart(iii),[14,1,"veins"]).
answer(number(2),part(b),subpart(iii),[15,0,"In the arteries."]).
answer(number(2),part(b),subpart(iii),[16,0,"veins and arteries."]).
answer(number(2),part(b),subpart(iii),[17,0,"in the main artery."]).
answer(number(2),part(b),subpart(iii),[18,0,"in lung, brin, kidneys."]).
answer(number(2),part(b),subpart(iii),[19,1,"In the veins"]).
answer(number(2),part(b),subpart(iii),[20,1,"In veins."]).
answer(number(2),part(b),subpart(iii),[21,0,"Pulmonary artery + aorta"]).
answer(number(2),part(b),subpart(iii),[22,0,"In the trachea to stop food going into your lungs"]).
answer(number(2),part(b),subpart(iii),[23,1,"Veins."]).
answer(number(2),part(b),subpart(iii),[24,1,"Veins."]).
answer(number(2),part(b),subpart(iii),[25,0,"Just under the stomach where the small intestines are."]).
answer(number(2),part(b),subpart(iii),[26,0,"Ventricals"]).
answer(number(2),part(b),subpart(iii),[27,1,"In veins."]).
answer(number(2),part(b),subpart(iii),[28,0,"everywhere in your body."]).
answer(number(2),part(b),subpart(iii),[29,0,"in the lungs."]).
answer(number(2),part(b),subpart(iii),[30,1,"In veins"]).
answer(number(2),part(b),subpart(iii),[31,1,"In the veins."]).
answer(number(2),part(b),subpart(iii),[32,0,"in the throat"]).
answer(number(2),part(b),subpart(iii),[33,0,"in our capillaries."]).
answer(number(2),part(b),subpart(iii),[34,0,"In the lungs"]).
answer(number(2),part(b),subpart(iii),[35,0,"Valves can also be found in Arteries."]).
answer(number(2),part(b),subpart(iii),[36,0,"stomach"]).
answer(number(2),part(b),subpart(iii),[37,0,"arteries."]).
answer(number(2),part(b),subpart(iii),[38,0,"lungs?"]).
answer(number(2),part(b),subpart(iii),[39,1,"In the veins"]).
answer(number(2),part(b),subpart(iii),[40,0,"arteries"]).
answer(number(2),part(b),subpart(iii),[41,1,"Valves are found in veins where blood is at low pressure."]).
answer(number(2),part(b),subpart(iii),[42,1,"In the veins."]).
answer(number(2),part(b),subpart(iii),[43,0,"arteries"]).
answer(number(2),part(b),subpart(iii),[44,1,"In veins"]).
answer(number(2),part(b),subpart(iii),[45,1,"In the veins to stop blood flowing backwards"]).
answer(number(2),part(b),subpart(iii),[46,0,"in the chambers."]).
answer(number(2),part(b),subpart(iii),[47,0,"In the lungs"]).
answer(number(2),part(b),subpart(iii),[48,0,"Lungs."]).
answer(number(2),part(b),subpart(iii),[49,0,"arteries"]).
answer(number(2),part(b),subpart(iii),[50,0,"pancreas"]).
answer(number(2),part(b),subpart(iii),[51,0,"In the capilleries."]).
answer(number(2),part(b),subpart(iii),[52,1,"in the veins"]).
answer(number(2),part(b),subpart(iii),[53,1,"In veins."]).
answer(number(2),part(b),subpart(iii),[54,1,"veins"]).
answer(number(2),part(b),subpart(iii),[55,0,"lungs."]).
answer(number(2),part(b),subpart(iii),[56,1,"veins."]).
answer(number(2),part(b),subpart(iii),[57,0,"in your lungs"]).
answer(number(2),part(b),subpart(iii),[58,0,"In the anus (sphincters) to prevent faeces coming out all the time."]).
answer(number(2),part(b),subpart(iii),[59,1,"In veins."]).
answer(number(2),part(b),subpart(iii),[60,1,"In veins."]).
answer(number(2),part(b),subpart(iii),[61,0,"Arteries."]).
answer(number(2),part(b),subpart(iii),[62,1,"veins"]).
answer(number(2),part(b),subpart(iii),[63,1,"veins"]).
answer(number(2),part(b),subpart(iii),[64,0,"lungs"]).
answer(number(2),part(b),subpart(iii),[65,0,"in the lungs"]).
answer(number(2),part(b),subpart(iii),[66,0,"Lungs."]).
answer(number(2),part(b),subpart(iii),[67,0,"liver."]).
answer(number(2),part(b),subpart(iii),[68,0,"in the brain"]).
answer(number(2),part(b),subpart(iii),[69,0,"kidney."]).
answer(number(2),part(b),subpart(iii),[70,1,"In the veins"]).
answer(number(2),part(b),subpart(iii),[71,0,"pancreas"]).
answer(number(2),part(b),subpart(iii),[72,1,"in the veins."]).
answer(number(2),part(b),subpart(iii),[73,0,"in the lungs"]).
answer(number(2),part(b),subpart(iii),[74,0,"lungs."]).
answer(number(2),part(b),subpart(iii),[75,0,"In veins and arteries."]).
answer(number(2),part(b),subpart(iii),[76,1,"in the veins"]).
answer(number(2),part(b),subpart(iii),[77,0,"the kidneys."]).
answer(number(2),part(b),subpart(iii),[78,0,"in the lungs."]).
answer(number(2),part(b),subpart(iii),[79,0,"arteries"]).
answer(number(2),part(b),subpart(iii),[80,0,"throat"]).
answer(number(2),part(b),subpart(iii),[81,1,"veins"]).
answer(number(2),part(b),subpart(iii),[82,1,"in veins."]).
answer(number(2),part(b),subpart(iii),[83,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[84,1,"in the veins"]).
answer(number(2),part(b),subpart(iii),[85,1,"In veins"]).
answer(number(2),part(b),subpart(iii),[86,1,"in veins."]).
answer(number(2),part(b),subpart(iii),[87,1,"In veins"]).
answer(number(2),part(b),subpart(iii),[88,1,"Valves are also found in the veins."]).
answer(number(2),part(b),subpart(iii),[89,1,"in veins."]).
answer(number(2),part(b),subpart(iii),[90,1,"veins"]).
answer(number(2),part(b),subpart(iii),[91,1,"In some veins."]).
answer(number(2),part(b),subpart(iii),[92,1,"veins"]).
answer(number(2),part(b),subpart(iii),[93,1,"Valves are found in veins which help the blood to flow in the right direction when taking deoxygenated blood towards the heart."]).
answer(number(2),part(b),subpart(iii),[94,1,"veins"]).
answer(number(2),part(b),subpart(iii),[95,1,"Main Veins returning the blood up to the heart"]).
answer(number(2),part(b),subpart(iii),[96,1,"veins."]).
answer(number(2),part(b),subpart(iii),[97,1,"In the veins, because they are at low pressure."]).
answer(number(2),part(b),subpart(iii),[98,1,"the vains in your arms."]).
answer(number(2),part(b),subpart(iii),[99,1,"Veins"]).
answer(number(2),part(b),subpart(iii),[100,1,"in veins (the pulmonary vein)"]).
answer(number(2),part(b),subpart(iii),[101,1,"in the veins."]).
answer(number(2),part(b),subpart(iii),[102,1,"veins"]).
answer(number(2),part(b),subpart(iii),[103,1,"in veins - watch-pocket valves"]).
answer(number(2),part(b),subpart(iii),[104,1,"veins."]).
answer(number(2),part(b),subpart(iii),[105,1,"veins"]).
answer(number(2),part(b),subpart(iii),[106,1,"veins"]).
answer(number(2),part(b),subpart(iii),[107,1,"In the veins."]).
answer(number(2),part(b),subpart(iii),[108,1,"viens."]).
answer(number(2),part(b),subpart(iii),[109,1,"in the veins"]).
answer(number(2),part(b),subpart(iii),[110,1,"In the veins."]).
answer(number(2),part(b),subpart(iii),[111,1,"veins."]).
answer(number(2),part(b),subpart(iii),[112,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[113,1,"In veins."]).
answer(number(2),part(b),subpart(iii),[114,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[115,1,"veins"]).
answer(number(2),part(b),subpart(iii),[116,1,"In veins."]).
answer(number(2),part(b),subpart(iii),[117,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[118,1,"in the veins"]).
answer(number(2),part(b),subpart(iii),[119,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[120,1,"Vena Cava"]).
answer(number(2),part(b),subpart(iii),[121,1,"veins"]).
answer(number(2),part(b),subpart(iii),[122,1,"veins"]).
answer(number(2),part(b),subpart(iii),[123,1,"in veins."]).
answer(number(2),part(b),subpart(iii),[124,1,"veins"]).
answer(number(2),part(b),subpart(iii),[125,1,"in the veins."]).
answer(number(2),part(b),subpart(iii),[126,1,"In veins"]).
answer(number(2),part(b),subpart(iii),[127,1,"veins"]).
answer(number(2),part(b),subpart(iii),[128,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[129,1,"In your veins"]).
answer(number(2),part(b),subpart(iii),[130,1,"Veins"]).
answer(number(2),part(b),subpart(iii),[131,1,"veins"]).
answer(number(2),part(b),subpart(iii),[132,1,"veins"]).
answer(number(2),part(b),subpart(iii),[133,1,"in the veins"]).
answer(number(2),part(b),subpart(iii),[134,1,"In the veins to keep the blood flowing the right way."]).
answer(number(2),part(b),subpart(iii),[135,1,"in veins."]).
answer(number(2),part(b),subpart(iii),[136,1,"In the veins."]).
answer(number(2),part(b),subpart(iii),[137,0,"at the end of the veins and arteries"]).
answer(number(2),part(b),subpart(iii),[138,1,"in veins (venae cavae) to prevent backflow."]).
answer(number(2),part(b),subpart(iii),[139,1,"Veins."]).
answer(number(2),part(b),subpart(iii),[140,1,"veins."]).
answer(number(2),part(b),subpart(iii),[141,1,"In veins"]).
answer(number(2),part(b),subpart(iii),[142,1,"veins."]).
answer(number(2),part(b),subpart(iii),[143,1,"Valves are also found in veins."]).
answer(number(2),part(b),subpart(iii),[144,1,"veins."]).
answer(number(2),part(b),subpart(iii),[145,1,"Veins have valves"]).
answer(number(2),part(b),subpart(iii),[146,1,"in the veins"]).
answer(number(2),part(b),subpart(iii),[147,1,"in veins."]).
answer(number(2),part(b),subpart(iii),[148,1,"veins"]).
answer(number(2),part(b),subpart(iii),[149,1,"veins blood vessles."]).
answer(number(2),part(b),subpart(iii),[150,1,"veins"]).
answer(number(2),part(b),subpart(iii),[151,1,"In the veins."]).
answer(number(2),part(b),subpart(iii),[152,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[153,1,"In the veins."]).
answer(number(2),part(b),subpart(iii),[154,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[155,1,"In veins in the body, like the legs."]).
answer(number(2),part(b),subpart(iii),[156,1,"in veins."]).
answer(number(2),part(b),subpart(iii),[157,1,"In viens (particularly when leading to the heart) where there is low pressure."]).
answer(number(2),part(b),subpart(iii),[158,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[159,1,"in the veins."]).
answer(number(2),part(b),subpart(iii),[160,1,"Veins."]).
answer(number(2),part(b),subpart(iii),[161,1,"veins"]).
answer(number(2),part(b),subpart(iii),[162,1,"In veins."]).
answer(number(2),part(b),subpart(iii),[163,1,"veins"]).
answer(number(2),part(b),subpart(iii),[164,1,"The veins."]).
answer(number(2),part(b),subpart(iii),[165,1,"veins"]).
answer(number(2),part(b),subpart(iii),[166,1,"In the veins"]).
answer(number(2),part(b),subpart(iii),[167,1,"The veins have valves"]).
answer(number(2),part(b),subpart(iii),[168,1,"veins"]).
answer(number(2),part(b),subpart(iii),[169,1,"Veins."]).
answer(number(2),part(b),subpart(iii),[170,1,"In the veins"]).
answer(number(2),part(b),subpart(iii),[171,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[172,1,"in the veins."]).
answer(number(2),part(b),subpart(iii),[173,1,"in the veins"]).
answer(number(2),part(b),subpart(iii),[174,1,"Veins"]).
answer(number(2),part(b),subpart(iii),[175,1,"veins."]).
answer(number(2),part(b),subpart(iii),[176,1,"in veins."]).
answer(number(2),part(b),subpart(iii),[177,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[178,1,"In the veins."]).
answer(number(2),part(b),subpart(iii),[179,1,"In the veins."]).
answer(number(2),part(b),subpart(iii),[180,1,"In veins."]).
answer(number(2),part(b),subpart(iii),[181,1,"In veins."]).
answer(number(2),part(b),subpart(iii),[182,1,"In the veins"]).
answer(number(2),part(b),subpart(iii),[183,1,"In the veins in arms + legs and most of the body"]).
answer(number(2),part(b),subpart(iii),[184,1,"veins"]).
answer(number(2),part(b),subpart(iii),[185,1,"veins in the legs"]).
answer(number(2),part(b),subpart(iii),[186,1,"veins"]).
answer(number(2),part(b),subpart(iii),[187,1,"in your veins"]).
answer(number(2),part(b),subpart(iii),[188,1,"in your veins."]).
answer(number(2),part(b),subpart(iii),[189,1,"veins"]).
answer(number(2),part(b),subpart(iii),[190,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[191,1,"in the veins."]).
answer(number(2),part(b),subpart(iii),[192,1,"veins in the leg."]).
answer(number(2),part(b),subpart(iii),[193,1,"in the veins."]).
answer(number(2),part(b),subpart(iii),[194,1,"In veins."]).
answer(number(2),part(b),subpart(iii),[195,1,"in veins"]).
answer(number(2),part(b),subpart(iii),[196,1,"in viens"]).
answer(number(2),part(b),subpart(iii),[197,1,"in your veins"]).
answer(number(2),part(b),subpart(iii),[198,1,"In the veins."]).
answer(number(2),part(b),subpart(iii),[199,1,"veins"]).
answer(number(2),part(b),subpart(iii),[200,1,"in veins"]).

 
