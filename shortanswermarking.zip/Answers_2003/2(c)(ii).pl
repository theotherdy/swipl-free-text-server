
:- multifile answer/4.

answer(number(2),part(c),subpart(ii),[1,1,"Harvey lived much later than Galen, where communications and travel were much improved."]).
answer(number(2),part(c),subpart(ii),[2,0,"They made more sense."]).
answer(number(2),part(c),subpart(ii),[3,1,"Galen lived many years ago when few people could read or took any interest in science, in Harvey's time more people were educated and read about scientific discoveries"]).
answer(number(2),part(c),subpart(ii),[4,1,"He was born later than Galen and so he had better communications eg, books."]).
answer(number(2),part(c),subpart(ii),[5,0,"Galen did not have as much scientific evidence to back up his ideas and so they may have seemed less believable."]).
answer(number(2),part(c),subpart(ii),[6,0,"Medical research backed up Harvey's ideas."]).
answer(number(2),part(c),subpart(ii),[7,1,"Galen was alive over 1000 years before Harvey was born and communication methods were not as good in Galen's times."]).
answer(number(2),part(c),subpart(ii),[8,0,"He had more proof"]).
answer(number(2),part(c),subpart(ii),[9,0,"because he had more evidence"]).
answer(number(2),part(c),subpart(ii),[10,0,"They were more substancial as they were based on better evidence carried out in laboratories"]).
answer(number(2),part(c),subpart(ii),[11,0,"William Harvey was a doctor so people trusted him"]).
answer(number(2),part(c),subpart(ii),[12,0,"He was a doctor and so .: many people trusted his ideas on circulation more than a scientist."]).
answer(number(2),part(c),subpart(ii),[13,1,"he published books about his ideas"]).
answer(number(2),part(c),subpart(ii),[14,0,"There were many more scientists and doctors to whom Harvey could tell his theories too which could then be spread around."]).
answer(number(2),part(c),subpart(ii),[15,0,"Galen's theory was similar to that of a fish's circulatory system and people understood they were different from a fish."]).
answer(number(2),part(c),subpart(ii),[16,0,"He may have lived longer."]).
answer(number(2),part(c),subpart(ii),[17,0,"Because there were more methods and equipment to gather evidence in Harvey's time and so there would be more to convince people with."]).
answer(number(2),part(c),subpart(ii),[18,0,"Harvey proved his ideas"]).
answer(number(2),part(c),subpart(ii),[19,0,"He was a doctor and so people believed in him more."]).
answer(number(2),part(c),subpart(ii),[20,0,"Harveys Ideas were more believeable than Galens Idea."]).
answer(number(2),part(c),subpart(ii),[21,0,"because you could feel the blood pumping around your body."]).
answer(number(2),part(c),subpart(ii),[22,0,"made more sence."]).
answer(number(2),part(c),subpart(ii),[23,0,"Harvey proved all of his theorm"]).
answer(number(2),part(c),subpart(ii),[24,0,"Harveys was more detailed and proved it by carrying out experiments."]).
answer(number(2),part(c),subpart(ii),[25,0,"more people interested."]).
answer(number(2),part(c),subpart(ii),[26,0,"His ideas were realistic and easy to belive and understand."]).
answer(number(2),part(c),subpart(ii),[27,0,"galens idea was more believable"]).
answer(number(2),part(c),subpart(ii),[28,0,"It was more realistic"]).
answer(number(2),part(c),subpart(ii),[29,0,"Because he was English."]).
answer(number(2),part(c),subpart(ii),[30,0,"It made more sense."]).
answer(number(2),part(c),subpart(ii),[31,0,"he had more connections."]).
answer(number(2),part(c),subpart(ii),[32,0,"It was a much more logical idea that had been proved."]).
answer(number(2),part(c),subpart(ii),[33,0,"Radio was invented and so more people heard about it."]).
answer(number(2),part(c),subpart(ii),[34,0,"People were starting to trust sciencetists more at that time"]).
answer(number(2),part(c),subpart(ii),[35,0,"working better than Galen"]).
answer(number(2),part(c),subpart(ii),[36,0,"Because he was a doctor."]).
answer(number(2),part(c),subpart(ii),[37,0,"He had years worth of evidence (from experiments) to prove his ideas."]).
answer(number(2),part(c),subpart(ii),[38,0,"William Harvey was also English whereas Galen was not - he was Greek & english was a language better known than Greek."]).
answer(number(2),part(c),subpart(ii),[39,0,"He was English"]).
answer(number(2),part(c),subpart(ii),[40,1,"He publised his ideas."]).
answer(number(2),part(c),subpart(ii),[41,1,"More publications of his theories and ideas than in Galen's time."]).
answer(number(2),part(c),subpart(ii),[42,0,"It seemed more logical to believe in Harvey's theory."]).
answer(number(2),part(c),subpart(ii),[43,0,"seemed more understanding"]).
answer(number(2),part(c),subpart(ii),[44,0,"Harveys ideas were more belivable."]).
answer(number(2),part(c),subpart(ii),[45,0,"Were more realistic, had more sense and reasoning behind them."]).
answer(number(2),part(c),subpart(ii),[46,0,"It spread because he was the latest to discover the circulation of blood by which people started to believe."]).
answer(number(2),part(c),subpart(ii),[47,0,"Harvey was more believed because he could back up his ideas with evidence"]).
answer(number(2),part(c),subpart(ii),[48,0,"They were more reliable and made more sense."]).
answer(number(2),part(c),subpart(ii),[49,0,"scientific experiment by challenging Galen's ideas to be wrong."]).
answer(number(2),part(c),subpart(ii),[50,1,"There were more scientic journels and papers in Harvey's time to spread ideas."]).
answer(number(2),part(c),subpart(ii),[51,1,"Communication was more advanced when Harvey was alive compared to when Galen was alive"]).
answer(number(2),part(c),subpart(ii),[52,1,"People travelled more in Harvey's time, and so could go to England and hear his ideas, more than people travelled in Galen's time."]).
answer(number(2),part(c),subpart(ii),[53,0,"had more money than him to do better experiments"]).
answer(number(2),part(c),subpart(ii),[54,0,"They made more sence"]).
answer(number(2),part(c),subpart(ii),[55,0,"Because he had proof he was able to dissect a human being."]).
answer(number(2),part(c),subpart(ii),[56,0,"because he was a doctor"]).
answer(number(2),part(c),subpart(ii),[57,1,"Harvey was alive later than Galen thus transport had improved so transport carrying his ideas got around faster Whereas Galen ideas only really spread by word of mouth which took longer"]).
answer(number(2),part(c),subpart(ii),[58,0,"He had got evidence and facts."]).
answer(number(2),part(c),subpart(ii),[59,2,"By the time of Harvey communication between scientists, through books & conventions and letters, had improved."]).
answer(number(2),part(c),subpart(ii),[60,0,"Because when Harvey was alive technology was available for careful observations and experimentation of the body, thus his ideas could be proved, meaning that people were more willing to accept them and to pass them on."]).
answer(number(2),part(c),subpart(ii),[61,0,"His idea was more logical"]).
answer(number(2),part(c),subpart(ii),[62,0,"Harvey's ideas spead faster because it was revelutionary"]).
answer(number(2),part(c),subpart(ii),[63,0,"Harvey had more proof and his ideas made more sense than Galen's."]).
answer(number(2),part(c),subpart(ii),[64,1,"He was able to publish in widely-distributed journals"]).
answer(number(2),part(c),subpart(ii),[65,1,"Communications were better when Harvey made his discoveries. eg printing press."]).
answer(number(2),part(c),subpart(ii),[66,1,"Harvey published his work."]).
answer(number(2),part(c),subpart(ii),[67,1,"Development of books"]).
answer(number(2),part(c),subpart(ii),[68,1,"In Galen's time, communications may have been much slower and less advanced than in Harvey's time as Galen lived over a hundred years earlier."]).
answer(number(2),part(c),subpart(ii),[69,1,"There were more means with which to get in touch with people such as national newspapers, in Harveys time."]).
answer(number(2),part(c),subpart(ii),[70,1,"because he showed deminstrations and wrote books"]).
answer(number(2),part(c),subpart(ii),[71,1,"Transportation was better steam trains"]).
answer(number(2),part(c),subpart(ii),[72,1,"Spoke at big University lectures."]).
answer(number(2),part(c),subpart(ii),[73,2,"Better communications - existence of the printing press allowing Harvey's ideas to be published"]).
answer(number(2),part(c),subpart(ii),[74,1,"More people were able to read and therefore Harvey's ideas spread faster."]).
answer(number(2),part(c),subpart(ii),[75,1,"Newspapers were more widely available."]).
answer(number(2),part(c),subpart(ii),[76,1,"Communications technology was faster and better developed"]).
answer(number(2),part(c),subpart(ii),[77,1,"Communications had improved since Galen's time and so news travelled faster through better transport. Harvey worked at the Royal Court which would have meant any of his discoveries would quickly spread."]).
answer(number(2),part(c),subpart(ii),[78,1,"There was more interest in Harvey's day because more people were educated"]).
answer(number(2),part(c),subpart(ii),[79,1,"Harvey lived in an age where the printing press meant greater circulation of ideas."]).
answer(number(2),part(c),subpart(ii),[80,1,"During the time Harvey lived, there was more media focus. He could tell people about it via newspapers, magazines, which were not so readily available in Galen's time."]).
answer(number(2),part(c),subpart(ii),[81,1,"Information spread faster because more educated people were able to travel and thus pass on Harvey's ideas than they had been able to in Galen's time. 3) His ideas made sense and were backed with a lot of evidence unlike Galen who had provided little proo"]).
answer(number(2),part(c),subpart(ii),[82,1,"more people could read and write therefor more people understood"]).
answer(number(2),part(c),subpart(ii),[83,0,"Advanced Society - TV, Radio etc."]).
answer(number(2),part(c),subpart(ii),[84,1,"Harvey was born later than Galen in 1578 and lived until 1657 - there was better forms of communication - to write his theories down & display them & better technology to test his theories."]).
answer(number(2),part(c),subpart(ii),[85,1,"More communications links."]).
answer(number(2),part(c),subpart(ii),[86,1,"his ideas came later when communication was more advanced."]).
answer(number(2),part(c),subpart(ii),[87,0,"There was more communication i.e. radios + TV."]).
answer(number(2),part(c),subpart(ii),[88,1,"He published his ideas in a medical journal"]).
answer(number(2),part(c),subpart(ii),[89,1,"he published his work unlik Galen"]).
answer(number(2),part(c),subpart(ii),[90,1,"Because Printing had been invented and so more of his books were Fabricated."]).
answer(number(2),part(c),subpart(ii),[91,1,"Galen existed around 100 years earlier when books were more difficult to make - books could spread ideas"]).
answer(number(2),part(c),subpart(ii),[92,1,"media-newspapers were now invented, so it could have been published."]).
answer(number(2),part(c),subpart(ii),[93,1,"As harvey was born long after Galen and communication was easyier at this time."]).
answer(number(2),part(c),subpart(ii),[94,1,"Harvey's ideas could be printed and published in the form of a book."]).
answer(number(2),part(c),subpart(ii),[95,1,"He could publish his ideas"]).
answer(number(2),part(c),subpart(ii),[96,1,"He wrote it down in books and drew detailed diagrams about circulation."]).
answer(number(2),part(c),subpart(ii),[97,1,"There were better communications between scientists in the 1600s-scientific journals."]).
answer(number(2),part(c),subpart(ii),[98,1,"Because Harvey lived later than Galen he was able to spread them more easily through pamphlets etc."]).
answer(number(2),part(c),subpart(ii),[99,1,"Harvey produced a book and the printing press helped to make it widely available."]).
answer(number(2),part(c),subpart(ii),[100,1,"Harvey was born at a later date when technolog would have been more advanced so that he could send his papers and ideas to other parts of the world much faster."]).
answer(number(2),part(c),subpart(ii),[101,0,"The printing press"]).
answer(number(2),part(c),subpart(ii),[102,1,"In Harvey's time there was a printing press so his ideas could be published and reach people that way."]).
answer(number(2),part(c),subpart(ii),[103,1,"Harvey could publish his ideas to reach other doctors."]).
answer(number(2),part(c),subpart(ii),[104,1,"Galen lived in the Roman times and they could not publish journals or books like they could in Harvey's time."]).
answer(number(2),part(c),subpart(ii),[105,1,"There were more established communities of scientists in Harvey's time, where scientist could exchange ideas."]).
answer(number(2),part(c),subpart(ii),[106,1,"The printing press made publishing ideas possible, so leaflets and text books could teach others."]).
answer(number(2),part(c),subpart(ii),[107,1,"Harvey lived much later than Galen so by his time transport and communications had improved so his ideas could be spread much more quickly."]).
answer(number(2),part(c),subpart(ii),[108,1,"Harvey came up with his idea much later than Galen - communication between scienticists was which improved."]).
answer(number(2),part(c),subpart(ii),[109,1,"In Harveys time communication links were more developed, and science was more developed� people would accept new ideas more readily"]).
answer(number(2),part(c),subpart(ii),[110,1,"Harvey wrote a book with his ideas and they therefore were published he also gave speeches Galen did not."]).
answer(number(2),part(c),subpart(ii),[111,1,"He published a book about his discovery"]).
answer(number(2),part(c),subpart(ii),[112,1,"Communication and science flourished under Queen Elizabeth and new ideas were encouraged."]).
answer(number(2),part(c),subpart(ii),[113,0,"he was more well known and doctor."]).
answer(number(2),part(c),subpart(ii),[114,1,"his ideas were written down with theory to back them up."]).
answer(number(2),part(c),subpart(ii),[115,1,"He was born later on, when science was more widely practised and there was a larger scientific community, so ideas were shared."]).
answer(number(2),part(c),subpart(ii),[116,1,"Galen was around before there were medical journals published to inform others of scientific discoveries."]).
answer(number(2),part(c),subpart(ii),[117,1,"he published them and people where more likely to accept new ideas in that day, previously the religious views may have got in the way"]).
answer(number(2),part(c),subpart(ii),[118,1,"He lived later than Galen when there were better communications."]).
answer(number(2),part(c),subpart(ii),[119,0,"More advanced technology in Harvey's time, such as printing."]).
answer(number(2),part(c),subpart(ii),[120,1,"Scientific research was more valued in Harvey's time - his work could be published and people believed it. Science considered more important, so his work was Harveys more publicized."]).
answer(number(2),part(c),subpart(ii),[121,1,"Because he wrote a book about his theory which many people read,"]).
answer(number(2),part(c),subpart(ii),[122,1,"Galen lived in a time where news didn't spread quickly because of limitations in technology."]).
answer(number(2),part(c),subpart(ii),[123,1,"Because news travelled faster then it did with Galen."]).
answer(number(2),part(c),subpart(ii),[124,1,"Because technology was better so word was spread quicker in books"]).
answer(number(2),part(c),subpart(ii),[125,1,"Better technology than in Galen's day newsprints were made faster."]).
answer(number(2),part(c),subpart(ii),[126,0,"He had greater technology than Galen with which to spread the news."]).
answer(number(2),part(c),subpart(ii),[127,1,"News could have spread by people being told in the local newspapers."]).
answer(number(2),part(c),subpart(ii),[128,1,"Had publishing so newspapers could report his ideas and he could publish them."]).
answer(number(2),part(c),subpart(ii),[129,1,"He wrote down his theories for people to see and his ideas were more acceptable for belief as he carried out autopsyes on the dead to prove his ideas."]).
answer(number(2),part(c),subpart(ii),[130,1,"There was press and therefore newspapers and books which would reach many people."]).
answer(number(2),part(c),subpart(ii),[131,2,"Communications had improved so when Harvey's work was published it was available to more people."]).
answer(number(2),part(c),subpart(ii),[132,0,"at that time there was the media and advertisement such as the news and television and newspapars."]).
answer(number(2),part(c),subpart(ii),[133,1,"Printing press allowed ideas to spread quicker than ever before."]).
answer(number(2),part(c),subpart(ii),[134,0,"There was better technology but not brilliant."]).
answer(number(2),part(c),subpart(ii),[135,0,"More people believed him. He broke a law so it spread through gossip."]).
answer(number(2),part(c),subpart(ii),[136,0,"Better technology to spread his ideas."]).
answer(number(2),part(c),subpart(ii),[137,1,"He was working more recently so he was able to publish articles and write letters that got to people faster."]).
answer(number(2),part(c),subpart(ii),[138,0,"He traveled round the world and showed every one his ideas"]).
answer(number(2),part(c),subpart(ii),[139,1,"More communication was available"]).
answer(number(2),part(c),subpart(ii),[140,1,"Harvey lived later than Galen - he could travel easier to give lectures to more people."]).
answer(number(2),part(c),subpart(ii),[141,1,"because technology had moved on and there were way of communicating"]).
answer(number(2),part(c),subpart(ii),[142,0,"the printing press wAs now AvAilAble"]).
answer(number(2),part(c),subpart(ii),[143,0,"Putting on exibitions to prove his theories."]).
answer(number(2),part(c),subpart(ii),[144,1,"Because communications were better in Harvey's time."]).
answer(number(2),part(c),subpart(ii),[145,1,"Galen made his ideas known centuries before Harvey - so by Harvey's time more advanced communications meant that news travelled faster."]).
answer(number(2),part(c),subpart(ii),[146,1,"Havey was borned after Galen, so the communication links were much better. and information can be spread faster."]).
answer(number(2),part(c),subpart(ii),[147,1,"Harvey published a book on circulation in the body : to widespread audience. In Galen's lifetime there was no way to copy information to such an extent."]).
answer(number(2),part(c),subpart(ii),[148,1,"More logical to comprehend. Harvey wrote books on his theory."]).
answer(number(2),part(c),subpart(ii),[149,0,"Lectures & Books."]).
answer(number(2),part(c),subpart(ii),[150,1,"Havey was richer and could publish his ideas."]).
answer(number(2),part(c),subpart(ii),[151,1,"He produced a Journal of his work"]).
answer(number(2),part(c),subpart(ii),[152,0,"Through travelling + showing others what he had found out."]).
answer(number(2),part(c),subpart(ii),[153,0,"Because people were less ignorent and more freely accepted Harvey's ideas as it was in a slightly more advanced time than Galens."]).
answer(number(2),part(c),subpart(ii),[154,0,"newspapers, advertisement etc."]).
answer(number(2),part(c),subpart(ii),[155,1,"Due to faster ways of communicating as he lived after Galen."]).
answer(number(2),part(c),subpart(ii),[156,0,"More people found out about his discoveries"]).
answer(number(2),part(c),subpart(ii),[157,1,"he lived later when technology was better so news travelled faster - in newspapers, letters etc."]).
answer(number(2),part(c),subpart(ii),[158,1,"New printing machines were made and it got printed and shown around"]).
answer(number(2),part(c),subpart(ii),[159,1,"his discoveries were at a later date so communication was easier."]).
answer(number(2),part(c),subpart(ii),[160,1,"Development of communications since Galen time."]).
answer(number(2),part(c),subpart(ii),[161,1,"There were more scientific journals to publish ideas when Harvey was alive."]).
answer(number(2),part(c),subpart(ii),[162,1,"it was easier in Harvey's time to publish work and do experimentation."]).
answer(number(2),part(c),subpart(ii),[163,1,"because they could of had quicker means of transport."]).
answer(number(2),part(c),subpart(ii),[164,2,"By Harvey's time communication was much better and there was opportunity for Harvey to travel and spread his ideas which he did. Established universities allowed him to study and teach."]).
answer(number(2),part(c),subpart(ii),[165,1,"Harvey lived later than Galen, so international communications were better"]).
answer(number(2),part(c),subpart(ii),[166,1,"Harvey's books were spread across the world. Harvey also carried out disections."]).
answer(number(2),part(c),subpart(ii),[167,1,"because Harvey wrote a book about it"]).
answer(number(2),part(c),subpart(ii),[168,1,"There were guilds and associations where journals & ideas could be submitted & announced to other scientists."]).
answer(number(2),part(c),subpart(ii),[169,1,"more hi-tech technology and advanced equipment - information travelled across better and people were more interested."]).
answer(number(2),part(c),subpart(ii),[170,1,"Better transport so the ideas could be spread faster."]).
answer(number(2),part(c),subpart(ii),[171,0,"In the late 1500's, there were the beginnings of scientific peer groups, and new theories might have been discussed and possibly publicised."]).
answer(number(2),part(c),subpart(ii),[172,1,"Communications such as post was better developed so ideas were easily told to others."]).
answer(number(2),part(c),subpart(ii),[173,1,"Write up all his findings by publicition."]).
answer(number(2),part(c),subpart(ii),[174,1,"Galen made his ideas a long time before Harvey and therefore could only spread by word of mouth, where as Harvey's ideas could have been published in newspapers."]).
answer(number(2),part(c),subpart(ii),[175,1,"because Harvey's ideas were published latter than Galen's so more reliable."]).
answer(number(2),part(c),subpart(ii),[176,0,"newspapers"]).
answer(number(2),part(c),subpart(ii),[177,1,"Methods of communication were more advanced in William Harvey's day. Messages could be carried on horse back with a messenger etc."]).
answer(number(2),part(c),subpart(ii),[178,0,"William Harvey was already famous"]).
answer(number(2),part(c),subpart(ii),[179,1,"The scientific community was bigger and there were more established journals for ideas to be shared"]).
answer(number(2),part(c),subpart(ii),[180,0,"Harvey was a public speaker and held demontrations."]).
answer(number(2),part(c),subpart(ii),[181,0,"Because there was more use of modern technology such as advertisements"]).
answer(number(2),part(c),subpart(ii),[182,1,"More modern means of communication"]).
answer(number(2),part(c),subpart(ii),[183,1,"Higher level of technology - better communications e.g printers."]).
answer(number(2),part(c),subpart(ii),[184,1,"Harvey was after Galen so media would have been developed more."]).
answer(number(2),part(c),subpart(ii),[185,1,"because he used books to get his ideas around - promotion."]).
answer(number(2),part(c),subpart(ii),[186,1,"Because Harvey lived later than Galen and there were more means of transport to tell other scientists about what Harvey had discovered. Science was also more widely accepted later in 1657."]).
answer(number(2),part(c),subpart(ii),[187,1,"There were more ways to communicate in Harveys time than in Galen's time"]).
answer(number(2),part(c),subpart(ii),[188,1,"The printing press had been invented and so his theories could be made known in that way"]).
answer(number(2),part(c),subpart(ii),[189,1,"he published them in science journals."]).
answer(number(2),part(c),subpart(ii),[190,1,"His ideas could be printed in books.* we never learnt about this!"]).
answer(number(2),part(c),subpart(ii),[191,1,"It was easier to print information in books and pass it around."]).
answer(number(2),part(c),subpart(ii),[192,1,"It was later so there were better methods of transporting news"]).
answer(number(2),part(c),subpart(ii),[193,2,"More people could read, as Harvey lived later on, and so when his ideas were published in science journals more people read them."]).
answer(number(2),part(c),subpart(ii),[194,1,"Communication was much improved in Harvey's time, meaning his ideas spread more easily and quicker."]).
answer(number(2),part(c),subpart(ii),[195,1,"communications had improved, there would be more established conferences and ways of contacting other scientists, thus spreading his ideas."]).
answer(number(2),part(c),subpart(ii),[196,0,"Harvey had publicity, contact with patients."]).
answer(number(2),part(c),subpart(ii),[197,2,"There were more books available and more literate people to read them"]).
answer(number(2),part(c),subpart(ii),[198,1,"they had horse and cart (transport) was better"]).
answer(number(2),part(c),subpart(ii),[199,1,"More ways of spreading news at the time of Harvey's suggestion. Galen's theory relied on word of mouth to spread it."]).
answer(number(2),part(c),subpart(ii),[200,1,"Better communication when Harvey was alive"]).
