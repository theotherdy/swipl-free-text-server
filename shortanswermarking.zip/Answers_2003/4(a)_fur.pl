:- multifile answer/4.

answer(number(4),part('a_fur'),subpart(0),[1,1,"provided insulation against the colder air of the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[2,1,"to keep himself warm becose it's cold up there."]).
answer(number(4),part('a_fur'),subpart(0),[3,1,"This will trap a layer of warm air next to the goats skin, helping to keep it warm in low temperatures that can occur in high mountains"]).
answer(number(4),part('a_fur'),subpart(0),[4,1,"To keep it warm in the cold high altitudes by insulating a layer of warm air around it"]).
answer(number(4),part('a_fur'),subpart(0),[5,1,"So the animal doesn't get cold."]).
answer(number(4),part('a_fur'),subpart(0),[6,1,"keeps it warm"]).
answer(number(4),part('a_fur'),subpart(0),[7,1,"was too keep it warm because its cold at the top of mountains."]).
answer(number(4),part('a_fur'),subpart(0),[8,1,"allowed the goat survived in cold weather"]).
answer(number(4),part('a_fur'),subpart(0),[9,1,"To keep itself warm. Mountains at a high altitude are cold"]).
answer(number(4),part('a_fur'),subpart(0),[10,1,"keep warm from could atmosphere"]).
answer(number(4),part('a_fur'),subpart(0),[11,1,"to insulate the animal and keep it warm in the cold mountain climate"]).
answer(number(4),part('a_fur'),subpart(0),[12,1,"keep warm."]).
answer(number(4),part('a_fur'),subpart(0),[13,1,"Insulation from the cold mountain air, as thick fur means more air spaces for warm air to circulate"]).
answer(number(4),part('a_fur'),subpart(0),[14,1,"traps a layer of air around the bucardo's body, which is warmed by its blood, providing insulation from the cold"]).
answer(number(4),part('a_fur'),subpart(0),[15,1,"kept it warm whilst on the mountain"]).
answer(number(4),part('a_fur'),subpart(0),[16,1,"Insulated the goat against cold up in mountains and fur traps heat so stays warmer."]).
answer(number(4),part('a_fur'),subpart(0),[17,1,"prevents loss of heat energy"]).
answer(number(4),part('a_fur'),subpart(0),[18,1,"Acts as insulation against the skin so the bucardo does not lose body heat and keeps warm"]).
answer(number(4),part('a_fur'),subpart(0),[19,1,"Help to insulate the bucardo, as conditions can be cold and inhospitable high in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[20,0,"its colder higher you are in the moutains (really cold)"]).
answer(number(4),part('a_fur'),subpart(0),[21,1,"keep the bucardo warm high up in the mountains"]).
answer(number(4),part('a_fur'),subpart(0),[22,1,"this insulates the bucardo from cold weather outside."]).
answer(number(4),part('a_fur'),subpart(0),[23,1,"insulates it. Traps air to reduce heat loss from animal as it is very cold in mountains."]).
answer(number(4),part('a_fur'),subpart(0),[24,1,"This insulated him from the cold as the mountains were high the temperatures would be low"]).
answer(number(4),part('a_fur'),subpart(0),[25,1,"provides good insulation"]).
answer(number(4),part('a_fur'),subpart(0),[26,1,"this fur traps a layer of air against the body that is warmed by body heat and remains there to warm the goat as air is a poor conductor of heat"]).
answer(number(4),part('a_fur'),subpart(0),[27,1,"prevent heat loss"]).
answer(number(4),part('a_fur'),subpart(0),[28,1,"to keep the bucardo warm (trap the heat)"]).
answer(number(4),part('a_fur'),subpart(0),[29,1,"insulates the body. Keeps it warm."]).
answer(number(4),part('a_fur'),subpart(0),[30,1,"to keep it warm during the winter"]).
answer(number(4),part('a_fur'),subpart(0),[31,1,"So that it keept the goat warm."]).
answer(number(4),part('a_fur'),subpart(0),[32,1,"high in the mountains, its colder Fur - Kept the goat warm."]).
answer(number(4),part('a_fur'),subpart(0),[33,0,"to be able to stand cold temperatures up high"]).
answer(number(4),part('a_fur'),subpart(0),[34,1,"insulated the goat from the cool temperatures high in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[35,1,"helps to keep the bucardo warm - prevents heat loss."]).
answer(number(4),part('a_fur'),subpart(0),[36,1,"Keep warmth in and protected the skin from being damaged (as much)."]).
answer(number(4),part('a_fur'),subpart(0),[37,1,"kept the bucardo's warm up in the mountains"]).
answer(number(4),part('a_fur'),subpart(0),[38,1,"keeps the bucardos body warm - less heat is lost the more fur their is"]).
answer(number(4),part('a_fur'),subpart(0),[39,1,"traps air and insulates the bucardo"]).
answer(number(4),part('a_fur'),subpart(0),[40,0,"protection from the wind"]).
answer(number(4),part('a_fur'),subpart(0),[41,0,"protects them from the cold and windy weather in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[42,1,"for insulation"]).
answer(number(4),part('a_fur'),subpart(0),[43,1,"to keep them warm"]).
answer(number(4),part('a_fur'),subpart(0),[44,1,"It is cold in the mountains, so the thick fur insulates the goat and keeps it warm, maintaining a good body temperature."]).
answer(number(4),part('a_fur'),subpart(0),[45,1,"insulates the bucardo from the low temperatures"]).
answer(number(4),part('a_fur'),subpart(0),[46,1,"Gives them body insulation, keeping them warm."]).
answer(number(4),part('a_fur'),subpart(0),[47,1,"keeps the goat warm in cold conditions"]).
answer(number(4),part('a_fur'),subpart(0),[48,1,"helped it keep warm"]).
answer(number(4),part('a_fur'),subpart(0),[49,0,"so that it could store water, and not lose alot through evaporation."]).
answer(number(4),part('a_fur'),subpart(0),[50,1,"would give it good insulation against cold weather"]).
answer(number(4),part('a_fur'),subpart(0),[51,1,"In high altitude it is cold. Thick fur acts as insulation."]).
answer(number(4),part('a_fur'),subpart(0),[52,1,"helps keep him warm and can also help to camaflage him if necessary."]).
answer(number(4),part('a_fur'),subpart(0),[53,0,"To protect the bucardo from cold weather."]).
answer(number(4),part('a_fur'),subpart(0),[54,0,"helps the bucardo survive cold weather high in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[55,1,"good insulation for cold weather - traps air and prevents heat from being released"]).
answer(number(4),part('a_fur'),subpart(0),[56,1,"Acts as an insulator to trap heat and reduce heat loss > good for surviving cold mountain conditions."]).
answer(number(4),part('a_fur'),subpart(0),[57,1,"keep the goat warm because its cold in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[58,1,"Keeps the bucardo warm."]).
answer(number(4),part('a_fur'),subpart(0),[59,1,"to trap hot air leaving the body for insulation."]).
answer(number(4),part('a_fur'),subpart(0),[60,0,"survie the winter when snow settals"]).
answer(number(4),part('a_fur'),subpart(0),[61,0,"for trapping air between his skin and his fur."]).
answer(number(4),part('a_fur'),subpart(0),[62,1,"Keep in heat"]).
answer(number(4),part('a_fur'),subpart(0),[63,1,"acts as an insulator and keeps body heat from being wasted in the cold at that altitude."]).
answer(number(4),part('a_fur'),subpart(0),[64,1,"The thick fur will help to stop the animal from getting cold at high altitudes and keep it insulated"]).
answer(number(4),part('a_fur'),subpart(0),[65,1,"keep it warm"]).
answer(number(4),part('a_fur'),subpart(0),[66,1,"provides it with insulation for warmth in the high mountains, where it is cold."]).
answer(number(4),part('a_fur'),subpart(0),[67,1,"keep it warm as it is cold in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[68,1,"mountains are cold so the fur keeps it warm by insulating heat - maintaining body temperature."]).
answer(number(4),part('a_fur'),subpart(0),[69,1,"High mountains tends to be cold, thick fur for insulation"]).
answer(number(4),part('a_fur'),subpart(0),[70,1,"for warmth"]).
answer(number(4),part('a_fur'),subpart(0),[71,1,"The thick fur would capture air between it which would act as insulation, keeping it warm."]).
answer(number(4),part('a_fur'),subpart(0),[72,1,"This allows the bucardo to keep warm in the winter as the fur is insulating. Also, it allows the bucardo to store fat, which it can use for energy if there's a food shortage."]).
answer(number(4),part('a_fur'),subpart(0),[73,1,"Traps lots of air between the hairs which its body can heat up so insulating itself from the cold."]).
answer(number(4),part('a_fur'),subpart(0),[74,1,"This insulated the deer keeping it warm."]).
answer(number(4),part('a_fur'),subpart(0),[75,1,"keeps heat inside the body, it acts as an insulator"]).
answer(number(4),part('a_fur'),subpart(0),[76,1,"To stay warm when it was cold"]).
answer(number(4),part('a_fur'),subpart(0),[77,1,"kept him well insolated"]).
answer(number(4),part('a_fur'),subpart(0),[78,1,"to prevent heat from escaping."]).
answer(number(4),part('a_fur'),subpart(0),[79,1,"Keep it warm from cold climate"]).
answer(number(4),part('a_fur'),subpart(0),[80,1,"Think fur provides warmth."]).
answer(number(4),part('a_fur'),subpart(0),[81,1,"to keep warm"]).
answer(number(4),part('a_fur'),subpart(0),[82,1,"To conserve body heat to keep warm in the cold monntains"]).
answer(number(4),part('a_fur'),subpart(0),[83,1,"in the mountains it would be cold, so thick fur provides warmth."]).
answer(number(4),part('a_fur'),subpart(0),[84,1,"provides the bucardo with insulation by trapping air close to the body"]).
answer(number(4),part('a_fur'),subpart(0),[85,1,"provides insulation (by trapping a layer of air) to keep it warm"]).
answer(number(4),part('a_fur'),subpart(0),[86,1,"keeps it warm in the cold invironment"]).
answer(number(4),part('a_fur'),subpart(0),[87,1,"prevents heat loss the bucardo is warmer"]).
answer(number(4),part('a_fur'),subpart(0),[88,1,"to keep the goat warm"]).
answer(number(4),part('a_fur'),subpart(0),[89,0,"So that it is not affected by the cold when in the mountains"]).
answer(number(4),part('a_fur'),subpart(0),[90,1,"kept the goat warm"]).
answer(number(4),part('a_fur'),subpart(0),[91,1,"can keep him warm because it is very cold on the mountains"]).
answer(number(4),part('a_fur'),subpart(0),[92,1,"As the bucardo lived at high altitude, the thick fur kept it warm by trapping a layer of air."]).
answer(number(4),part('a_fur'),subpart(0),[93,1,"It is often cold high in the mountains the fur would insulate it"]).
answer(number(4),part('a_fur'),subpart(0),[94,1,"insulates heat and helps insulate the fur."]).
answer(number(4),part('a_fur'),subpart(0),[95,1,"keeps the goat warm"]).
answer(number(4),part('a_fur'),subpart(0),[96,1,"good insulator, reduces goat heat loss."]).
answer(number(4),part('a_fur'),subpart(0),[97,1,"Because if it snowed or it was cold up in the moutains etc, it would keep its body warm"]).
answer(number(4),part('a_fur'),subpart(0),[98,1,"kept itself warm, for insulation from the cold weather."]).
answer(number(4),part('a_fur'),subpart(0),[99,1,"provides insulation from cold"]).
answer(number(4),part('a_fur'),subpart(0),[100,1,"kept it warm from the harsh climate high in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[101,1,"Thick fur insulates the bucardo from the cold, so it is kept warm."]).
answer(number(4),part('a_fur'),subpart(0),[102,0,"to keep the animal morm"]).
answer(number(4),part('a_fur'),subpart(0),[103,1,"it keeps it warm up in the high mountains keeps the body heat in."]).
answer(number(4),part('a_fur'),subpart(0),[104,1,"help keep the animal warm"]).
answer(number(4),part('a_fur'),subpart(0),[105,1,"fur can be used as a insulator to keep the goat warm high in the mountains where it can be very cold."]).
answer(number(4),part('a_fur'),subpart(0),[106,0,"Insulation of heat to protect because from harsh weather conditions"]).
answer(number(4),part('a_fur'),subpart(0),[107,1,"kept the bucardo warm when it wos cold"]).
answer(number(4),part('a_fur'),subpart(0),[108,1,"Keeps the animal warm in the winter, when its cold and snowing."]).
answer(number(4),part('a_fur'),subpart(0),[109,1,"Keep the goat insulated and warm at night."]).
answer(number(4),part('a_fur'),subpart(0),[110,1,"a layer of insulation to trap heat to keep the goat warm"]).
answer(number(4),part('a_fur'),subpart(0),[111,1,"This would enable the bucardo to survive and keep warm high up in the cold mountains."]).
answer(number(4),part('a_fur'),subpart(0),[112,1,"Keep it warm"]).
answer(number(4),part('a_fur'),subpart(0),[113,1,"So that it did not become to cold and die"]).
answer(number(4),part('a_fur'),subpart(0),[114,1,"to keep warm in the cool mountain climate."]).
answer(number(4),part('a_fur'),subpart(0),[115,1,"To keep the bucardo warm and comforateble."]).
answer(number(4),part('a_fur'),subpart(0),[116,1,"for insulation against the cold weather high up on the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[117,1,"To keep warm because they are high up."]).
answer(number(4),part('a_fur'),subpart(0),[118,1,"traps a layer of warm air around the goat insulating it, which is useful as it is cold high in the mountains"]).
answer(number(4),part('a_fur'),subpart(0),[119,1,"keeps the bucardo warm at a high altitude"]).
answer(number(4),part('a_fur'),subpart(0),[120,1,"helped to keep it warm In the winter"]).
answer(number(4),part('a_fur'),subpart(0),[121,1,"Kept the bucardo warm because it is cold in the mountains"]).
answer(number(4),part('a_fur'),subpart(0),[122,1,"kept it warm"]).
answer(number(4),part('a_fur'),subpart(0),[123,1,"acts as an insulator to keep animal warm."]).
answer(number(4),part('a_fur'),subpart(0),[124,1,"was to keep the bucardo warm."]).
answer(number(4),part('a_fur'),subpart(0),[125,1,"helped keep heat in in cold conditions."]).
answer(number(4),part('a_fur'),subpart(0),[126,1,"the fur protected the Bucardo from rain and the cold ie it insulated it's body."]).
answer(number(4),part('a_fur'),subpart(0),[127,1,"insulation from the cold"]).
answer(number(4),part('a_fur'),subpart(0),[128,1,"helped it stay warm because it would be very cold way up high in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[129,1,"Keeps it warm as it is cold high up in the mountains"]).
answer(number(4),part('a_fur'),subpart(0),[130,1,"to keep them warm as the mountains are very cold."]).
answer(number(4),part('a_fur'),subpart(0),[131,1,"would keep Bucardo warm and stop him chivering"]).
answer(number(4),part('a_fur'),subpart(0),[132,1,"insulates body in cold climates, generates heat just like a layer of fat would."]).
answer(number(4),part('a_fur'),subpart(0),[133,1,"because it kept him warm"]).
answer(number(4),part('a_fur'),subpart(0),[134,1,"Is to keep warm and chance to protected by bad weather."]).
answer(number(4),part('a_fur'),subpart(0),[135,1,"Protects him from the cold keeping him warm in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[136,1,"Traps air pockets which insulate the body against the cold"]).
answer(number(4),part('a_fur'),subpart(0),[137,1,"This keeps the goat insulated on the cold altitudes of the mountains. It will reduce his heat loss."]).
answer(number(4),part('a_fur'),subpart(0),[138,1,"insulates the bucardo from cold weather in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[139,1,"Keep them warm at colder climates"]).
answer(number(4),part('a_fur'),subpart(0),[140,0,"provides a layer of insulin to help the bucardo regulate its body temperature."]).
answer(number(4),part('a_fur'),subpart(0),[141,1,"the thick fur kept the bucardo warm."]).
answer(number(4),part('a_fur'),subpart(0),[142,1,"would of helped the goat stay warm"]).
answer(number(4),part('a_fur'),subpart(0),[143,1,"to keep it warm and to stop it geting badly hurt"]).
answer(number(4),part('a_fur'),subpart(0),[144,1,"the heigher up in in altitude you are the colder it is so thick fur insulated and kept him warm"]).
answer(number(4),part('a_fur'),subpart(0),[145,1,"The thick fur traps heat from the blood vessels close to the skin."]).
answer(number(4),part('a_fur'),subpart(0),[146,1,"The thick fur would insulate the bucardo against the cold weather in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[147,0,"To protect it from strong winds and extremes of weather."]).
answer(number(4),part('a_fur'),subpart(0),[148,1,"to keep it warm in the cold temperatures as the fur would have trapped air insulating the body"]).
answer(number(4),part('a_fur'),subpart(0),[149,1,"As there are colder temperatures at higher altitudes, thick fur would have kept the bucardo warm."]).
answer(number(4),part('a_fur'),subpart(0),[150,1,"keeps it warm and protects"]).
answer(number(4),part('a_fur'),subpart(0),[151,1,"Keep it warm in the cold mountaneous climate."]).
answer(number(4),part('a_fur'),subpart(0),[152,1,"In the mountains it is cold therefor it need insulation and thick fur give it that"]).
answer(number(4),part('a_fur'),subpart(0),[153,1,"would keep the bucardo warm in cold weather"]).
answer(number(4),part('a_fur'),subpart(0),[154,0,"helped it to survive cold seasons, especially as it is even colder in high mountains then, e.g. in suburbia"]).
answer(number(4),part('a_fur'),subpart(0),[155,1,"it keeps the bucardo warm as it insulates the body"]).
answer(number(4),part('a_fur'),subpart(0),[156,1,"Kept the bucardo warm in the lower temperatures created by the high altitude"]).
answer(number(4),part('a_fur'),subpart(0),[157,1,"to keep them warm when it was cold."]).
answer(number(4),part('a_fur'),subpart(0),[158,1,"helps the animal to keep warm"]).
answer(number(4),part('a_fur'),subpart(0),[159,1,"is so that the bucardo can keep warm as mountains are cold"]).
answer(number(4),part('a_fur'),subpart(0),[160,1,"this helps to insulate the goat preventing loss of heat"]).
answer(number(4),part('a_fur'),subpart(0),[161,1,"did not become cold In the winter as mountains are cold"]).
answer(number(4),part('a_fur'),subpart(0),[162,1,"To keep them warm"]).
answer(number(4),part('a_fur'),subpart(0),[163,1,"Kept him warm. Prevents some injuries"]).
answer(number(4),part('a_fur'),subpart(0),[164,1,"helped to insulate the bucardo when it was cold."]).
answer(number(4),part('a_fur'),subpart(0),[165,1,"able to keep body warm in the cold mountains so it could not freeze"]).
answer(number(4),part('a_fur'),subpart(0),[166,1,"helps to keep the goat warm in the high altitudes that it lives in."]).
answer(number(4),part('a_fur'),subpart(0),[167,1,"This would keep them warm while they lived in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[168,1,"helps him keep warm as it is cold high in the mountains"]).
answer(number(4),part('a_fur'),subpart(0),[169,1,"to keep the bucardo warm."]).
answer(number(4),part('a_fur'),subpart(0),[170,1,"kept the bucardo warm and insulated up in the cold mountains"]).
answer(number(4),part('a_fur'),subpart(0),[171,1,"to help it to keep warm in the summer"]).
answer(number(4),part('a_fur'),subpart(0),[172,1,"traps air for insulation to keep it warm in the cold conditions high in a mountain"]).
answer(number(4),part('a_fur'),subpart(0),[173,1,"To keep the bucardo warm"]).
answer(number(4),part('a_fur'),subpart(0),[174,1,"would help to insulate heat to reduce body heat being lost."]).
answer(number(4),part('a_fur'),subpart(0),[175,1,"kept them warm"]).
answer(number(4),part('a_fur'),subpart(0),[176,1,"to keep the bucardo well insulated, as the higher up the mountain, the colder the temperature."]).
answer(number(4),part('a_fur'),subpart(0),[177,0,"To help survive the cold weather/Temperature."]).
answer(number(4),part('a_fur'),subpart(0),[178,1,"keeps it warm and protection from cold wind."]).
answer(number(4),part('a_fur'),subpart(0),[179,1,"In mountanous areas the temperature decreases, so the thick fur helps it to retain a good body temperature."]).
answer(number(4),part('a_fur'),subpart(0),[180,1,"Insulate the bucardo's body from the cold temperatures in high mountains by trapping the heat."]).
answer(number(4),part('a_fur'),subpart(0),[181,1,"keep it warm from the wind."]).
answer(number(4),part('a_fur'),subpart(0),[182,1,"kept the goat warm in the High mountains and cold temperatures."]).
answer(number(4),part('a_fur'),subpart(0),[183,1,"the atmosphere is thinner higher up, so the temperature would be colder. Thick fur would keep the bucardo warm."]).
answer(number(4),part('a_fur'),subpart(0),[184,1,"Provides insulation to keep it warm"]).
answer(number(4),part('a_fur'),subpart(0),[185,1,"keep it self warm because it is cool in the mountains."]).
answer(number(4),part('a_fur'),subpart(0),[186,1,"Kept him warm on the cold mountains"]).
answer(number(4),part('a_fur'),subpart(0),[187,1,"to keep warm from low, cold temperatures"]).
answer(number(4),part('a_fur'),subpart(0),[188,1,"to keep it warm. Up in the mountains it is cold and the fur would protect it against the cold."]).
answer(number(4),part('a_fur'),subpart(0),[189,1,"Gives the bucardo insulation because temperatures are lower at higher altitudes"]).
answer(number(4),part('a_fur'),subpart(0),[190,1,"to keep itself warm. The air is trapped under the hair which is warmed up."]).
answer(number(4),part('a_fur'),subpart(0),[191,1,"Protection against cold weather, insulation."]).
answer(number(4),part('a_fur'),subpart(0),[192,1,"in high mountains the temperatures are very low, thick fur can trap air and keep animal warm"]).
answer(number(4),part('a_fur'),subpart(0),[193,1,"Stop it from becoming very cold and die."]).
answer(number(4),part('a_fur'),subpart(0),[194,1,"keeps The Bucardo warm"]).
answer(number(4),part('a_fur'),subpart(0),[195,1,"Keeps bucardo warm whilst at the high mountains were its cold ."]).
answer(number(4),part('a_fur'),subpart(0),[196,1,"The thick fur kept him warm."]).
answer(number(4),part('a_fur'),subpart(0),[197,1,"stops him suffering from hyperthermia."]).
answer(number(4),part('a_fur'),subpart(0),[198,0,"protected the bicardo from the icy winds and snow that is typical on high mountains."]).
answer(number(4),part('a_fur'),subpart(0),[199,0,"if it fell it wouldn't hurt itself to badly."]).
answer(number(4),part('a_fur'),subpart(0),[200,0,"allowed the bucardo to survive to freezing temperatues of its habitat."]).

 
