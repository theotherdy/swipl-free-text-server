:- multifile answer/4.
answer(number(2),part(b),subpart(i),[1,0,"one push blood around the body, the other draws it into the heart."]).
answer(number(2),part(b),subpart(i),[2,1,"they prevent the backflow of blood."]).
answer(number(2),part(b),subpart(i),[3,0,"They let the blood in and out of the heart."]).
answer(number(2),part(b),subpart(i),[4,1,"They prevent blood flowing back,"]).
answer(number(2),part(b),subpart(i),[5,1,"to send the blood round the heart and not allow it to flow backwards."]).
answer(number(2),part(b),subpart(i),[6,1,"The valves stop blood back flow from the ventricles back into the atria."]).
answer(number(2),part(b),subpart(i),[7,0,"To prevent any unwanted waste passing into the heart."]).
answer(number(2),part(b),subpart(i),[8,1,"the valves are there to prevent the backflow of blood"]).
answer(number(2),part(b),subpart(i),[9,1,"The Jobs are to let blood into the heart one way but not out the same way."]).
answer(number(2),part(b),subpart(i),[10,0,"To only let a certain amount of blood in at a time."]).
answer(number(2),part(b),subpart(i),[11,1,"To keep the blood going in the right direction"]).
answer(number(2),part(b),subpart(i),[12,1,"The valves prevent backflow of blood."]).
answer(number(2),part(b),subpart(i),[13,1,"The valves can stop the blood from flowing in the wrong direction."]).
answer(number(2),part(b),subpart(i),[14,1,"There valves prevent the backflow of blood in the heart and ensure that it flows in the right direction."]).
answer(number(2),part(b),subpart(i),[15,0,"These valves are responsible for preventing backflow of the blood, from the atria to the ventricles"]).
answer(number(2),part(b),subpart(i),[16,1,"Valves control the movement of blood into the heart, they prevent back flow."]).
answer(number(2),part(b),subpart(i),[17,1,"To prevent the backflow of the blood.  The blood must keep going forwards so these valves help the blood to do that."]).
answer(number(2),part(b),subpart(i),[18,1,"To stop the backflow of blood"]).
answer(number(2),part(b),subpart(i),[19,0,"They store oxygen."]).
answer(number(2),part(b),subpart(i),[20,1,"To keep blood flowing in the correct direction."]).
answer(number(2),part(b),subpart(i),[21,1,"These valves open as blood enters the atrium and they immediately close, so there is no backflow of blood."]).
answer(number(2),part(b),subpart(i),[22,0,"they let blood go in and out of the heart."]).
answer(number(2),part(b),subpart(i),[23,0,"These valves allow a certain amount of blood into the heart at a time to be pumped out the heart and around the body."]).
answer(number(2),part(b),subpart(i),[24,0,"To pump the heart"]).
answer(number(2),part(b),subpart(i),[25,1,"to prevent a backflow of blood (into the atrium)."]).
answer(number(2),part(b),subpart(i),[26,0,"The left side pumps blood to the body, and the right to the muscles."]).
answer(number(2),part(b),subpart(i),[27,0,"to let blood in and out"]).
answer(number(2),part(b),subpart(i),[28,1,"to prevent backflow of blood"]).
answer(number(2),part(b),subpart(i),[29,0,"The valves pump the blood through the heart and into the organs."]).
answer(number(2),part(b),subpart(i),[30,1,"The valves keep the blood flowing the right way"]).
answer(number(2),part(b),subpart(i),[31,1,"The bicuspid + tricuspid valves close to prevent the backflow of blood + open to allow blood into the ventricles."]).
answer(number(2),part(b),subpart(i),[32,1,"sends the blood the right way."]).
answer(number(2),part(b),subpart(i),[33,1,"They prevent backflow of the blood."]).
answer(number(2),part(b),subpart(i),[34,0,"The job of thes two valves is to let blood in and not out"]).
answer(number(2),part(b),subpart(i),[35,0,"lets blood in + out"]).
answer(number(2),part(b),subpart(i),[36,1,"These valves prevent backflow from the ventricles into the atriums.  They ensure that blood moves in one way only."]).
answer(number(2),part(b),subpart(i),[37,1,"The valves prevent back flow of blood."]).
answer(number(2),part(b),subpart(i),[38,1,"to stop the backflow of blood."]).
answer(number(2),part(b),subpart(i),[39,1,"To prevent backflow because blood must only flow one way."]).
answer(number(2),part(b),subpart(i),[40,1,"Valves prevent the blood from flowing in the wrong direction"]).
answer(number(2),part(b),subpart(i),[41,0,"The L (left valve) pumps blood to your right side of your body, whereas the R pumps it to your left side."]).
answer(number(2),part(b),subpart(i),[42,0,"pumps blood around body"]).
answer(number(2),part(b),subpart(i),[43,1,"to stop blood backflowing into the atrium."]).
answer(number(2),part(b),subpart(i),[44,1,"To stop blood flowing the wrong way"]).
answer(number(2),part(b),subpart(i),[45,1,"they prevent the backflow of blood"]).
answer(number(2),part(b),subpart(i),[46,1,"These valves stop the back flow of blood."]).
answer(number(2),part(b),subpart(i),[47,1,"The valves are to prevent the backflow of blood eg. tricuspid valves stop blood from velicles going back into atria."]).
answer(number(2),part(b),subpart(i),[48,0,"These are the bicuspid and tricuspid valves they make sure blood doesnt go back into the ventricles and flows in the correct direction"]).
answer(number(2),part(b),subpart(i),[49,1,"They prevent back flow into the wrong area"]).
answer(number(2),part(b),subpart(i),[50,1,"To prevent a backflow of blood or blood moving the wrong way."]).
answer(number(2),part(b),subpart(i),[51,0,"These valves stop the heart from blowing inside out + prevent backflow of blood."]).
answer(number(2),part(b),subpart(i),[52,1,"The valves prevent blood from the ventricles from flowing up into the atria"]).
answer(number(2),part(b),subpart(i),[53,1,"Their job is to stop the backflow of blood."]).
answer(number(2),part(b),subpart(i),[54,1,"To stop backflow so the blood will flow in one direction"]).
answer(number(2),part(b),subpart(i),[55,0,"one is to stop the backflow of blood and the other is to let blood back into the heart."]).
answer(number(2),part(b),subpart(i),[56,0,"helps breathe in and out."]).
answer(number(2),part(b),subpart(i),[57,0,"These valves prevent backflow of blood from the ventricles into the atria."]).
answer(number(2),part(b),subpart(i),[58,1,"Valves are present in the heart to ensure that blood flows the right way (the correct way)."]).
answer(number(2),part(b),subpart(i),[59,0,"One valve pumps blood into the heart whiles the other pumps it out."]).
answer(number(2),part(b),subpart(i),[60,1,"The valves control the direction in which the blood flows"]).
answer(number(2),part(b),subpart(i),[61,1,"to prevent back flow of blood"]).
answer(number(2),part(b),subpart(i),[62,1,"Only allow the blood to move in one direction."]).
answer(number(2),part(b),subpart(i),[63,1,"to stop blood backflowing."]).
answer(number(2),part(b),subpart(i),[64,1,"The valves prevent blood flowing back in the wrong direction"]).
answer(number(2),part(b),subpart(i),[65,0,"To control the amount of blood entering and leaving the heart, and ensure it flows in the right direction and doesn't go back."]).
answer(number(2),part(b),subpart(i),[66,1,"Valves prevent the back flow of blood by opening and closing when necessary."]).
answer(number(2),part(b),subpart(i),[67,1,"They separate the atrium and ventricle so that blood does not flow back into the atrium when the ventricle contracts."]).
answer(number(2),part(b),subpart(i),[68,1,"The valves make sure the blood flows in the one direction."]).
answer(number(2),part(b),subpart(i),[69,1,"The valves stop blood from going back the way it had come."]).
answer(number(2),part(b),subpart(i),[70,1,"These valves are there to stop the blood from flowing in the wrong direction"]).
answer(number(2),part(b),subpart(i),[71,1,"These cuspid valves are to prevent backflow of blood back into the atria when ventricles constrict so blood doesn't go backwards."]).
answer(number(2),part(b),subpart(i),[72,1,"These valves prevent the backflow of blood."]).
answer(number(2),part(b),subpart(i),[73,0,"They make sure the blood gets to everywhere."]).
answer(number(2),part(b),subpart(i),[74,0,"a helps carry around one part of for orgons and the brain and the other goes round the other orgons"]).
answer(number(2),part(b),subpart(i),[75,1,"to keep the blood flowing in the right direction."]).
answer(number(2),part(b),subpart(i),[76,1,"stop the backflow of blood."]).
answer(number(2),part(b),subpart(i),[77,1,"These valves prevent backflow, ie they stop blood from flowing back from one atrium into the previous atrium."]).
answer(number(2),part(b),subpart(i),[78,1,"To prevent back flow."]).
answer(number(2),part(b),subpart(i),[79,1,"The jobs of these valves are to stop any blood from flowing backwards, either back into the atria or back into the ventricles."]).
answer(number(2),part(b),subpart(i),[80,1,"To prevent the backflow of blood."]).
answer(number(2),part(b),subpart(i),[81,0,"To keep the blood circulating"]).
answer(number(2),part(b),subpart(i),[82,0,"to open and close when the heart is pumping blood."]).
answer(number(2),part(b),subpart(i),[83,1,"They keep blood flowing in one direction."]).
answer(number(2),part(b),subpart(i),[84,0,"to renter oxygen back into the blood stream."]).
answer(number(2),part(b),subpart(i),[85,1,"They prevent the blood from flowing backwards."]).
answer(number(2),part(b),subpart(i),[86,1,"to prevent backflow of blood in the heart."]).
answer(number(2),part(b),subpart(i),[87,1,"The valves prevent any blood flowing into the wrong vessels i.e. back where it came from."]).
answer(number(2),part(b),subpart(i),[88,0,"to restrict the blood flow."]).
answer(number(2),part(b),subpart(i),[89,1,"Prevents blood from flowing backwards"]).
answer(number(2),part(b),subpart(i),[90,1,"The valves stop the backflow of blood."]).
answer(number(2),part(b),subpart(i),[91,1,"These valves prevent 'suckback'.  When the ventricles contract they close to prevent blood flowing in the wrong direction (back into the atria)."]).
answer(number(2),part(b),subpart(i),[92,0,"To keep the blood clean and pure."]).
answer(number(2),part(b),subpart(i),[93,1,"To prevent the backflow of any blood."]).
answer(number(2),part(b),subpart(i),[94,1,"The valves make sure that the blood does not flow back on itself, ensuring that it stays in one direction going round the body."]).
answer(number(2),part(b),subpart(i),[95,1,"They open + shut allowing blood to enter a different chamber and then stay there and not flow backwards."]).
answer(number(2),part(b),subpart(i),[96,1,"To ensure the blood circulates in the correct direction."]).
answer(number(2),part(b),subpart(i),[97,1,"They prevent blood from flowing backwards"]).
answer(number(2),part(b),subpart(i),[98,0,"let blood pass out of our heart."]).
answer(number(2),part(b),subpart(i),[99,0,"lets oxygin into the heart"]).
answer(number(2),part(b),subpart(i),[100,1,"To make sure blood flows in the right direction through the heart."]).
answer(number(2),part(b),subpart(i),[101,1,"These stops the backflow of blood back into the atria."]).
answer(number(2),part(b),subpart(i),[102,1,"They stop blood from flowing backwards."]).
answer(number(2),part(b),subpart(i),[103,1,"To stop the blood going back into the Atria after it has entered the ventricals (prevent back flow)"]).
answer(number(2),part(b),subpart(i),[104,1,"to stop blood coming back on itself after its been pumped."]).
answer(number(2),part(b),subpart(i),[105,0,"To allow blood into the ventricles."]).
answer(number(2),part(b),subpart(i),[106,1,"These are to prevent backflow from blood that has passed through them."]).
answer(number(2),part(b),subpart(i),[107,1,"the valves make sure that once the blood has passed from the atria to the ventricles it does not go back."]).
answer(number(2),part(b),subpart(i),[108,0,"To release air."]).
answer(number(2),part(b),subpart(i),[109,1,"To prevent backflow of the blood - to ensure it is pumped in the correct direction."]).
answer(number(2),part(b),subpart(i),[110,0,"These help the heart move in a certain direction."]).
answer(number(2),part(b),subpart(i),[111,1,"during ventricular systole these prevent blood flowing backwards into the atria.  So blood is forced into the arteries instead."]).
answer(number(2),part(b),subpart(i),[112,0,"to trap extra blood for stronger pressure."]).
answer(number(2),part(b),subpart(i),[113,0,"The valves are to let blood in and out of the heart."]).
answer(number(2),part(b),subpart(i),[114,1,"They let blood in one way and stop blood going back out the sameway"]).
answer(number(2),part(b),subpart(i),[115,1,"They prevent the backflow of blood in the heart, so that it can be pumped to wherever it is needed."]).
answer(number(2),part(b),subpart(i),[116,0,"The semi-lunar valves let the blood from the atriums pass into the ventricles"]).
answer(number(2),part(b),subpart(i),[117,0,"one valve sends out oxygenated blood and the other recived blood"]).
answer(number(2),part(b),subpart(i),[118,1,"To allow blood into the ventricles, but prevent it being pushed backwards when the ventricles contract."]).
answer(number(2),part(b),subpart(i),[119,1,"To prevent blood from flowing in the wrong direction."]).
answer(number(2),part(b),subpart(i),[120,1,"The valves prevent the backflow of blood and thus as much blood as possible can reach body tissue."]).
answer(number(2),part(b),subpart(i),[121,1,"They make the blood travel one way in and out of the heart."]).
answer(number(2),part(b),subpart(i),[122,1,"The valves stop the blood flowing in the wrong direction"]).
answer(number(2),part(b),subpart(i),[123,0,"They open up allowing blood to pass from the atria to ventricles, and vice versa."]).
answer(number(2),part(b),subpart(i),[124,1,"These are the bicuspid and tricuspid valves that make sure the blood goes from the atrium into the ventricles and not visa-versa"]).
answer(number(2),part(b),subpart(i),[125,0,"let blood in and oxygen."]).
answer(number(2),part(b),subpart(i),[126,1,"enables the blood to be transported in only one direction."]).
answer(number(2),part(b),subpart(i),[127,0,"They control how much blood enters the heart + they prevent back flow."]).
answer(number(2),part(b),subpart(i),[128,1,"to make sure there is no backflow of blood."]).
answer(number(2),part(b),subpart(i),[129,1,"The valves in the heart, allow the blood to circulate in one particular direction."]).
answer(number(2),part(b),subpart(i),[130,1,"To stop the blood backflowing."]).
answer(number(2),part(b),subpart(i),[131,0,"1 Valve pumps blood without oxygen the other pumps blood with oxygen"]).
answer(number(2),part(b),subpart(i),[132,1,"Bicupsid + tricupsid valves.  To prevent backflow of blood within the heart, so it stays flowing in the right direction"]).
answer(number(2),part(b),subpart(i),[133,1,"The valves stop the blood flowing backwards (eg the blood in the ventricles flowing back into the atrium)."]).
answer(number(2),part(b),subpart(i),[134,1,"The jobs of these valves is to allow blood to pass through them but to not let the blood go back the way it came."]).
answer(number(2),part(b),subpart(i),[135,0,"They reduce the occurance of backflow of the blood."]).
answer(number(2),part(b),subpart(i),[136,1,"They prevent blood from re-entering the left and right atria."]).
answer(number(2),part(b),subpart(i),[137,1,"They ensure that blood flows in the right direction.  e.g. it allows blood to flow to the right ventricle, but stops it from flowing straight back into the right atrium again."]).
answer(number(2),part(b),subpart(i),[138,1,"These valves allow blood into the ventricles and prevent the blood from flowing back into the atrium."]).
answer(number(2),part(b),subpart(i),[139,0,"To open and close as the heart pumps blood"]).
answer(number(2),part(b),subpart(i),[140,1,"Valves prevent blood flowing backwards due to low pressure"]).
answer(number(2),part(b),subpart(i),[141,0,"One Valve lets blood in and one Valve lets blood out.  So it can go around the body"]).
answer(number(2),part(b),subpart(i),[142,1,"The valves prevent the blood flowing back in the direction that it came from."]).
answer(number(2),part(b),subpart(i),[143,1,"They are to prevent the backflow of blood."]).
answer(number(2),part(b),subpart(i),[144,1,"To prevent the backflow of blood (one way opening)"]).
answer(number(2),part(b),subpart(i),[145,1,"to stop the blood flowing back into the heart in the wrong direction"]).
answer(number(2),part(b),subpart(i),[146,1,"The valves prevent the backwards flow of blood in the heart, by only allowing blood one way"]).
answer(number(2),part(b),subpart(i),[147,1,"to stop the backflow of blood from the ventricle back to the atrium."]).
answer(number(2),part(b),subpart(i),[148,1,"They prevent backflow of the blood."]).
answer(number(2),part(b),subpart(i),[149,1,"The valves are there to prevent the backflow of blood."]).
answer(number(2),part(b),subpart(i),[150,1,"The valves prevent backflow of blood."]).
answer(number(2),part(b),subpart(i),[151,1,"[crossed out: When the ventricles contract to pump the blood into the pulmonary artery + aorta they shut]  preventing blood flowing into the atria."]).
answer(number(2),part(b),subpart(i),[152,1,"These valves prevent the blood from going backwards"]).
answer(number(2),part(b),subpart(i),[153,1,"To prevent backflow - the blood going in the opposite direction."]).
answer(number(2),part(b),subpart(i),[154,1,"To only allow blood flow in one direction"]).
answer(number(2),part(b),subpart(i),[155,0,"controls the amount of blood pass through at an one time."]).
answer(number(2),part(b),subpart(i),[156,0,"The valves are there to take on oxygenated blood and pump out deoxygenated blood."]).
answer(number(2),part(b),subpart(i),[157,0,"The valves contract and then release to produce a heartbeat."]).
answer(number(2),part(b),subpart(i),[158,1,"These valves prevent blood flowing upwards from the ventricles into the atria"]).
answer(number(2),part(b),subpart(i),[159,1,"To stop there from being a backflow of blood when it is pushed through the heart (from the ventricles to the atria)"]).
answer(number(2),part(b),subpart(i),[160,1,"These valves prevent blood from travelling in the wrong direction ie from the ventricles back into the atria."]).
answer(number(2),part(b),subpart(i),[161,1,"The valves are to stop backflow of blood, so it doesn't go the wrong way round the heart."]).
answer(number(2),part(b),subpart(i),[162,0,"to control the flow of blood pumped at every contraction from the atria into the ventricles"]).
answer(number(2),part(b),subpart(i),[163,1,"These valves (Tricuspid + Bicuspid valves) are used to prevent blood from backflowing."]).
answer(number(2),part(b),subpart(i),[164,0,"To 'pump' 'clean' and 'dirty' blood to the right places."]).
answer(number(2),part(b),subpart(i),[165,1,"To make sure that the blood only flows in one direction"]).
answer(number(2),part(b),subpart(i),[166,1,"Valves prevent the backflow of blood."]).
answer(number(2),part(b),subpart(i),[167,1,"ensure that the blood only flows in one direction."]).
answer(number(2),part(b),subpart(i),[168,1,"The valves prevent backflow of blood."]).
answer(number(2),part(b),subpart(i),[169,1,"The valves prevent the blood from flowing backwards when the heart isn't contracting and pumping it forwards."]).
answer(number(2),part(b),subpart(i),[170,0,"To let the blood in and the other to let blood out"]).
answer(number(2),part(b),subpart(i),[171,1,"To prevent the blood backflowing into the heart."]).
answer(number(2),part(b),subpart(i),[172,0,"One set of valves carries oxygenated blood whilst the other carries deoxygenated blood."]).
answer(number(2),part(b),subpart(i),[173,0,"These valves keep the circulation of the blood constant."]).
answer(number(2),part(b),subpart(i),[174,0,"They are there to slow down the blood so you don't get to much flushing through at once."]).
answer(number(2),part(b),subpart(i),[175,1,"stops the back-flow of blood."]).
answer(number(2),part(b),subpart(i),[176,1,"The valves prevent the backflow of blood and keep blood flowing in the right direction."]).
answer(number(2),part(b),subpart(i),[177,1,"The jobs of the valves is to close to prevent blood bieng pushed back into the atriums when it is in the ventricles and the heart is trying to pump the blood through the pulmonary artery and aorta"]).
answer(number(2),part(b),subpart(i),[178,1,"To prevent a backflow of blood from the ventricles back into the atria."]).
answer(number(2),part(b),subpart(i),[179,1,"the valves are to prevent backflow of blood."]).
answer(number(2),part(b),subpart(i),[180,1,"To prevent the backflow of blood."]).
answer(number(2),part(b),subpart(i),[181,1,"To prevent the backflow of blood i.e. stop blood flowing in the wrong direction"]).
answer(number(2),part(b),subpart(i),[182,0,"These push blood from the ventricles to the atrium + prevents back flow."]).
answer(number(2),part(b),subpart(i),[183,1,"These valves are there to allow blood to flow into the ventricles (A).  It is designed to prevent the blood from returning into the atrium."]).
answer(number(2),part(b),subpart(i),[184,1,"Valves stop the blood from flowing backwards the way it came"]).
answer(number(2),part(b),subpart(i),[185,1,"When the ventricles contract, they close to prevent blood from flowing back into the atriums, rather than through the arteries."]).
answer(number(2),part(b),subpart(i),[186,1,"They allow the blood to flow through them from the atria to the ventricles, but do not allow the blood to flow backwards back into the atria"]).
answer(number(2),part(b),subpart(i),[187,1,"These valves ensure there is no backflow of blood into the heart."]).
answer(number(2),part(b),subpart(i),[188,1,"The valves prevent a backflow of blood"]).
answer(number(2),part(b),subpart(i),[189,1,"these valves prevent the back flow of blood."]).
answer(number(2),part(b),subpart(i),[190,1,"The valves stop the back flow of blood."]).
answer(number(2),part(b),subpart(i),[191,1,"These valves prevent blood flowing backwards to where it came from in between contractions"]).
answer(number(2),part(b),subpart(i),[192,1,"They prevent the backflow of blood [therefore] they keep the blood going in the same direction."]).
answer(number(2),part(b),subpart(i),[193,0,"The valves prevent the backflow of blood into the ventricles below the atriums"]).
answer(number(2),part(b),subpart(i),[194,1,"To prevent blood from flowing backwards."]).
answer(number(2),part(b),subpart(i),[195,1,"To prevent backflow of the blood"]).
answer(number(2),part(b),subpart(i),[196,1,"the valves let the blood flow one way and not the other."]).
answer(number(2),part(b),subpart(i),[197,1,"They are to stop blood flowing in the wrong direction"]).
answer(number(2),part(b),subpart(i),[198,1,"they direct the blood from the atria to the ventricles, preventing the blood from flowing backwards"]).
answer(number(2),part(b),subpart(i),[199,0,"pass blood around the body in one direction"]).
answer(number(2),part(b),subpart(i),[200,1,"To make sure the blood only flows in one direction (so there is no backflow)."]).


 
