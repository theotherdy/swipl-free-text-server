
:- multifile answer/4.
answer(number(4),part('a_hooves'),subpart(0),[1,1,"to grip easly of mountain slopes."]).
answer(number(4),part('a_hooves'),subpart(0),[2,1,"Allows it to grip onto rocks and gaps in the rocks when moving around the mountains so it does not fall and it can go where it wants in order to catch food etc."]).
answer(number(4),part('a_hooves'),subpart(0),[3,0,"fought off any predators and used them to kill its prey."]).
answer(number(4),part('a_hooves'),subpart(0),[4,1,"To help the bucardo climb the mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[5,1,"help bucardo to climb rocks because they can cling them or pierce them"]).
answer(number(4),part('a_hooves'),subpart(0),[6,1,"so that it can climb mountains and grip onto unsteady ground, i.e loose rock."]).
answer(number(4),part('a_hooves'),subpart(0),[7,1,"make it easier for it to climb up high and would have good grip."]).
answer(number(4),part('a_hooves'),subpart(0),[8,1,"for grip on the hard rock and to run quickly from predators."]).
answer(number(4),part('a_hooves'),subpart(0),[9,1,"It can climb more easily steep mountains and awkward climbs."]).
answer(number(4),part('a_hooves'),subpart(0),[10,1,"As mountains are rocky, sharp curved hooves help Bucardo to grip and climb"]).
answer(number(4),part('a_hooves'),subpart(0),[11,0,"able to walk on narrow edges"]).
answer(number(4),part('a_hooves'),subpart(0),[12,0,"to help kill preadtor and so they can hang on to the mountain."]).
answer(number(4),part('a_hooves'),subpart(0),[13,0,"the hoves helped it forage for food."]).
answer(number(4),part('a_hooves'),subpart(0),[14,0,"easy to walk on mountaneous surroundings"]).
answer(number(4),part('a_hooves'),subpart(0),[15,1,"Sharp curved hooves provides grip."]).
answer(number(4),part('a_hooves'),subpart(0),[16,1,"helps the bucardo climb and balance on the mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[17,0,"to keep themselves protected."]).
answer(number(4),part('a_hooves'),subpart(0),[18,0,"makes it able to move in the mountainous conditions."]).
answer(number(4),part('a_hooves'),subpart(0),[19,1,"to help the bucardo to grip the land as it may be steep or bumpy in the mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[20,1,"will help them to grip the mountainside."]).
answer(number(4),part('a_hooves'),subpart(0),[21,1,"To help climb the mountains and to help him if he's ever under attack."]).
answer(number(4),part('a_hooves'),subpart(0),[22,1,"to give more grip and stability on the rocky surfact."]).
answer(number(4),part('a_hooves'),subpart(0),[23,1,"help them climb steep mountain sides."]).
answer(number(4),part('a_hooves'),subpart(0),[24,1,"to stop the bucardo slipping high up in the mountains and to give the bucardo grip that is why they are sharp."]).
answer(number(4),part('a_hooves'),subpart(0),[25,1,"he can get better grip on the floor he may slip at such a high height"]).
answer(number(4),part('a_hooves'),subpart(0),[26,1,"good grip so that the goat is able to walk on the cliffs & steep mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[27,1,"to climb"]).
answer(number(4),part('a_hooves'),subpart(0),[28,1,"to dig into the moutain surface so is does no fall"]).
answer(number(4),part('a_hooves'),subpart(0),[29,1,"These help to grip on rocks which are found high up so they can walk in steep slopes safely"]).
answer(number(4),part('a_hooves'),subpart(0),[30,1,"for climbing the mountains + on rocks."]).
answer(number(4),part('a_hooves'),subpart(0),[31,1,"To get extra grips while on the mountain side."]).
answer(number(4),part('a_hooves'),subpart(0),[32,1,"to grip onto rocks and mountains to prevent falling."]).
answer(number(4),part('a_hooves'),subpart(0),[33,0,"fits inbetween mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[34,0,"to defend itself against predetors"]).
answer(number(4),part('a_hooves'),subpart(0),[35,1,"to climb the mountains to find food"]).
answer(number(4),part('a_hooves'),subpart(0),[36,0,"helps to balance on steep mountain slopes - to dig into ground."]).
answer(number(4),part('a_hooves'),subpart(0),[37,1,"These would enable the bucardo to climb the mountains that might otherwise be too steep / sheer."]).
answer(number(4),part('a_hooves'),subpart(0),[38,1,"make the mountainside easier to grip and to walk on"]).
answer(number(4),part('a_hooves'),subpart(0),[39,1,"Enables the bucardo to climb the steep, rocky mountain sides, by being able to stand on the slanted rocks."]).
answer(number(4),part('a_hooves'),subpart(0),[40,1,"would easily find footholds on the steep mountain slopes."]).
answer(number(4),part('a_hooves'),subpart(0),[41,1,"These would allow them to climb steep rocks and mountains without losing footing."]).
answer(number(4),part('a_hooves'),subpart(0),[42,1,"these allow it to grip onto rocks and grass making it easier to climb up and down the mountain"]).
answer(number(4),part('a_hooves'),subpart(0),[43,1,"adapted to help the goat climb as they are sharp and curved."]).
answer(number(4),part('a_hooves'),subpart(0),[44,0,"The sharpness of the hooves enables the goat to stand on many surfaces, they are curved for heat balance."]).
answer(number(4),part('a_hooves'),subpart(0),[45,1,"to help keep their balance on the rocky mountains and to keep a grip"]).
answer(number(4),part('a_hooves'),subpart(0),[46,1,"helped grip on hard, steep surfaces"]).
answer(number(4),part('a_hooves'),subpart(0),[47,1,"acted like grips when walking, as mountains are steep, and may have helped when trying to catch prey."]).
answer(number(4),part('a_hooves'),subpart(0),[48,1,"helps it to grip onto rough surface of mountain, which may have steap sides."]).
answer(number(4),part('a_hooves'),subpart(0),[49,1,"to help the goats climb steep or rocky ground to find food."]).
answer(number(4),part('a_hooves'),subpart(0),[50,1,"helped goats to mountain a grip & walk in mountainous regions."]).
answer(number(4),part('a_hooves'),subpart(0),[51,0,"blocked it off so cold can't touch skin"]).
answer(number(4),part('a_hooves'),subpart(0),[52,1,"To climb up the mountain."]).
answer(number(4),part('a_hooves'),subpart(0),[53,1,"help to climb the rocks of the mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[54,1,"allows it to climb up jagged mountain surfaces"]).
answer(number(4),part('a_hooves'),subpart(0),[55,1,"#NAME?"]).
answer(number(4),part('a_hooves'),subpart(0),[56,0,"Good to capture prey or to dig out food with"]).
answer(number(4),part('a_hooves'),subpart(0),[57,1,"to give the goat strong grip on the rocks and the mountain"]).
answer(number(4),part('a_hooves'),subpart(0),[58,1,"This makes it easier for the bucardo to grip onto the mountain surface."]).
answer(number(4),part('a_hooves'),subpart(0),[59,1,"So he can climb up the mountain by getting his hooves into the nots ang cranies."]).
answer(number(4),part('a_hooves'),subpart(0),[60,1,"grips the mountain side allows it to move whilst preventing it from falling"]).
answer(number(4),part('a_hooves'),subpart(0),[61,1,"so the can climb and get good grips on the mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[62,1,"would benifit their climbing abilitly"]).
answer(number(4),part('a_hooves'),subpart(0),[63,1,"allows it to grip better along the mountain."]).
answer(number(4),part('a_hooves'),subpart(0),[64,0,"protection from sharp stones when walking/running."]).
answer(number(4),part('a_hooves'),subpart(0),[65,1,"meant it could grip onto the side of the mountains which are probably very steep"]).
answer(number(4),part('a_hooves'),subpart(0),[66,1,"have a grip on steep surfaces (stop slipping)."]).
answer(number(4),part('a_hooves'),subpart(0),[67,0,"To find its prey, ect - food."]).
answer(number(4),part('a_hooves'),subpart(0),[68,1,"Would allow the bucardo to grip onto sloped surfaces without falling"]).
answer(number(4),part('a_hooves'),subpart(0),[69,1,"It allows the goat to climb and steady itself on the hills. (It gives it grip)."]).
answer(number(4),part('a_hooves'),subpart(0),[70,1,"allow the goat to make it's way over steep slopes (extra grip) which is the type of terrain found high in the mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[71,0,"can walk on all surfaces"]).
answer(number(4),part('a_hooves'),subpart(0),[72,1,"allowed it to dig into the rock, which makes climbing easier."]).
answer(number(4),part('a_hooves'),subpart(0),[73,1,"for grip and balance, stability on the steep mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[74,1,"help grip and stabalise the animal to make it easier to walk up and down the mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[75,0,"Good for helping it get its food, by attacking other spieces."]).
answer(number(4),part('a_hooves'),subpart(0),[76,1,"Used to provide good grip for climbing up mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[77,1,"These would enable the bucardo to climb easily and cope with the rocky terrain of the mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[78,0,"enables it to walk up and down mountains easily and catch food."]).
answer(number(4),part('a_hooves'),subpart(0),[79,1,"So that it can climb the mountains easily, gripping the steep slopes with their sharp curved hooves"]).
answer(number(4),part('a_hooves'),subpart(0),[80,0,"he can attack his prey."]).
answer(number(4),part('a_hooves'),subpart(0),[81,1,"to help climb the mountain"]).
answer(number(4),part('a_hooves'),subpart(0),[82,1,"Climbing steep mountains and digging for food."]).
answer(number(4),part('a_hooves'),subpart(0),[83,1,"helped to grip to the mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[84,1,"helps the goat to grip onto the high mountains surface as the mountains are steep."]).
answer(number(4),part('a_hooves'),subpart(0),[85,0,"Curved to run faster and spread out surface area - Keep balance."]).
answer(number(4),part('a_hooves'),subpart(0),[86,0,"So that it can walk easily on the mountain."]).
answer(number(4),part('a_hooves'),subpart(0),[87,1,"As it lives on mountains the sharp curved hooves will help it to grip onto the land and not slip."]).
answer(number(4),part('a_hooves'),subpart(0),[88,1,"The sharp curved hooves could be the give the bucardo increased grip of the mountain side and find notches on the mountains to climb up on."]).
answer(number(4),part('a_hooves'),subpart(0),[89,1,"helped the bucardo to have a grip on the soil & ground so that it would not slip when land was steep."]).
answer(number(4),part('a_hooves'),subpart(0),[90,0,"enables it to move on the rough surface of the mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[91,0,"keeping its balance on rocks and stones"]).
answer(number(4),part('a_hooves'),subpart(0),[92,0,"helps them to walk on terrain in mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[93,1,"to help grip onto steep slopes to prevent slipping off rocks"]).
answer(number(4),part('a_hooves'),subpart(0),[94,1,"helped keep grip in the rocky hard mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[95,1,"helps bucardo to lock it to mountain surface to climb better."]).
answer(number(4),part('a_hooves'),subpart(0),[96,0,"this help the bucardo walk and keep balance when on the mountain."]).
answer(number(4),part('a_hooves'),subpart(0),[97,1,"to climb up the mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[98,1,"gives it grip on mountains so it will not fall."]).
answer(number(4),part('a_hooves'),subpart(0),[99,1,"prevent the bucardo from slipping on the high mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[100,1,"These help when climbing up rocky mountains, they would never get injured and would withstand the rockiness"]).
answer(number(4),part('a_hooves'),subpart(0),[101,1,"gave the goat good grip on the mountains rough terrain."]).
answer(number(4),part('a_hooves'),subpart(0),[102,1,"provide grip for climbing mountains & defence against predators."]).
answer(number(4),part('a_hooves'),subpart(0),[103,0,"Allowed the goat to walk on rocky ground"]).
answer(number(4),part('a_hooves'),subpart(0),[104,1,"helps them grip on steep slopes."]).
answer(number(4),part('a_hooves'),subpart(0),[105,0,"Protec itself"]).
answer(number(4),part('a_hooves'),subpart(0),[106,1,"help climb the mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[107,1,"Help to cling to rocky surfaces and jump and climb rocks easily."]).
answer(number(4),part('a_hooves'),subpart(0),[108,1,"helps goat to climb and move about easily e.g. there may be loose rocks but the goat can easily find foot holds that its hooves can cling to to help it climb the mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[109,1,"To help climb the mountains and to prevent the goat from slipping."]).
answer(number(4),part('a_hooves'),subpart(0),[110,1,"More grip and stability to move."]).
answer(number(4),part('a_hooves'),subpart(0),[111,1,"to grip onto the mountain. Also to catch prey."]).
answer(number(4),part('a_hooves'),subpart(0),[112,1,"To keep grip on mountains, and to help climb on mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[113,1,"to grasp the rocks under its hooves, as it lives on mountains the ground will be uneven."]).
answer(number(4),part('a_hooves'),subpart(0),[114,1,"helped bucardo to grip onto steep, stone surfaces such as the mountain side."]).
answer(number(4),part('a_hooves'),subpart(0),[115,0,"To balance on rocks and protect skin (so does not bleed on legs or paws)."]).
answer(number(4),part('a_hooves'),subpart(0),[116,1,"better grip on the rocky mountain sides"]).
answer(number(4),part('a_hooves'),subpart(0),[117,0,"This would protect the goat from predators."]).
answer(number(4),part('a_hooves'),subpart(0),[118,0,"To kill pray and defend him self from preditors."]).
answer(number(4),part('a_hooves'),subpart(0),[119,1,"to maintain grip on the mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[120,1,"To run faster & catch its prey. To climb easier."]).
answer(number(4),part('a_hooves'),subpart(0),[121,1,"able to grip the turf and roam the slopes."]).
answer(number(4),part('a_hooves'),subpart(0),[122,1,"to help climb and dig arount the mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[123,1,"to grip and climb high in the mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[124,1,"It allows them to grip on to icy areas of rock on mountain cliffs"]).
answer(number(4),part('a_hooves'),subpart(0),[125,1,"help it to climb up mountains with out falling."]).
answer(number(4),part('a_hooves'),subpart(0),[126,1,"to help them grip the steep rocks they had to climb."]).
answer(number(4),part('a_hooves'),subpart(0),[127,1,"are for moving around on the mountain it hooves a very gripy"]).
answer(number(4),part('a_hooves'),subpart(0),[128,0,"to be able to walk around easily on the mountains as it can be very rocky."]).
answer(number(4),part('a_hooves'),subpart(0),[129,1,"To provide better grip on the mountain rocks and avoid falling"]).
answer(number(4),part('a_hooves'),subpart(0),[130,1,"this helps it to climb mountains and run across them easily."]).
answer(number(4),part('a_hooves'),subpart(0),[131,1,"They are able to dig into the mountain rocks and small cracks so they can climb on steep mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[132,1,"allowed bucardo to maintain grip on mountainous terrain"]).
answer(number(4),part('a_hooves'),subpart(0),[133,1,"to get grip when climbing mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[134,1,"help it to climb / walk on the mountain"]).
answer(number(4),part('a_hooves'),subpart(0),[135,0,"used for hunting for food to kill its prey."]).
answer(number(4),part('a_hooves'),subpart(0),[136,1,"These would help the goat to climb by allowing him to hook onto small ridges and hook into the rocks on the mountainside."]).
answer(number(4),part('a_hooves'),subpart(0),[137,1,"good grip when walking on the mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[138,0,"protection from predators"]).
answer(number(4),part('a_hooves'),subpart(0),[139,0,"To keep them stable on the mountain rock."]).
answer(number(4),part('a_hooves'),subpart(0),[140,1,"to grip on to the mountains so it is easier to climp"]).
answer(number(4),part('a_hooves'),subpart(0),[141,1,"Help goat to be more stable on land as they can grip the rocky mountain surface."]).
answer(number(4),part('a_hooves'),subpart(0),[142,1,"This enabled the goat to grip onto the rocky mountain slopes"]).
answer(number(4),part('a_hooves'),subpart(0),[143,1,"allow the bucardo to be able to climb."]).
answer(number(4),part('a_hooves'),subpart(0),[144,1,"to help him grip onto the rocks"]).
answer(number(4),part('a_hooves'),subpart(0),[145,1,"This was to help them grip on to the rocks when they needed to climb or come down."]).
answer(number(4),part('a_hooves'),subpart(0),[146,1,"To give it grip when climbing and walking on the mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[147,1,"good for gripping and climbing the rough mountainous enviroment with"]).
answer(number(4),part('a_hooves'),subpart(0),[148,0,"allows the bucardo to tread on the rough mountain rocks, acting as protection."]).
answer(number(4),part('a_hooves'),subpart(0),[149,0,"So they wouldnt fall And furmley stay on the Ground."]).
answer(number(4),part('a_hooves'),subpart(0),[150,1,"To help it grip on the uneven rocky surfaces of the mountain"]).
answer(number(4),part('a_hooves'),subpart(0),[151,0,"to help it wAlk on the steep And rocky mountAins"]).
answer(number(4),part('a_hooves'),subpart(0),[152,1,"The sharp curved hooves enable the bucardo to dig them into the mountainside while climbing preventing them from falling"]).
answer(number(4),part('a_hooves'),subpart(0),[153,1,"To keep grip on the slopes"]).
answer(number(4),part('a_hooves'),subpart(0),[154,0,"help them to walk on the steep, uneven mountain sides"]).
answer(number(4),part('a_hooves'),subpart(0),[155,1,"are useful to help the bucardo climb the mountains. The improve the grip."]).
answer(number(4),part('a_hooves'),subpart(0),[156,1,"to grip on the rocky mountain sides."]).
answer(number(4),part('a_hooves'),subpart(0),[157,1,"to help him climb up & down the mountains without sliding or slipping"]).
answer(number(4),part('a_hooves'),subpart(0),[158,1,"Provide grip / firm hooves for walking the hilly and rough mountain surfaces. Protect the feet."]).
answer(number(4),part('a_hooves'),subpart(0),[159,0,"to kill prey with or to dig for food with and for protection against predators and for climbing on the hills."]).
answer(number(4),part('a_hooves'),subpart(0),[160,0,"to enable it to move quickly around the mountain terrain."]).
answer(number(4),part('a_hooves'),subpart(0),[161,1,"enabled it to climb over rocks and up the mountain sides."]).
answer(number(4),part('a_hooves'),subpart(0),[162,0,"helps fight of predictors and help catch pray."]).
answer(number(4),part('a_hooves'),subpart(0),[163,1,"This helped the goat to grip the rocky mountains, enabling them to climb the steep gradients."]).
answer(number(4),part('a_hooves'),subpart(0),[164,1,"The hooves would be useful for the Bucardo to get a grip on the steep mountain paths."]).
answer(number(4),part('a_hooves'),subpart(0),[165,1,"provides grip on rock ect."]).
answer(number(4),part('a_hooves'),subpart(0),[166,0,"To travel in the mountains it helps stability by being sharp digging into mountain and curved like a mountain."]).
answer(number(4),part('a_hooves'),subpart(0),[167,1,"allows them to cling onto rocky surfaces better."]).
answer(number(4),part('a_hooves'),subpart(0),[168,1,"gives the burcado the grip they need to climb steep mountains & also enables them to kill their prey."]).
answer(number(4),part('a_hooves'),subpart(0),[169,1,"to help it grip on the mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[170,1,"this allows the animal to grip will on the steep slopes"]).
answer(number(4),part('a_hooves'),subpart(0),[171,1,"helped them grip on to things so they could go up the mountain."]).
answer(number(4),part('a_hooves'),subpart(0),[172,1,"to give it a strong grip on the rocky surface"]).
answer(number(4),part('a_hooves'),subpart(0),[173,1,"Good grip on sloping land and sharpness also for defense purposes against predators."]).
answer(number(4),part('a_hooves'),subpart(0),[174,0,"fend off other animals."]).
answer(number(4),part('a_hooves'),subpart(0),[175,1,"provide the bucardo with grip on the rocks and scree-covered mountain slopes."]).
answer(number(4),part('a_hooves'),subpart(0),[176,1,"For grip and protection of the feet."]).
answer(number(4),part('a_hooves'),subpart(0),[177,1,"gave extra grip and stability."]).
answer(number(4),part('a_hooves'),subpart(0),[178,1,"to climb and keep a good grip on the mountainside, steep rocks."]).
answer(number(4),part('a_hooves'),subpart(0),[179,0,"to kill his food when he would need this and try to attack any invaders !"]).
answer(number(4),part('a_hooves'),subpart(0),[180,0,"protection against predators and to kill prey."]).
answer(number(4),part('a_hooves'),subpart(0),[181,0,"useful for small thin pasages through the mountains."]).
answer(number(4),part('a_hooves'),subpart(0),[182,0,"So he can find prey Help him find food."]).
answer(number(4),part('a_hooves'),subpart(0),[183,0,"Curved hooves mean smaller surface area so less heat loss."]).
answer(number(4),part('a_hooves'),subpart(0),[184,0,"helps the bucado to walk on the mountains with its hooves sharp against the ground"]).
answer(number(4),part('a_hooves'),subpart(0),[185,0,"The dig up rock and protect from preditors"]).
answer(number(4),part('a_hooves'),subpart(0),[186,1,"so it can grip and kill things with"]).
answer(number(4),part('a_hooves'),subpart(0),[187,0,"Helps to kill it's prey."]).
answer(number(4),part('a_hooves'),subpart(0),[188,0,"It can help them scare off predator to protect themselves from being eaten by predators."]).
answer(number(4),part('a_hooves'),subpart(0),[189,0,"They helped them attack."]).
answer(number(4),part('a_hooves'),subpart(0),[190,0,"to run fast and also to travel up the mountain"]).
answer(number(4),part('a_hooves'),subpart(0),[191,0,"can protect its sefl if attacted"]).
answer(number(4),part('a_hooves'),subpart(0),[192,0,"protect it from being eaten by predators and also a means of killing prey"]).
answer(number(4),part('a_hooves'),subpart(0),[193,0,"from the rocks, so he can't hurt himself from what he treds on."]).
answer(number(4),part('a_hooves'),subpart(0),[194,0,"protect it against predators"]).
answer(number(4),part('a_hooves'),subpart(0),[195,0,"in order to defend himsef from any danger as well as to catch food for himself in order to stay alive."]).
answer(number(4),part('a_hooves'),subpart(0),[196,0,"easy to walk over mountains"]).
answer(number(4),part('a_hooves'),subpart(0),[197,0,"would of helped the goat keep his balance and he would have been able to stick his feet in gaps."]).
answer(number(4),part('a_hooves'),subpart(0),[198,0,"to help them scratch and kill prey."]).
answer(number(4),part('a_hooves'),subpart(0),[199,0,"hunting for food, catching prey."]).
answer(number(4),part('a_hooves'),subpart(0),[200,0,"to dig up with and defend itself / find food."]).

 
