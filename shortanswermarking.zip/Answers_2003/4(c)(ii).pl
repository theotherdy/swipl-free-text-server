:- multifile answer/4.

answer(number(4),part(c),subpart(ii),[1,0,"Trying to introduce them to the wild again, and create variation so they can reproduce. This tissue may include a mutation which will be present in all clones."]).
answer(number(4),part(c),subpart(ii),[2,0,"returning it to its natural habitat."]).
answer(number(4),part(c),subpart(ii),[3,0,"How the Bucardo will turn out"]).
answer(number(4),part(c),subpart(ii),[4,0,"how to breed it."]).
answer(number(4),part(c),subpart(ii),[5,0,"turning it into a bucardo"]).
answer(number(4),part(c),subpart(ii),[6,0,"Whether it was morally right or wrong to do it"]).
answer(number(4),part(c),subpart(ii),[7,1,"They will then have to try and make another bucardo the opposite sex to the other embryo"]).
answer(number(4),part(c),subpart(ii),[8,1,"they will not have another bucardo to act as a surrogate or host."]).
answer(number(4),part(c),subpart(ii),[9,1,"They do not have another Bucardo to implant the embryo into so it will be difficult to implant it into another goat without its body rejecting it."]).
answer(number(4),part(c),subpart(ii),[10,1,"Turning the embryo into a foetus inserting the embryo into a womb of the same species."]).
answer(number(4),part(c),subpart(ii),[11,0,"Clones tend to have problems and may die quickly or face athritus."]).
answer(number(4),part(c),subpart(ii),[12,0,"get it to survive in the wild."]).
answer(number(4),part(c),subpart(ii),[13,1,"Cloning reduces the gene pool of the organism, :. may be immune to less diseases"]).
answer(number(4),part(c),subpart(ii),[14,0,"if it would survive of it may have problems"]).
answer(number(4),part(c),subpart(ii),[15,1,"It will develop any deceases or weakness the bucardo had."]).
answer(number(4),part(c),subpart(ii),[16,0,"not noing if there is any faults with the process."]).
answer(number(4),part(c),subpart(ii),[17,1,"Finding a female bucardo to put the embryo in so it can develop."]).
answer(number(4),part(c),subpart(ii),[18,1,"They will not be able to reproduce because they only have female cells"]).
answer(number(4),part(c),subpart(ii),[19,0,"If the bucardo dies out due to it not being able to adapt to a change of environment it will also kill the cloned bucardo."]).
answer(number(4),part(c),subpart(ii),[20,1,"Trying to find a mother to implant the embryo into."]).
answer(number(4),part(c),subpart(ii),[21,0,"breading them."]).
answer(number(4),part(c),subpart(ii),[22,0,"getting it to develop in to a bucardo"]).
answer(number(4),part(c),subpart(ii),[23,0,"mutations, mating the goat, creating more bucardos, ethical issues, health of goat."]).
answer(number(4),part(c),subpart(ii),[24,0,"How the bucardo will live and reproduce."]).
answer(number(4),part(c),subpart(ii),[25,1,"no bucardo to implant it in."]).
answer(number(4),part(c),subpart(ii),[26,0,"That more will be developed and they would just be extinct again as they are not a protected species."]).
answer(number(4),part(c),subpart(ii),[27,0,"Growing it - There are no more bucardos left."]).
answer(number(4),part(c),subpart(ii),[28,0,"trying to mate the bucardo"]).
answer(number(4),part(c),subpart(ii),[29,0,"Fertilising the embryo itself."]).
answer(number(4),part(c),subpart(ii),[30,0,"How to keep the bucardo goats alive."]).
answer(number(4),part(c),subpart(ii),[31,0,"trying to prevent it from becoming endangered again."]).
answer(number(4),part(c),subpart(ii),[32,0,"They need another one for it to breed."]).
answer(number(4),part(c),subpart(ii),[33,0,"how to bring it up in that environment and my have deformaties when asexualy reproduced"]).
answer(number(4),part(c),subpart(ii),[34,0,"Finding an environment where the embryo will grow"]).
answer(number(4),part(c),subpart(ii),[35,1,"They have to find a female burcado to give birth to it."]).
answer(number(4),part(c),subpart(ii),[36,0,"It might not work right like it might not digest food or have somthing wrong with its brain"]).
answer(number(4),part(c),subpart(ii),[37,0,"Reproducing offspring"]).
answer(number(4),part(c),subpart(ii),[38,0,"The mager Ploblem is feeding it and protecting from getting damages"]).
answer(number(4),part(c),subpart(ii),[39,1,"The next problem is inplantation into a living organism and the growth of the embryo."]).
answer(number(4),part(c),subpart(ii),[40,0,"To put them in a surrounding which suitable for them."]).
answer(number(4),part(c),subpart(ii),[41,1,"creating 2 of differents sexes to be able to mate & reproduce"]).
answer(number(4),part(c),subpart(ii),[42,1,"They need a womb for it to grow in but all bucardo's are extinct."]).
answer(number(4),part(c),subpart(ii),[43,0,"genetics & mating"]).
answer(number(4),part(c),subpart(ii),[44,0,"To make the species if it works."]).
answer(number(4),part(c),subpart(ii),[45,1,"They will need a host organism to implant the embryo into. However, as all the bucardos are dead, this could pose problems."]).
answer(number(4),part(c),subpart(ii),[46,0,"How they will be able to make this organism thrive again as they will have make other bucardos for the population to grow. Also where they will keep it."]).
answer(number(4),part(c),subpart(ii),[47,1,"an animal suitable for the embryo to be implanted into."]).
answer(number(4),part(c),subpart(ii),[48,1,"where they will put the embryo for it to grow into a feotus"]).
answer(number(4),part(c),subpart(ii),[49,0,"Weather the bucardo embryo fertilises and or has any deformaties."]).
answer(number(4),part(c),subpart(ii),[50,0,"it is difficult to get it to develop into a new creature, it will not be adapted to its environment without a mother or family, and it will only be one bucardo, they would need to develope more to reproduce them also clones are more susceptible to disease"]).
answer(number(4),part(c),subpart(ii),[51,0,"They would have to make two bucardo's for offspring to be produced and therefore carry on genes"]).
answer(number(4),part(c),subpart(ii),[52,0,"trying to protect them from hunters and the cold."]).
answer(number(4),part(c),subpart(ii),[53,1,"How to let it grow, what animal to be it's surrogate carrier, and if it will be alright and not have defects later on, as many clones do."]).
answer(number(4),part(c),subpart(ii),[54,0,"they will have to produce another one to mate with it."]).
answer(number(4),part(c),subpart(ii),[55,0,"That it will be the only one of that species and people will want it."]).
answer(number(4),part(c),subpart(ii),[56,1,"trying to create amale bucardo to mate it with"]).
answer(number(4),part(c),subpart(ii),[57,0,"Keeping it alive without mother's milk"]).
answer(number(4),part(c),subpart(ii),[58,1,"In the past clones have started to show fast signs of ageing eg, arthretis."]).
answer(number(4),part(c),subpart(ii),[59,1,"They will have no bucardos in which to insert the embryo while it develops."]).
answer(number(4),part(c),subpart(ii),[60,0,"it is likely that it will be prone to disease."]).
answer(number(4),part(c),subpart(ii),[61,1,"Where it can be implanted to grow and develop into a baby because there are no bucardos left"]).
answer(number(4),part(c),subpart(ii),[62,1,"they would not have a female bucardo to inject it into and become its mother. Also there would be no variation of the species making it more vunerable to epidimics or climate change."]).
answer(number(4),part(c),subpart(ii),[63,1,"They need a living bucardo (female) to implant the embryo into"]).
answer(number(4),part(c),subpart(ii),[64,0,"Not being able to breed it, and arthritis"]).
answer(number(4),part(c),subpart(ii),[65,1,"managing to implant the embryo in the uterus of a member of some other, similar species."]).
answer(number(4),part(c),subpart(ii),[66,0,"dieseizes which they could get a die in later Stage"]).
answer(number(4),part(c),subpart(ii),[67,0,"developing the embryo in the right conditions."]).
answer(number(4),part(c),subpart(ii),[68,0,"Whether to make another as the species will not be able to reproduce + continue with only 1 bucardo."]).
answer(number(4),part(c),subpart(ii),[69,1,"implanting it into a suitable 'mother' + then producing another in a different sex to reproduce then"]).
answer(number(4),part(c),subpart(ii),[70,0,"Making the Bucardo born."]).
answer(number(4),part(c),subpart(ii),[71,0,"Trying to grow it and finding another organism with which to grow it."]).
answer(number(4),part(c),subpart(ii),[72,0,"They will not know where to grow the embryo"]).
answer(number(4),part(c),subpart(ii),[73,1,"trying to ulter the DNA because otherwise they will all be the same and they will never evalve"]).
answer(number(4),part(c),subpart(ii),[74,1,"Finding a suitable 'surrogate mother' to give birth to the cloned bucardo."]).
answer(number(4),part(c),subpart(ii),[75,0,"Reproduction"]).
answer(number(4),part(c),subpart(ii),[76,1,"They need to put it somewhere safe to develop, maybe in another womb."]).
answer(number(4),part(c),subpart(ii),[77,0,"World wide criticism, mainly from the media"]).
answer(number(4),part(c),subpart(ii),[78,0,"clones cannot reproduce so they will have to clone every one."]).
answer(number(4),part(c),subpart(ii),[79,0,"Finding another bucardo to fertilise it in the futre (breeding etc.)"]).
answer(number(4),part(c),subpart(ii),[80,0,"they will have to make it able to survive and reproduce with another cloned bucardo to produce more of the species."]).
answer(number(4),part(c),subpart(ii),[81,1,"Inherited disease cloning animals can easily pass on a series of diseases"]).
answer(number(4),part(c),subpart(ii),[82,0,"they will have the problem of hatching the embryo."]).
answer(number(4),part(c),subpart(ii),[83,1,"They will have to transfer the embryo and place it into the suitable species ready to reproduce, into the host."]).
answer(number(4),part(c),subpart(ii),[84,0,"How will they breed the animal?, They cant mate it with itself."]).
answer(number(4),part(c),subpart(ii),[85,0,"The outrage from the media and religeous people"]).
answer(number(4),part(c),subpart(ii),[86,1,"They will have no female bucardo to plant the embryo in the uterus as they are extinct."]).
answer(number(4),part(c),subpart(ii),[87,1,"How to develop the embryo into a 'baby bucardo' that can survive on its own."]).
answer(number(4),part(c),subpart(ii),[88,1,"There are no other bucardo's left to implant the embryo into."]).
answer(number(4),part(c),subpart(ii),[89,0,"finding another one to breed it with as if the lone two and breed them, it will be deformed."]).
answer(number(4),part(c),subpart(ii),[90,1,"They will have to let the embryo grow but without another animal to grow it in it will be hard."]).
answer(number(4),part(c),subpart(ii),[91,0,"What to reproduce it with or where to fertilise it as where to fertilise it as there is no mother or womb."]).
answer(number(4),part(c),subpart(ii),[92,1,"They do not have another bucardo to implant the embryo in to that the embryo can grow to produce a bucardo baby."]).
answer(number(4),part(c),subpart(ii),[93,0,"Where to grow the embryo"]).
answer(number(4),part(c),subpart(ii),[94,0,"They dont have any other bucardo's for it to mate with so cant reproduce them only clone them."]).
answer(number(4),part(c),subpart(ii),[95,1,"Finding an animal suitable to have the embryo inserted into their womb."]).
answer(number(4),part(c),subpart(ii),[96,1,"They will have no bucardo to implant it into, so it has no-where to grow."]).
answer(number(4),part(c),subpart(ii),[97,1,"farming the goat and letting it get all its features before it would be born as it does not have the mother for the embryo to grow in"]).
answer(number(4),part(c),subpart(ii),[98,1,"They will face the problem of their being little genetic variation in its offspring."]).
answer(number(4),part(c),subpart(ii),[99,0,"finding a mate species"]).
answer(number(4),part(c),subpart(ii),[100,0,"making another one so that they can reproduce."]).
answer(number(4),part(c),subpart(ii),[101,1,"They have to insert it into the womb of a more common species, and then keep it alive when it's born."]).
answer(number(4),part(c),subpart(ii),[102,1,"There is no where to store the bucardo embryo e.g. no bucardo womb."]).
answer(number(4),part(c),subpart(ii),[103,1,"Find a surrogate mother suitable to bring up bucardo. To produce a breeding couple to repopulate would mean making another clone > reduced gene pool > geneticially identical > reduced resistance to disease."]).
answer(number(4),part(c),subpart(ii),[104,1,"how will it reproduce if they haven't got a male clone"]).
answer(number(4),part(c),subpart(ii),[105,1,"getting it to reproduce, as the clone would be of the same sex as it's 'mother' & there would be no one for it to mate with"]).
answer(number(4),part(c),subpart(ii),[106,1,"(1) Putting it in a uterus of an animal that can give birth to it, Keeping it alive, having the correct immunuties and food to give it. It will also be tame."]).
answer(number(4),part(c),subpart(ii),[107,1,"They have to find a surrogate to carry the embryo, but as there are no bucardo left this will be difficult."]).
answer(number(4),part(c),subpart(ii),[108,0,"They will struggle to get it to grow healthily without its parent, and then they will not have another bucardo to mate it with to create the next generation"]).
answer(number(4),part(c),subpart(ii),[109,1,"getting another one for it to mate with of the oposit sex."]).
answer(number(4),part(c),subpart(ii),[110,1,"Where to insert the embryo to allow it to develop, as the specie is extinct."]).
answer(number(4),part(c),subpart(ii),[111,1,"The bucardo will not be able to procreate as the only sample with which to clone is another bucardo female. Therefore they will only ever be able to make female bucardo"]).
answer(number(4),part(c),subpart(ii),[112,1,"They will need to find an animal that could act as a surrogate while the embryo develops."]).
answer(number(4),part(c),subpart(ii),[113,1,"Finding an animal that the embryo can develop in before it is born."]).
answer(number(4),part(c),subpart(ii),[114,0,"Breeding the bucardo to produce more of them."]).
answer(number(4),part(c),subpart(ii),[115,0,"They wouldn't be able to give birth to it as it isn't inside another animal"]).
answer(number(4),part(c),subpart(ii),[116,0,"They will need one male and one female the would neet lots of different bucardos because if they bread it would make in breads."]).
answer(number(4),part(c),subpart(ii),[117,0,"getting it to reproduce properly"]).
answer(number(4),part(c),subpart(ii),[118,1,"As there are no bucardos left there will be no female into whose womb they could implant the embryo."]).
answer(number(4),part(c),subpart(ii),[119,1,"which animnal they should implant the embryo into and whether it is ethically alright to try and produce a bucardo"]).
answer(number(4),part(c),subpart(ii),[120,1,"They have no bucardo's left to insemenate the embryo with."]).
answer(number(4),part(c),subpart(ii),[121,1,"They would need to find a suitable animal to place this clone in. Then they would have to breed a male vertion."]).
answer(number(4),part(c),subpart(ii),[122,1,"feeding it and producing a male as cells where only taken from a female."]).
answer(number(4),part(c),subpart(ii),[123,1,"They won't be able to mate the bucardo so they will have to clone the bucardo again and all the bucardo will be genetically identical meaning they will be more succeptibility to diseases."]).
answer(number(4),part(c),subpart(ii),[124,1,"There will not be a male bucardo for the female clone to mate with."]).
answer(number(4),part(c),subpart(ii),[125,0,"what to plant it into?"]).
answer(number(4),part(c),subpart(ii),[126,0,"They will face the problem of breeding them because they will be from the same cells."]).
answer(number(4),part(c),subpart(ii),[127,0,"They will find it difficult to protect and it may be succeptible to or spread new diseases."]).
answer(number(4),part(c),subpart(ii),[128,0,"They will need to find it a mate so that it can produce offspring"]).
answer(number(4),part(c),subpart(ii),[129,0,"they will only be able to reproduce by mitosis which would only provide a genetically identical partner for the clone to mate with"]).
answer(number(4),part(c),subpart(ii),[130,1,"Many cloned embryos do not mature correctly, resulting in deformations and miscarriages. A suitable animal would have to be found to carry the embryo."]).
answer(number(4),part(c),subpart(ii),[131,1,"Producing a bucardo of a different gender, so two of them can mate and produce offspring."]).
answer(number(4),part(c),subpart(ii),[132,1,"Finding a sample of the opposite sex so that they can breed."]).
answer(number(4),part(c),subpart(ii),[133,1,"Implanting it into a womb to be kept warm and nutriated and grow there - because there are no other bucardos left."]).
answer(number(4),part(c),subpart(ii),[134,1,"finding a mother to implant the embryo into."]).
answer(number(4),part(c),subpart(ii),[135,1,"They may need a womb to place it in so that it can grow and have nutrients provided for it."]).
answer(number(4),part(c),subpart(ii),[136,1,"They will have to find a host mother for the embryo, which would give birth to it."]).
answer(number(4),part(c),subpart(ii),[137,0,"Clones often have health problems. Also another must be made in order to them to reproduce."]).
answer(number(4),part(c),subpart(ii),[138,1,"They have to insert the embryo into a mother which will be a problem as there are no more bucardos."]).
answer(number(4),part(c),subpart(ii),[139,1,"They would have to find a surrogate mother for the embryo whose womb would not reject the embryo as a foreign organism."]).
answer(number(4),part(c),subpart(ii),[140,0,"There will be no other bucardo for it to reproduce with."]).
answer(number(4),part(c),subpart(ii),[141,1,"The embryo must be implanted into the womb of an animal, but as no bucardos are left it may be necessary for a different animal to carry the embryo."]).
answer(number(4),part(c),subpart(ii),[142,1,"They need to find an animal which they can implant the embryo into for it to develop."]).
answer(number(4),part(c),subpart(ii),[143,1,"Finding a suitable surrogate mother."]).
answer(number(4),part(c),subpart(ii),[144,0,"Getting the embryo to grow successfully into an adult bucardo."]).
answer(number(4),part(c),subpart(ii),[145,1,"If the clone inherits any bad illnesses or if it develops any illnesses it could spread disease and die."]).
answer(number(4),part(c),subpart(ii),[146,0,"Developing the bucardo embryo into a fully grown bucardo."]).
answer(number(4),part(c),subpart(ii),[147,1,"growing the embryo, as there are no bucardo mothers to raise it in its uterus, and so they may have to grow it in another animal, acting as a surrogate mother."]).
answer(number(4),part(c),subpart(ii),[148,0,"To get sperm from a nother bucardo"]).
answer(number(4),part(c),subpart(ii),[149,1,"They will have to find an animal which is suitable to have embryo implanted into it."]).
answer(number(4),part(c),subpart(ii),[150,1,"Which animal to place the embryo in."]).
answer(number(4),part(c),subpart(ii),[151,0,"finding a possible sperm donater of the same species they may need to find a male bucardo."]).
answer(number(4),part(c),subpart(ii),[152,1,"The embryo needs to be placed in an uterus of an animal which can allow it to grow."]).
answer(number(4),part(c),subpart(ii),[153,0,"It won't be able to reproduce."]).
answer(number(4),part(c),subpart(ii),[154,1,"be able to create a different one with a different sex so they can breed"]).
answer(number(4),part(c),subpart(ii),[155,0,"stopping the embryo from getting any diformity e.g an extra eye etc."]).
answer(number(4),part(c),subpart(ii),[156,1,"Making a bucardo of the opposite sex so that they can breed."]).
answer(number(4),part(c),subpart(ii),[157,0,"producing bucardo sperm to fertize the embryo"]).
answer(number(4),part(c),subpart(ii),[158,1,"What animal to plant the embryo in."]).
answer(number(4),part(c),subpart(ii),[159,1,"There are no longer mother bucardo's to carry the embryo during its development."]).
answer(number(4),part(c),subpart(ii),[160,1,"They'll have to try to grow the embryo in another spieces."]).
answer(number(4),part(c),subpart(ii),[161,1,"Where to put it to grow and develop into a foetus and then baby. They have no female bucardo's would to use."]).
answer(number(4),part(c),subpart(ii),[162,1,"Finding another animal or an artificial womb suitable to implant the embryo so that it can develop into a foetus and then a baby goat."]).
answer(number(4),part(c),subpart(ii),[163,1,"The animal will not be able to reproduce sexually, because it will not have a mate so all bucardo's will have to be cloned and that will be no variation in the species"]).
answer(number(4),part(c),subpart(ii),[164,1,"Trying to recreate an entire species from one animal, with no access to reproductive cells of the opposite sex."]).
answer(number(4),part(c),subpart(ii),[165,1,"They would need a carrier to grow the embryo."]).
answer(number(4),part(c),subpart(ii),[166,1,"Then it will be difficult because a surrogate mother must be found in which the embryo can develop"]).
answer(number(4),part(c),subpart(ii),[167,0,"They won't have a bucardo sperm cell to reproduce a feotus"]).
answer(number(4),part(c),subpart(ii),[168,1,"There wouldn't be a surrogate mother of the same species to carry the embryo til it's fully developed"]).
answer(number(4),part(c),subpart(ii),[169,0,"they wont have a mother to produce the embryo"]).
answer(number(4),part(c),subpart(ii),[170,1,"They will have to find a suitable animal to place the embryos in, so that it can be born."]).
answer(number(4),part(c),subpart(ii),[171,1,"They will have to place the embryo into an animal's womb for it to grow. It will be a problem to determine which animal is similar to a bucardo in which to plant the embryo as Bucardo's are now extinct."]).
answer(number(4),part(c),subpart(ii),[172,1,"how to make another of the opposite sex so they can reproduce. They would also have to keep them safe."]).
answer(number(4),part(c),subpart(ii),[173,1,"find a surrogate mother to give birth to it"]).
answer(number(4),part(c),subpart(ii),[174,1,"They will need to implant the embryo into another species of goat to gestate."]).
answer(number(4),part(c),subpart(ii),[175,1,"It will have to be planted in a womb of another goat to grow."]).
answer(number(4),part(c),subpart(ii),[176,0,"There would only be one bucardo and it wouldn't be able to mate. There are many problems with clones especially with infertility."]).
answer(number(4),part(c),subpart(ii),[177,1,"How to grow the embryo as there are no more bucardo's to grow the embryo in there whooms."]).
answer(number(4),part(c),subpart(ii),[178,1,"varing the type of bucardo otherwise they will all be the same."]).
answer(number(4),part(c),subpart(ii),[179,0,"There are no other bucardos left to mate with it so the species will die out, also which animal to be a foster mother to the bucardo."]).
answer(number(4),part(c),subpart(ii),[180,0,"They would have to artificially grow the embryo, also cloned species are liable to health problems as - well. It would also be hard to breed more"]).
answer(number(4),part(c),subpart(ii),[181,1,"They will have to provide a decent environment for the embryo to develop in because there will not be a female Bucardo womb available."]).
answer(number(4),part(c),subpart(ii),[182,1,"Producing a mate. The last bucardo was a female and now they need to find cells from a male bucardo."]).
answer(number(4),part(c),subpart(ii),[183,1,"Which animal should be used to host the embryo as it grows,"]).
answer(number(4),part(c),subpart(ii),[184,1,"The embryo will have to grow in the right conditions without being in its mothers womb, which could prove to be very difficult."]).
answer(number(4),part(c),subpart(ii),[185,1,"Finding a womb for it to develop in."]).
answer(number(4),part(c),subpart(ii),[186,1,"They would have to implant it into another animal as there are no female bucardos left"]).
answer(number(4),part(c),subpart(ii),[187,1,"They will only have a bucardo of one sex so it will not be able to reproduce."]).
answer(number(4),part(c),subpart(ii),[188,1,"they will have no bucardos to carry the embryo & give birth to it."]).
answer(number(4),part(c),subpart(ii),[189,0,"producing another bucardo which will be able to reproduce with the first to create fertile offspring."]).
answer(number(4),part(c),subpart(ii),[190,1,"lack of variety in the bucardo population makes them vulnerable to new diseases due to a reduced gene pool of the New bucardo population."]).
answer(number(4),part(c),subpart(ii),[191,1,"They will have to reproduce a womb for the embryo to grow in."]).
answer(number(4),part(c),subpart(ii),[192,1,"They may not know where to put the bucardo embryo, and how to make sure it grows in correct conditions (like the womb of the mother)"]).
answer(number(4),part(c),subpart(ii),[193,1,"The cloned bucardo will not be able to reproduce because it needs a mate and there is no male bucardo for the female bucardo to produce offspring with."]).
answer(number(4),part(c),subpart(ii),[194,1,"They will have to produce another for it to eventually mate with, but there will be no genetic variation so the species would not be able to adapt"]).
answer(number(4),part(c),subpart(ii),[195,1,"a decrease in the variation of the gene pool, Also the fact that the bucardo's are extinct, creates the problem as to which organism the embryo should be placed in - surrogacy. The embryo needs to be injected into a uterus for development."]).
answer(number(4),part(c),subpart(ii),[196,1,"The embryo cannot be put in a mother's uterus as bucardo has extincted."]).
answer(number(4),part(c),subpart(ii),[197,1,"Breeding the Bucardo because if they are all male there are no females, or vice versa and they can only make one gender from the sample."]).
answer(number(4),part(c),subpart(ii),[198,1,"breeding the animal, they only have the tissue of a female bucardo."]).
answer(number(4),part(c),subpart(ii),[199,1,"They will have to find a host animal to implant the embryo into who is compatible & whose body will not reject the embryo."]).
answer(number(4),part(c),subpart(ii),[200,1,"They will have to implant the embryo into a different species"]).

 
