
:- multifile answer/4.

answer(number(2),part(b),subpart(ii),[1,0,"They contract when not letting blood pass, then relax when they know that there is space for more blood"]).
answer(number(2),part(b),subpart(ii),[2,0,"When all the blood passes through, the valves squeeze up and tighten, preventing backflow"]).
answer(number(2),part(b),subpart(ii),[3,1,"As the blood enters the pulmonary vein it enters the atrium and then the ventricle.  The valves close once the blood has passed in the ventricle to stop it flowing backwards"]).
answer(number(2),part(b),subpart(ii),[4,1,"When the heart contracts one of the valves closes but when it retracts the other valve closes and the other opens."]).
answer(number(2),part(b),subpart(ii),[5,1,"They let blood through in one direction as the flaps of the valve only open one way but if the blood tries to flow back the flaps close preventing it from doing so."]).
answer(number(2),part(b),subpart(ii),[6,2,"If pressure is put on them from beneath such as that of blood pushing on them, they close, preventing entry to the blood there."]).
answer(number(2),part(b),subpart(ii),[7,0,"These valves work together.  When one valves lets blood out the other lets blood in"]).
answer(number(2),part(b),subpart(ii),[8,1,"they let blood pass by them if it is going the right way but close tightly together to stop any blood flowing backwards they are pulled closed by tendons."]).
answer(number(2),part(b),subpart(ii),[9,2,"When there is a high blood pressure in the atriums, they contract + open, letting the blood rush out.  They then slacken and close when there is high blood pressure in the ventricles, so the blood doesnt go back to the atrium."]).
answer(number(2),part(b),subpart(ii),[10,1,"The valves open + close.  This is caused by blood pressure"]).
answer(number(2),part(b),subpart(ii),[11,0,"The blood just runs through them slowely."]).
answer(number(2),part(b),subpart(ii),[12,1,"They open as blood is pumped through but immediately close as soon as the blood is through."]).
answer(number(2),part(b),subpart(ii),[13,1,"The valves can be pushed open one way, but if something pushes from the other side they close because of their shape."]).
answer(number(2),part(b),subpart(ii),[14,1,"they only let it get through one way and close if it trys to come back through"]).
answer(number(2),part(b),subpart(ii),[15,1,"The valves are opened and closed according to pressure, if there is high pressure when there blood they will open as the blood goes through they close when there is nothing present in the section e.g atria."]).
answer(number(2),part(b),subpart(ii),[16,0,"As the oxygenated blood enters the heart the valve opens and then closes.  The other valves does the same so the two do not mix."]).
answer(number(2),part(b),subpart(ii),[17,0,"The valves are shaped like lunar moons and act as a door.  If blood tries to flow in the wrong direction they cannot get through them."]).
answer(number(2),part(b),subpart(ii),[18,0,"The valves allow blood to pass through in the correct direction.  If the blood tries to travel back the way it has come the valves prevent this because their shape does not allow backflow."]).
answer(number(2),part(b),subpart(ii),[19,1,"The valves snap shut to prevent backflow into the ventricles once the blood has passed through they make sure blood is flowing in the right direction"]).
answer(number(2),part(b),subpart(ii),[20,1,"they open to let blood flow through and close to let stop blood flowing throgh"]).
answer(number(2),part(b),subpart(ii),[21,0,"When the blood fills up the valves close so no more blood can enter then re-open when empty."]).
answer(number(2),part(b),subpart(ii),[22,1,"As the blood enters the valves give way but if the blood was to backflow, then the valves would be pushed together by the blood."]).
answer(number(2),part(b),subpart(ii),[23,1,"The valves only open if pressure is applied in one direction, if it is applied from the other direction they remain shut."]).
answer(number(2),part(b),subpart(ii),[24,2,"The valves are pushed open by the pressure of the blood then if the blood tries go back through the valves it causes the valves to close and then the cycle starts again."]).
answer(number(2),part(b),subpart(ii),[25,0,"they tend to curve in one particular way, making it difficult for blood to flow in the opposing way to this."]).
answer(number(2),part(b),subpart(ii),[26,0,"Increasing blood pressure in the artria cause the valves to open"]).
answer(number(2),part(b),subpart(ii),[27,1,"as blood passes throug the right way it lets it through but if it comes back they close to stop it"]).
answer(number(2),part(b),subpart(ii),[28,1,"After blood has passed through the valves, they close to prevent the blood going backwards."]).
answer(number(2),part(b),subpart(ii),[29,1,"When the atria are full and put pressure on the valves, they open to allow the blood through and then close again to prevent backflow."]).
answer(number(2),part(b),subpart(ii),[30,1,"They do this by only letting blood flow through in one direction by locking together if the blood tries to flow in the wrong direction.  Their shape makes it impossible for blood to backflow otherwise this would happen."]).
answer(number(2),part(b),subpart(ii),[31,0,"because gose one way and the other the other way so the blood goes round"]).
answer(number(2),part(b),subpart(ii),[32,1,"As the muscles (ventricals + Atriems) contract the blood is pushed through the valves, then the valves close, preventing backflow."]).
answer(number(2),part(b),subpart(ii),[33,0,"By opening and closing so when the heart pumps the top chamber fills with blood, valves close and the bottom chambers empty.  Valves open and the bottom chambers fill again."]).
answer(number(2),part(b),subpart(ii),[34,0,"They only open one way, everytime the heart pumps they relax and let blood through."]).
answer(number(2),part(b),subpart(ii),[35,2,"They can open if blood is pushing from the atria so blood flows through to ventricles, however they close firmly if blood is at pressure in ventricles, so blood flows out the arteries instead."]).
answer(number(2),part(b),subpart(ii),[36,1,"Once blood is pumped out the valves are forced closed, to stop blood from getting back into the heart."]).
answer(number(2),part(b),subpart(ii),[37,0,"They make the blood is being passed the right way and doesn't go backwards carrie blood around the body supplying muscles with oxygen"]).
answer(number(2),part(b),subpart(ii),[38,1,"The valves alow blood to flow through one way but close when blood tries to flow the opposite way."]).
answer(number(2),part(b),subpart(ii),[39,1,"They close as blood flows through them so that if the blood starts flowing the opposite way, they make it impossible for it to do so."]).
answer(number(2),part(b),subpart(ii),[40,1,"They have flaps which only open in one direction but if pushed against in the other direction are closed."]).
answer(number(2),part(b),subpart(ii),[41,0,"They open and close on each pump of the heart."]).
answer(number(2),part(b),subpart(ii),[42,1,"The aorta contracts forcing (due to high blood pressure) the valve to open, but the valves are like trap doors and only open one way so that blood will not pass from the ventricle to the aorta."]).
answer(number(2),part(b),subpart(ii),[43,1,"As the blood enters the right atria once the blood in the right ventricle has been pushed through the pulmonary artery the valve opens to let all the blood in the atria to the ventricle.  The same thing occurs on the left side.  The valve then closes to s"]).
answer(number(2),part(b),subpart(ii),[44,0,"These valves do not allow blood to flow back because they only go one way, eg, blood cannot travel back because the valves are too strong."]).
answer(number(2),part(b),subpart(ii),[45,1,"The open under the pressure of the blood and a pushed shut by blood attempting to flow the wrong way."]).
answer(number(2),part(b),subpart(ii),[46,1,"As the ventricles contract, the 'flaps' of the valves are pushed back and join, closing off the atria and so preventing blood from flowing back into them.  The blood is forced out of the only exit (either the pulmonary artery or aorta)."]).
answer(number(2),part(b),subpart(ii),[47,0,"They move so that nothing can get down their."]).
answer(number(2),part(b),subpart(ii),[48,0,"The valves carry out their jobs by only being able to open and close one way."]).
answer(number(2),part(b),subpart(ii),[49,0,"From one valve blood that is deoxygenated comes back and from the next valve oxygenated blood is pumped around the body."]).
answer(number(2),part(b),subpart(ii),[50,0,"They move so you can breathe."]).
answer(number(2),part(b),subpart(ii),[51,1,"When the heart is in ventricular ?sisstole? The ventricals contract to push the blood into the arteries, the valves snap shut by pressure to prevent the backflow of blood so all the blood enters the arteries"]).
answer(number(2),part(b),subpart(ii),[52,1,"As the atria push the blood into the ventricles these valves pop shut so that all blood will continue to flow down aorta or pulmonary artery and not flow backwards."]).
answer(number(2),part(b),subpart(ii),[53,0,"they contract when they take in blood and relax when they pump out blood."]).
answer(number(2),part(b),subpart(ii),[54,0,"When you breathe in the valves open, when you breathe out they close."]).
answer(number(2),part(b),subpart(ii),[55,1,"once blood has passed them they shut, so blood has only on exit to carry on by."]).
answer(number(2),part(b),subpart(ii),[56,0,"The valves open and close to carry out their job"]).
answer(number(2),part(b),subpart(ii),[57,0,"When the heart is waiting for blood to be pumped, these valves will open and allow blood in the heart to be pumped."]).
answer(number(2),part(b),subpart(ii),[58,1,"The valves open as the blood is pumped through them.  They close behind the blood, so none flows back again."]).
answer(number(2),part(b),subpart(ii),[59,0,"These valves are shaped in a specific way and so blood can easily pass through them in the right direction but then, if it tried to pass through them the wrong way, the curved shape prevents this from happening."]).
answer(number(2),part(b),subpart(ii),[60,0,"they open and close letting blood through"]).
answer(number(2),part(b),subpart(ii),[61,1,"The valves open and close.  They open to allow blood to pass but close after to stop the blood flowing back in the wrong direction."]).
answer(number(2),part(b),subpart(ii),[62,0,"The valves are like little flaps and they only let particals go in one direction."]).
answer(number(2),part(b),subpart(ii),[63,0,"The valves carry out their job as the valves consist of a fine but tough membrane which only lets blood flow one way through it and not the other way."]).
answer(number(2),part(b),subpart(ii),[64,1,"Well when blood enters the heart the valve closes to make sure that the blood can not back flow and when it exits the heart on the other side the value opens up let's the blood out then closes again."]).
answer(number(2),part(b),subpart(ii),[65,0,"They are thin and blood would push it's way through"]).
answer(number(2),part(b),subpart(ii),[66,1,"After blood is pumped into the ventricles, they close to make sure it doesn't go the other way."]).
answer(number(2),part(b),subpart(ii),[67,0,"The valves open up until the atrium is full they then close to stop th blood flowing back into the ventricle"]).
answer(number(2),part(b),subpart(ii),[68,0,"They only let blood go one way not both because it blocks blood coming from the same place."]).
answer(number(2),part(b),subpart(ii),[69,1,"When the blood flows through these valves they open, afterwards they automatically close inwards so that the blood can go back through."]).
answer(number(2),part(b),subpart(ii),[70,1,"The blood is pumped and the valve opens, once the blood passes through it, it closes to stop it retreating back downwards."]).
answer(number(2),part(b),subpart(ii),[71,1,"because blood flows in a double loop they close to stop the blood flowing back."]).
answer(number(2),part(b),subpart(ii),[72,0,"When blood flows into the right side of the heart through the aorta/pulmonary artery it puts presure on the valve and the valve opens letting blood into the right and left ventricles.  There is no more pressure on the valves after that and (for the time b"]).
answer(number(2),part(b),subpart(ii),[73,0,"These valves work by, opening up, allowing the blood to flow through, and when some blood, goes the opposite way, they close."]).
answer(number(2),part(b),subpart(ii),[74,0,"When blood comes into the heart from the rest of the body it is stored/kept in the right chamber so blood can go to the lungs."]).
answer(number(2),part(b),subpart(ii),[75,0,"the open when the blood is to be pumped out and close to alowe the blood to fill up without leaking out"]).
answer(number(2),part(b),subpart(ii),[76,0,"They pop shut when the ventricles open because of the pressure.  They have little pockets which fill up with blood going backwards and the empty when they open again."]).
answer(number(2),part(b),subpart(ii),[77,0,"When blood is pumped into the atria their muscles contract + they close to prevent flow into the ventricles - and when the ventricles pump blood to the atria and hence the rest of the body they close to prevent backflow to the ventricles."]).
answer(number(2),part(b),subpart(ii),[78,0,"carry messages to the body to tell them what to do. (send messages)."]).
answer(number(2),part(b),subpart(ii),[79,1,"The valves close and open automatically when the pressure is increased.  The pressure of the venticles causes the valves to close and when blood enters the atria the pressure causes them to open."]).
answer(number(2),part(b),subpart(ii),[80,0,"they open and close."]).
answer(number(2),part(b),subpart(ii),[81,1,"When the blood moves backwards it pushes the valves closed."]).
answer(number(2),part(b),subpart(ii),[82,1,"The valves carry out their Job by oppening when blood flows through them to allow it to pass, and then closing behind the flow of blood to keep it flowing in the same direction."]).
answer(number(2),part(b),subpart(ii),[83,1,"When blood is in the atria, this makes the valves open.  When blood in the ventricles is pumped to the arteries, the valves close."]).
answer(number(2),part(b),subpart(ii),[84,0,"They open and close."]).
answer(number(2),part(b),subpart(ii),[85,1,"When blood is passed through the valves move together to stop blood flowing back into the atrium.  They work as a one way system, not allowing blood to go back."]).
answer(number(2),part(b),subpart(ii),[86,1,"They allow the blood to pass through in one direction then close so that it can't flow back out in the other direction."]).
answer(number(2),part(b),subpart(ii),[87,0,"by opening and closing"]).
answer(number(2),part(b),subpart(ii),[88,1,"The valves shut if blood is being transported in the wrong direction."]).
answer(number(2),part(b),subpart(ii),[89,1,"The atrium contracts at high pressure, force valves open, blood flows into ventricles, blood in ventricles, in at a low pressure forces valves to shut, until blood pumped to body or heart through semilunar valves."]).
answer(number(2),part(b),subpart(ii),[90,0,"they blow out the amount of blood then they lock together process is repeated"]).
answer(number(2),part(b),subpart(ii),[91,1,"They let blood flow forward through them but if the blood flows backwards they close so that no blood goes the wrong way."]).
answer(number(2),part(b),subpart(ii),[92,1,"These close when the ventricles push the blood out of the heart and open when the blood flows from the atria to the ventricles."]).
answer(number(2),part(b),subpart(ii),[93,0,"They move up & down so the blood can only get in or out not both of the ways"]).
answer(number(2),part(b),subpart(ii),[94,0,"They only allow blood to flow in one direction."]).
answer(number(2),part(b),subpart(ii),[95,0,"The gap between them widens as the blood comes through and contract once the blood has passed"]).
answer(number(2),part(b),subpart(ii),[96,0,"These carry out their function by when a flow of blood is detected in the wrong direction, their flaps open like a parachute and do not allow the blood to travel through them."]).
answer(number(2),part(b),subpart(ii),[97,0,"When blood is pumped round the body, the valves open to allow the blood to flow.  However, if there is a backlog, the valves alter their shape to make it flow correctly."]).
answer(number(2),part(b),subpart(ii),[98,0,"they make sure that the blood cannot flow back on itself."]).
answer(number(2),part(b),subpart(ii),[99,0,"the Left valve has more muscle so it can pump the Blood the Right one has less muscle so it can do its job."]).
answer(number(2),part(b),subpart(ii),[100,0,"The valves do this by making sure that once the blood has eg. Flowed into the atrium to be pumped around the body, it snaps back in place and provides a barrier for this blood"]).
answer(number(2),part(b),subpart(ii),[101,2,"When the ventricle walls contract to push blood into the aorta and pulmonary vein a high pressure is created, this causes the flaps of the valves to close shutting the atriums to the ventricle."]).
answer(number(2),part(b),subpart(ii),[102,1,"they can be pushed down and thus opened as blood goes from atrium to ventricle but will be pushed closed if blood tries to travel the other way"]).
answer(number(2),part(b),subpart(ii),[103,2,"The open and close with blood pressure.  The atriums contract forcing the valves to open, blood flows through, the valves.  The atrium relaxes and then the ventricles contract.  The valves close with the pressure and so the only way for the blood to go is"]).
answer(number(2),part(b),subpart(ii),[104,1,"As the blood flows through the valves it is then pumped through the arteries because when the heart pumps, if the blood tries to go back up the veins, it closes the valves stopping it from going back that way."]).
answer(number(2),part(b),subpart(ii),[105,1,"They allow blood to push through them to get into the ventrical, but then close, so that it can't get back into the atrium."]).
answer(number(2),part(b),subpart(ii),[106,0,"They contract, closing and opening when the blood reaches the appropriate pressure to be pumped in or out."]).
answer(number(2),part(b),subpart(ii),[107,1,"They have a flap that opens to allow blood to flow through and then closes to stop the blood flowing backwards.  This function is happening all the time as blood flows in the heart and veins."]).
answer(number(2),part(b),subpart(ii),[108,1,"If blood were to flow in the wrong direction then the valves close due to applied pressure."]).
answer(number(2),part(b),subpart(ii),[109,1,"When the blood has entered a chamber, it will try to push back through a valve to decrease volume, but the valve snaps shut to prevent this"]).
answer(number(2),part(b),subpart(ii),[110,0,"The valves can only be forced up from one direction."]).
answer(number(2),part(b),subpart(ii),[111,1,"if the blood is flowing the right way the valves open up but if its not the close."]).
answer(number(2),part(b),subpart(ii),[112,0,"They open and close depending on how much let in and let out."]).
answer(number(2),part(b),subpart(ii),[113,0,"When blood enters the atria and the atria contract, the valves open allowing the blood through, however can only opn one way (see left)"]).
answer(number(2),part(b),subpart(ii),[114,1,"as blood flows through them they open but to stop blood from flowing back they close allowing good blood flow."]).
answer(number(2),part(b),subpart(ii),[115,1,"The semi lunar valve + bicuspid valve stops blood entering the right ventricle and left atrium by two flaps which close as the heart beats."]).
answer(number(2),part(b),subpart(ii),[116,1,"They are similar to doors opening only one way.  When the heart beats blood is squeezed into the next chamber of the heart and the valves snap shut."]).
answer(number(2),part(b),subpart(ii),[117,1,"They are like automatic double doors they open whe blood is flowing through one way and closes if no blood is coming from that direction."]).
answer(number(2),part(b),subpart(ii),[118,1,"The valves work by letting the blood flow in one direction, however when it travels in another the valves close causing the blood to stop flowing in that direction, and change the flow to the alternate direction through the now open valves."]).
answer(number(2),part(b),subpart(ii),[119,1,"When the blood is pumped through the valves are forced open (naturally open in required direction) but when the blood is through they close preventing the blood from going back."]).
answer(number(2),part(b),subpart(ii),[120,0,"If blood were to flow through the veins in the wrong direction then the valves would close firmly and prevent it from doing so.  They also, as shown on the diagram, prevent blood from flowing back into the venrticles from the atria."]).
answer(number(2),part(b),subpart(ii),[121,0,"Inbetween every contraction of the heart the close to prevent the backflow of blood, when the heart pumps they open to let blood through."]).
answer(number(2),part(b),subpart(ii),[122,0,"These valves are designed to allow blood to flow into the destined place, but are designed to open only one way, so that it cannot return and go the wrong way."]).
answer(number(2),part(b),subpart(ii),[123,1,"These valves close up when blood has been pumped through and catches the backflow of blood (it can do this because the heart has contracted)"]).
answer(number(2),part(b),subpart(ii),[124,1,"When the atria contract, the valves open and let the blood flow through, but when the ventricles contract, they are forced shut ensuring that blood does not flow back."]).
answer(number(2),part(b),subpart(ii),[125,1,"They are curved slightly so they can only open one way, when enough blood has passed through the valve it slams shut."]).
answer(number(2),part(b),subpart(ii),[126,0,"As blood is pumped into the ventricles, they expand, which stretches the muscles controlling the valves, causing them to shut."]).
answer(number(2),part(b),subpart(ii),[127,1,"As the first compartment of blood starts to fill up the valve closes.  Then, after the second compartment has left through the artery, the valves open, allowing the blood into the ventricle."]).
answer(number(2),part(b),subpart(ii),[128,1,"the valves close together so that they are able to control the flow of blood."]).
answer(number(2),part(b),subpart(ii),[129,1,"Once blood has travelled through the valve it closes so the blood cannot travel through the same way preventing backflow & causing high pressure."]).
answer(number(2),part(b),subpart(ii),[130,1,"They allow blood to travel through one way only.  If blood tries to go the other way the valve is closed off, therefore stopping it."]).
answer(number(2),part(b),subpart(ii),[131,1,"The valves are flaps and are kept together but open when the blood pushes past them.  Then one the blood has gone through they close again to prevent backflow"]).
answer(number(2),part(b),subpart(ii),[132,0,"The valves can only open one way therefore keeping a one-way system."]).
answer(number(2),part(b),subpart(ii),[133,1,"when the blood is being pumped into the ventricles from the atrium they open when the ventricles pump blood out of the ventricles the valves close"]).
answer(number(2),part(b),subpart(ii),[134,0,"They can only move one way, the can only open one way, they cant be pushed back."]).
answer(number(2),part(b),subpart(ii),[135,1,"If the blood goes the wrong way the valves are curved so the blood pushes them and they close to that the blood can't go the wrong way but alows it to go the right way."]).
answer(number(2),part(b),subpart(ii),[136,1,"the blood passes through the valves and then the valves close, not allowing any blood back, keeping it flowing in the same direction"]).
answer(number(2),part(b),subpart(ii),[137,1,"When the blood enters a different ventricle or atrium, they close to prevent the backflow of blood.  When the blood enters the ventricles, the valves then close, preventing blood from backflowing into the atria."]).
answer(number(2),part(b),subpart(ii),[138,0,"As blood enters the heart it is pumped from the atrium to the ventricle then the heart contracts causing blood to leave the heart so any blood trying to leave the heart via the valve it can't because as blood is pushed, it gets pushed onto the valve so th"]).
answer(number(2),part(b),subpart(ii),[139,1,"every time the heart beats it pumps the blood through the valves when they are open and then the valves close and open in a cycle."]).
answer(number(2),part(b),subpart(ii),[140,1,"When the ventricles contract to pump the blood into the aorta + pulmonary artery the valves shut."]).
answer(number(2),part(b),subpart(ii),[141,1,"When blood flows the right way, valves open.  When blood backflows, the valves are forced shut and does not allow blood through."]).
answer(number(2),part(b),subpart(ii),[142,0,"They move blood through the heart and stop the blood from falling in the wrong direction by closing if the pressure is too low."]).
answer(number(2),part(b),subpart(ii),[143,1,"If the blood is going the right way through the valves, things continue as normal.  But if it starts flowing backwards, the flaps of the valve come together and close, preventing blood from flowing in that wrong direction."]).
answer(number(2),part(b),subpart(ii),[144,1,"they allow blood to flow through but then close so no blood is allowed to flow backwards"]).
answer(number(2),part(b),subpart(ii),[145,0,"When the heart pumps, the muscles in the heart contract forcing the valves to close and thereby preventing any blood flow through the heart."]).
answer(number(2),part(b),subpart(ii),[146,1,"the Valves can only be opened one way so when blood goes through the they will close until more blood is passed through"]).
answer(number(2),part(b),subpart(ii),[147,1,"The valves open as blood enters the heart so that it can reach the ventricles, but shuts when the blood is flowing to the rest of the body to avoid backflow."]).
answer(number(2),part(b),subpart(ii),[148,1,"Blood from the atrium is pumped into the ventricles while the valves are open and when the ventricle is full the valves close so no more blood can enter from the atrium."]).
answer(number(2),part(b),subpart(ii),[149,1,"As blood flows into the heart they are opened, but as soon as the blood is in the heart they close, so that the blood can only flow in the right direction"]).
answer(number(2),part(b),subpart(ii),[150,1,"the valves are like little one way flaps, as the blood pushes against it they open, but when the blood tries to go back the other way it just pushes them shut?"]).
answer(number(2),part(b),subpart(ii),[151,1,"these valves carry out there jobs by letting blood through but if it tries to go back it shuts them."]).
answer(number(2),part(b),subpart(ii),[152,1,"When the blood enters the right way they open to let it pass through.  If the blood tries to flow the other way the valve automatically closes."]).
answer(number(2),part(b),subpart(ii),[153,1,"after the blood has passed through the valves close."]).
answer(number(2),part(b),subpart(ii),[154,2,"When an atrium fills with blood the pressure pushes the valves open and blood flows through into the ventricle.  However pressure of blood in the ventricle pushes the valves back shut so blood cannot escape."]).
answer(number(2),part(b),subpart(ii),[155,0,"when these side of the heart fills with blood they close and then the blood is pumped another way."]).
answer(number(2),part(b),subpart(ii),[156,1,"The valves open letting in blood they then close to stop blood thats been let in from going out."]).
answer(number(2),part(b),subpart(ii),[157,1,"When the muscle in the ventricle wall contracts, the valves close, so that blood is forced out of the aorta/pulmonary artery, not back into the atrium."]).
answer(number(2),part(b),subpart(ii),[158,1,"They open to allow blood in and then let blood be pumped around the body.  They close in a certain way which only allows blood to go one way."]).
answer(number(2),part(b),subpart(ii),[159,1,"The valves are normally closed.  When the cardiac muscle contracts, it forces blood through the valves.  The valves then close again, preventing blood from flowing back."]).
answer(number(2),part(b),subpart(ii),[160,1,"When blood flows from the atrium to the ventricle the valves relax and open, but as blood flows out of the ventricle through the arteries the valves contract and close"]).
answer(number(2),part(b),subpart(ii),[161,1,"They are designed so than it will let blood threw one way but if the blood comes back it closes."]).
answer(number(2),part(b),subpart(ii),[162,1,"The blood is pushed out of the heart and the valves are open, once the blood has left the ventricle the valves close together to stop blood flowing back."]).
answer(number(2),part(b),subpart(ii),[163,1,"blood flows the wrong way against the valves, they are forced closed"]).
answer(number(2),part(b),subpart(ii),[164,1,"the shut when the heart ventrisystoles so the blood does not flow back into the atria."]).
answer(number(2),part(b),subpart(ii),[165,1,"They open to allow blood through into the ventricles.  When they are filled with blood, they are forced to close by the pressure"]).
answer(number(2),part(b),subpart(ii),[166,1,"The valves only allow blood through one way as they are facing in a certain direction.  When blood tries to flow backwards, the valves close, preventing it from flowing in the wrong direction."]).
answer(number(2),part(b),subpart(ii),[167,1,"When the blood enters the atria the valves open to let it into the ventricles But when the ventricles pump the blood to the pulmonary artery or aorta The atria-ventricle valves snap shut"]).
answer(number(2),part(b),subpart(ii),[168,1,"When blood is flowing the right way it pushes the flaps of the valves which part so it can pass, but when the heart contracts and the blood moves up, it pushes the flaps shut so it cannot get through."]).
answer(number(2),part(b),subpart(ii),[169,1,"The valves allow blood to pass through them one way but when/if it tries the flow the other way the valve closes [therefore] not allowing the the blood through"]).
answer(number(2),part(b),subpart(ii),[170,0,"they carry out their job by when the blood comes in to the heart then the valves shut and when the blood is pushed out they open to prevent any backwas of blood."]).
answer(number(2),part(b),subpart(ii),[171,1,"The atria contract and push blood through the valves.  The atria then relax and pull the valves shut.  The valves cannot open the other way and are elasticated so they close when there is no pressure on them."]).
answer(number(2),part(b),subpart(ii),[172,1,"Only open when blood is flowing in one direction but when the blood tries to flow backwards the valves close"]).
answer(number(2),part(b),subpart(ii),[173,2,"If the blood starts to flow the other way, the valves close up due to the pressure of the blood, so they prevent backflow"]).
answer(number(2),part(b),subpart(ii),[174,1,"After blood passes through the valves, they close therefore disalowing the blood to flow back down the vein."]).
answer(number(2),part(b),subpart(ii),[175,1,"They allow blood to pass through one way only.  They open to allow blood through,  then close to prevent backflow by acting like umbrellas, catching the blood"]).
answer(number(2),part(b),subpart(ii),[176,1,"When the atria contract and ventricles relax.  There is a high pressure in atria, so valves are forced open to allow blood into the ventricles.  When the ventricles contract and atria relax, there is a high pressure in the ventricles, so valves are forced"]).
answer(number(2),part(b),subpart(ii),[177,0,"Shut (contracted) to allow blood to flow into the atria, open (relaxed) to allow blood to flow to ventricles.  They are shaped in a crescent so no blood can flow backwards and up."]).
answer(number(2),part(b),subpart(ii),[178,0,"When the atria fill with blood the pressure causes them to open allowing the blood to flow through into the ventricles.  The heart strings attached to the valves cause them to close."]).
answer(number(2),part(b),subpart(ii),[179,1,"The valves squeeze shut when the ventricles contract to prevent the blood in the ventricles from entering the atriums again, so that instead it goes into the aorta or pulmonary vein."]).
answer(number(2),part(b),subpart(ii),[180,1,"With each heartbeat, the blood is pushed forward.  Therefore, with every beat, the valves open enough to allow that blood through and then close again.  They only operate in one direction."]).
answer(number(2),part(b),subpart(ii),[181,1,"The valves open and close, once blood is about to enter they open to allow blood to go through and close after the blood has gone"]).
answer(number(2),part(b),subpart(ii),[182,1,"eg in the left atria, blood is passed from the atria to the ventricle.  The tricuspid valves then close, stopping blood flowing from the way it came, but going to the pulmonary artery."]).
answer(number(2),part(b),subpart(ii),[183,1,"When blood flows the right way, they open and let the blood run in that direction, BUT as blood flows the wrong way, they close preventing the blood to flow that way."]).
answer(number(2),part(b),subpart(ii),[184,1,"When the ventricles beat these valves immediately close and the blood can [therefore] not flow backwards into the atria - when the ventricles relax these valves immediately open and blood can flow from the atria into the ventricle again."]).
answer(number(2),part(b),subpart(ii),[185,1,"When blood passes from the atria to the ventricles it forces the valves open.  When it has entered, the pressure in the ventricles holds them closed, preventing any backflow."]).
answer(number(2),part(b),subpart(ii),[186,1,"They are relaxed when blood is in the atria.  When blood is pushed into the ventricles by muscle contraction, they close so the blood cannot go back, and it moves into the arteries when ventricles contract."]).
answer(number(2),part(b),subpart(ii),[187,2,"These valves work so blood can only pass through one way (from the atria to the ventricles).  If pressure from the blood trying to travel the opposite way is applied, they close and do not open to let the blood back into the atria."]).
answer(number(2),part(b),subpart(ii),[188,1,"The valves are shaped so that if blood is flowing in the right direction, the valves move aside, but if blood starts to flow in the wrong direction, it will push the valves down and thus prevent the flow of blood (see diagrams)."]).
answer(number(2),part(b),subpart(ii),[189,1,"When the specific chamber contracts to release the blood, the valves pop open allowing the blood through and then close quickly to stop the blood from re-entering."]).
answer(number(2),part(b),subpart(ii),[190,1,"They are arrow shaped and if the blood flows back the valves closes.  The valves only open when blood is pumped to force the valve open."]).
answer(number(2),part(b),subpart(ii),[191,1,"The atria beat and pump blood into the ventricles.  The valves open to allow this.  They then spring shut, to prevent the blood in the ventricles backflowing into the atria, held by ligaments."]).
answer(number(2),part(b),subpart(ii),[192,1,"They close when the blood is in the next section of the heart e.g when the blood is in the ventricles the tricupids valves close so blood won't flow into atrium again and therefore it will move to the next section of the cycle"]).
answer(number(2),part(b),subpart(ii),[193,1,"They are shaped in a way that if blood changed its corse they would close to make sure that it went the right way"]).
answer(number(2),part(b),subpart(ii),[194,1,"When the blood is pumped into the ventricles the valves close until they are ready to open again, and let the blood flow out again, until the heartbeat has passed."]).
answer(number(2),part(b),subpart(ii),[195,1,"The heart pumps and the blood is then pushed through the valves.  The valves close as soon as the blood is through and prevent backflow as they can not be pushed open the wrong way."]).
answer(number(2),part(b),subpart(ii),[196,1,"they only open one way so if the blood would try to the opposite way they would close."]).
answer(number(2),part(b),subpart(ii),[197,1,"when the blood flows into the certain compartment the valves shut behind it so the blood cannot escape backwards."]).
answer(number(2),part(b),subpart(ii),[198,1,"The valves point downwards which means that the blood can easily pass from the atria to the ventricle but going the other way the valve will be pushed shut by the blood."]).
answer(number(2),part(b),subpart(ii),[199,0,"they push down in the direction that the blood is flowing but if the blood tried to go the other way it is constricted."]).
answer(number(2),part(b),subpart(ii),[200,1,"They open when the pressure is high in the atrium to allow the blood into the ventricals but once the pressure is high in the ventricals they are forced closed"]).

 
