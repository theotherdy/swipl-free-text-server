
:- multifile answer/4.
answer(number(4),part(c),subpart(i),[1,2,"A clone is a genitically identical organism, and so will have all the same genes as the last bucardo"]).
answer(number(4),part(c),subpart(i),[2,2,"A copy of something else, it is exactly the same, with the same DNA and chromosomes."]).
answer(number(4),part(c),subpart(i),[3,1,"A clone is a copy of a set of jeans."]).
answer(number(4),part(c),subpart(i),[4,2,"A genetically identical organism (to the organism that provided the cell)"]).
answer(number(4),part(c),subpart(i),[5,1,"It is an identical copy of another of the same organism/species using it's genes."]).
answer(number(4),part(c),subpart(i),[6,2,"An exact genetic copy of a living organism."]).
answer(number(4),part(c),subpart(i),[7,2,"An exact replica of the orrigional, with identical genetic material as same chromosomes and DNA."]).
answer(number(4),part(c),subpart(i),[8,2,"a clone is an organism that has identical DNA to another. They are exactly the same."]).
answer(number(4),part(c),subpart(i),[9,2,"A clone is an exact genetic copy of a living thing"]).
answer(number(4),part(c),subpart(i),[10,2,"A clone is a living organism which is genetically identical to another organism"]).
answer(number(4),part(c),subpart(i),[11,1,"Is a species, an exact object that is the same as another, such as identical twins."]).
answer(number(4),part(c),subpart(i),[12,1,"an exact copy of any living creature it was cloned from"]).
answer(number(4),part(c),subpart(i),[13,2,"it is an organism which is a geneticaly identical copy of what it was copied from."]).
answer(number(4),part(c),subpart(i),[14,1,"an exact repulace of the thing the sample was taken from"]).
answer(number(4),part(c),subpart(i),[15,1,"An artificial copy of an animal or plant using only cells."]).
answer(number(4),part(c),subpart(i),[16,2,"a cell reproduces itself (mitosis) so it produces identical offspring ie. same genetic information as parent cell."]).
answer(number(4),part(c),subpart(i),[17,1,"An exact replica of a species using mitosis cell division where you take 2 daughter cells which are exactly identical to the original."]).
answer(number(4),part(c),subpart(i),[18,1,"An exact replicate of a somthing"]).
answer(number(4),part(c),subpart(i),[19,0,"a replicer of something else produced by the DNA of another animal"]).
answer(number(4),part(c),subpart(i),[20,1,"A genetically identical cell or group of cells made from one parent made by mitosis."]).
answer(number(4),part(c),subpart(i),[21,0,"A replication of animal cells to create the exact species"]).
answer(number(4),part(c),subpart(i),[22,1,"something man made that is exactly the same as"]).
answer(number(4),part(c),subpart(i),[23,2,"Someone who is genetically like you and has every thing about you the same."]).
answer(number(4),part(c),subpart(i),[24,0,"A clone is a way of producing creature without sexual reproduction"]).
answer(number(4),part(c),subpart(i),[25,2,"An exact genetic copy of a single organism."]).
answer(number(4),part(c),subpart(i),[26,2,"It is an exact replication of an organism containing identical DNA and chromosomes which means it has identical charateristics. It is identical to its parents"]).
answer(number(4),part(c),subpart(i),[27,2,"A clone is an organism for example the goat which has identical DNA to another organism. No sexual reproduction takes place."]).
answer(number(4),part(c),subpart(i),[28,2,"a copy of another living thing, by copying the DNA in the cell of the origonal animale"]).
answer(number(4),part(c),subpart(i),[29,0,"Try and make another bucardo. Creating more bucardos."]).
answer(number(4),part(c),subpart(i),[30,2,"The exact replica of another mammel. A clone has the exact DNA as the original mammel."]).
answer(number(4),part(c),subpart(i),[31,2,"a genetically identical copy"]).
answer(number(4),part(c),subpart(i),[32,1,"A clone is cells which are exactly the same as the owner's cells, to make the same bucardo"]).
answer(number(4),part(c),subpart(i),[33,0,"clone is when they try to make something with a sample."]).
answer(number(4),part(c),subpart(i),[34,0,"keep them alive to reproduce."]).
answer(number(4),part(c),subpart(i),[35,1,"a clone is a replicer of another plant of animal made from a cell from that thing"]).
answer(number(4),part(c),subpart(i),[36,1,"an exact identical copy of itself"]).
answer(number(4),part(c),subpart(i),[37,2,"It is when the DNA of an animal is coppied to produced and animal just like the one the DNA was taken from."]).
answer(number(4),part(c),subpart(i),[38,2,"An identical copy of another organism. It has the exact same genetic information."]).
answer(number(4),part(c),subpart(i),[39,2,"A clone is a genetic replica of something which has identical DNA."]).
answer(number(4),part(c),subpart(i),[40,2,"Genetically identical individual"]).
answer(number(4),part(c),subpart(i),[41,1,"a clone is a exact copy of a species using their genes"]).
answer(number(4),part(c),subpart(i),[42,1,"It is the identical copy of the orginal animal which they took the tissue from."]).
answer(number(4),part(c),subpart(i),[43,0,"clone is making the same species from cells from another species."]).
answer(number(4),part(c),subpart(i),[44,1,"A match, the same as the cell it was formed with."]).
answer(number(4),part(c),subpart(i),[45,1,"It is an exact replica of the animal the tissue was taken from"]).
answer(number(4),part(c),subpart(i),[46,1,"An exact replica"]).
answer(number(4),part(c),subpart(i),[47,2,"A genetically identical copy of the cells."]).
answer(number(4),part(c),subpart(i),[48,2,"An exact replica of a living thing. It looks & has exact things e.g DNA"]).
answer(number(4),part(c),subpart(i),[49,1,"It is an exact replica of another cell or species that is made by the process of meiosis."]).
answer(number(4),part(c),subpart(i),[50,1,"like a baby made the same as something else like an embryo of this species which will make a baby one."]).
answer(number(4),part(c),subpart(i),[51,1,"a copy of something eg Rabit fake a clone and you can form another."]).
answer(number(4),part(c),subpart(i),[52,1,"It Is a copy of An animal made sicentificly, with Nuclei from stored from stored cells."]).
answer(number(4),part(c),subpart(i),[53,2,"An extact repial/copy of what ever it was cloned from including exsat DNA copies. Every thing the same, as the oringal."]).
answer(number(4),part(c),subpart(i),[54,0,"re - create"]).
answer(number(4),part(c),subpart(i),[55,1,"A clone is an organism bred through genetic engineering that is identical to the organism who's DNA it comes from."]).
answer(number(4),part(c),subpart(i),[56,1,"A clone is the exact copy of the animal it has been taken from."]).
answer(number(4),part(c),subpart(i),[57,1,"a clone is a replica of a certain animal"]).
answer(number(4),part(c),subpart(i),[58,2,"An exact copy of the parent genetically. Mitosis is used in cloning."]).
answer(number(4),part(c),subpart(i),[59,1,"A clone is an exact replica, an exact copy of the species."]).
answer(number(4),part(c),subpart(i),[60,1,"a clone is a exact replica of a animal or a species"]).
answer(number(4),part(c),subpart(i),[61,2,"It is an exact copy of another organism. Its DNA are identical"]).
answer(number(4),part(c),subpart(i),[62,2,"A clone is a genetically identical creation of another animal."]).
answer(number(4),part(c),subpart(i),[63,2,"A animal that is created from an exact genetic genes as another animal."]).
answer(number(4),part(c),subpart(i),[64,2,"A clone is a reproduction of an animal that contains the same chromosones & genetic make-up."]).
answer(number(4),part(c),subpart(i),[65,1,"A clone is a exact copy of an existing unique animal or person."]).
answer(number(4),part(c),subpart(i),[66,2,"A genetically identicle, artificially made animal/plant/creature using tissues from the"]).
answer(number(4),part(c),subpart(i),[67,2,"An exact replicar of the genitic tissues and Dna of the deceased animal they have copied."]).
answer(number(4),part(c),subpart(i),[68,2,"A clone is the process of genetically producing an identical organism as the one you started of with."]).
answer(number(4),part(c),subpart(i),[69,1,"A clone is a copy of something or a specie."]).
answer(number(4),part(c),subpart(i),[70,1,"A clone is something that is exactly the same as something else"]).
answer(number(4),part(c),subpart(i),[71,1,"A clone is an exact replica of a specie."]).
answer(number(4),part(c),subpart(i),[72,2,"A clone is a copy that is genetically identical to the original - they have the same DNA."]).
answer(number(4),part(c),subpart(i),[73,1,"making exactly the same as something else like a humin"]).
answer(number(4),part(c),subpart(i),[74,1,"A clone is a exact copy of something that is produced by scientist."]).
answer(number(4),part(c),subpart(i),[75,1,"A clone is an exact copy of an organism."]).
answer(number(4),part(c),subpart(i),[76,1,"a clone is exactly the same as the speeicies it is being cloned from."]).
answer(number(4),part(c),subpart(i),[77,2,"A clone is an exact genetic replica of something else. The clone has the exact same genes as the thing it is being cloned from."]).
answer(number(4),part(c),subpart(i),[78,1,"An organism which is copied exactly from another organism, using cells from its body."]).
answer(number(4),part(c),subpart(i),[79,1,"an exact copy of a person or being"]).
answer(number(4),part(c),subpart(i),[80,2,"A clone is an organism with the exact same genetic code as the organism from which it was cloned."]).
answer(number(4),part(c),subpart(i),[81,2,"A clone is a replica of an organism which the same DNA and appearence."]).
answer(number(4),part(c),subpart(i),[82,2,"A re-make of something, an exact copy including things like DNA"]).
answer(number(4),part(c),subpart(i),[83,1,"It is an identical Copy of its mother produced through asexual reproduction."]).
answer(number(4),part(c),subpart(i),[84,0,"A clone is a type of experiment which investigates rare animals of its rare cells."]).
answer(number(4),part(c),subpart(i),[85,1,"It is a genetically built modle and it is identical to the origenal."]).
answer(number(4),part(c),subpart(i),[86,1,"a clone is a copy made from they DNA of a creature"]).
answer(number(4),part(c),subpart(i),[87,1,"A copy of anything whats a lifeform."]).
answer(number(4),part(c),subpart(i),[88,2,"an offspring which has the same chromosomes as the cell it was created from"]).
answer(number(4),part(c),subpart(i),[89,1,"It is an exact copy of a living thing."]).
answer(number(4),part(c),subpart(i),[90,1,"A clone is an identical copy of the parent made through the cell division process of mitosis."]).
answer(number(4),part(c),subpart(i),[91,1,"a replica of something that once lived .ie. the bucardo."]).
answer(number(4),part(c),subpart(i),[92,2,"A clone is an exact copy of the genetic makeup of a cell."]).
answer(number(4),part(c),subpart(i),[93,2,"a clone is when an organism's DNA is used to produce another organism that has the exact same DNA as the original; an exact replica."]).
answer(number(4),part(c),subpart(i),[94,2,"A genetically identical copy of an organism or the parent cell(s)."]).
answer(number(4),part(c),subpart(i),[95,2,"a clone is an exact genetic replicar of a certain living organism."]).
answer(number(4),part(c),subpart(i),[96,2,"An exact replica of an organism: genetic information is exactly the same"]).
answer(number(4),part(c),subpart(i),[97,2,"A clone is an offspring which is genetically identical to its parent i.e. was created from only one other organism"]).
answer(number(4),part(c),subpart(i),[98,2,"It is a species made from the cells of the same species. The clone is ginetically identical"]).
answer(number(4),part(c),subpart(i),[99,1,"and animal or person or plant which is exactly the same organism as what it has been made from."]).
answer(number(4),part(c),subpart(i),[100,1,"It is an exact replica of the animal that the cell is taken from."]).
answer(number(4),part(c),subpart(i),[101,2,"a clone is an exact replica of an organism which has the same genetic make up and DNA"]).
answer(number(4),part(c),subpart(i),[102,0,"It is where you take cells of an animal and use it to create another one."]).
answer(number(4),part(c),subpart(i),[103,0,"It is a cell to make a inbread species."]).
answer(number(4),part(c),subpart(i),[104,0,"Something made from a little bird an animal to make another."]).
answer(number(4),part(c),subpart(i),[105,1,"A clone is a copy of an animal which is exactly the same."]).
answer(number(4),part(c),subpart(i),[106,0,"To make something like a certain species by using that species DNA."]).
answer(number(4),part(c),subpart(i),[107,2,"A clone is an organism that is genetically identical to its parent."]).
answer(number(4),part(c),subpart(i),[108,0,"A re make of an animal that did live but Now dead"]).
answer(number(4),part(c),subpart(i),[109,2,"an exact genetic copy of somthing"]).
answer(number(4),part(c),subpart(i),[110,1,"A copy of an animal produced by Asexual reproduction e.g. bacteria are cloned."]).
answer(number(4),part(c),subpart(i),[111,1,"An identical replication from a parent cell."]).
answer(number(4),part(c),subpart(i),[112,0,"when they use the DNA from the nuclei and try and reproduce."]).
answer(number(4),part(c),subpart(i),[113,2,"A clone is a cell which is genetically identical to it's parent."]).
answer(number(4),part(c),subpart(i),[114,2,"An organism that has been reproduced asexually using the cells of one parent so that parent and offspring are genetically identical"]).
answer(number(4),part(c),subpart(i),[115,2,"A clone is an organism that has identical genes to the embryo in which it was cloned from."]).
answer(number(4),part(c),subpart(i),[116,2,"A clone is using body cells and reproducing them to be an exact copy of the original cells genetically."]).
answer(number(4),part(c),subpart(i),[117,1,"A clone is something that is made by coping the cells of another organism."]).
answer(number(4),part(c),subpart(i),[118,2,"A clone is a genetically identical organism made by copying cells from another animal."]).
answer(number(4),part(c),subpart(i),[119,1,"Its a exact replica of the dead bucardo"]).
answer(number(4),part(c),subpart(i),[120,1,"A clone is something made to look identical to something else using cells and genes."]).
answer(number(4),part(c),subpart(i),[121,1,"You take some of the DNA of something and make an exact replica. (Double)"]).
answer(number(4),part(c),subpart(i),[122,1,"A clone is an organism that has DNA identical to that of its parent."]).
answer(number(4),part(c),subpart(i),[123,2,"a form of parenting or twinning. An organism that is genetically identical to another."]).
answer(number(4),part(c),subpart(i),[124,1,"A clone is an identical copy of the creature from which the tissue came"]).
answer(number(4),part(c),subpart(i),[125,0,"It is an animal made by scientists, the animal has no mom, or dad"]).
answer(number(4),part(c),subpart(i),[126,1,"A complete replica from the animal which the cells were took from"]).
answer(number(4),part(c),subpart(i),[127,1,"The exact same image."]).
answer(number(4),part(c),subpart(i),[128,1,"It is the result of Asexual reproduction where genes from only one parent are used making it look identical."]).
answer(number(4),part(c),subpart(i),[129,1,"A clone is an identical replica of another organism which the DNA was taken from."]).
answer(number(4),part(c),subpart(i),[130,2,"It is a genetically identical organism. It will be genetically identical to the bucardo the sample was taken from."]).
answer(number(4),part(c),subpart(i),[131,0,"It is something remade by cells from a creature"]).
answer(number(4),part(c),subpart(i),[132,2,"A clone is an exact copy of its parents. It is made by taking a tissue and causing it to divide by mitosis to make genetically identical copies."]).
answer(number(4),part(c),subpart(i),[133,2,"This is a genetically identical offspring to its parent with identical characteristics."]).
answer(number(4),part(c),subpart(i),[134,2,"A genetically identical reproduction of the initial object from which the cell comes from."]).
answer(number(4),part(c),subpart(i),[135,2,"A cell division which creates a genetically identical cell."]).
answer(number(4),part(c),subpart(i),[136,2,"An exact gene copy of an organism."]).
answer(number(4),part(c),subpart(i),[137,1,"A clone is an exact carbon copie of something."]).
answer(number(4),part(c),subpart(i),[138,2,"a clone is an exact copy / replica of an organism / cell. The clone goat would carry exactly the same genetic information as the other goat and would look the same."]).
answer(number(4),part(c),subpart(i),[139,1,"A clone is an identical animal of it's self exactly the same."]).
answer(number(4),part(c),subpart(i),[140,2,"is an organism with identical genetic makeup to another organism."]).
answer(number(4),part(c),subpart(i),[141,1,"An exact copy of the Animal, produced by Asexual reproduction."]).
answer(number(4),part(c),subpart(i),[142,1,"a clone is a exact replica taken from certain DNA from the animal"]).
answer(number(4),part(c),subpart(i),[143,2,"A clone is an organism that is a genetically identical (i.e. the nucleus of its body cells contain the same chromosomes) to its 'parent'"]).
answer(number(4),part(c),subpart(i),[144,1,"The clone is where an exact replecar is made buy putting the nucleus of one cell into another cell"]).
answer(number(4),part(c),subpart(i),[145,2,"An animal; aritificialy (asexually) produced; that is genetically identical to it's parent."]).
answer(number(4),part(c),subpart(i),[146,1,"a clone is an exact replica of an organism, created using a sample of its DNA."]).
answer(number(4),part(c),subpart(i),[147,1,"a replica of something, basically a double"]).
answer(number(4),part(c),subpart(i),[148,2,"A clone is an exact copy of a species with its DNA"]).
answer(number(4),part(c),subpart(i),[149,2,"A clone is genetically identical to what it has been cloned by, by the process of mitosis."]).
answer(number(4),part(c),subpart(i),[150,2,"An exact genetic copy of the original"]).
answer(number(4),part(c),subpart(i),[151,1,"is an exact copy of a species of plant or animal"]).
answer(number(4),part(c),subpart(i),[152,2,"A genetic copy."]).
answer(number(4),part(c),subpart(i),[153,2,"The is a genetically identical individual."]).
answer(number(4),part(c),subpart(i),[154,1,"it is a replica of another living thing."]).
answer(number(4),part(c),subpart(i),[155,1,"A clone contains the exact genetic makeup of the original organism. They are produced by mitosis."]).
answer(number(4),part(c),subpart(i),[156,1,"a being the same as what it came from."]).
answer(number(4),part(c),subpart(i),[157,1,"It is an exact copy of another thing."]).
answer(number(4),part(c),subpart(i),[158,1,"An identical copy of an organism - It will have exactly the same cells as the thing it was cloned off."]).
answer(number(4),part(c),subpart(i),[159,0,"Where something is artificually copied by genetics."]).
answer(number(4),part(c),subpart(i),[160,1,"A clone is like a twin it is something witch is the same thing person or Animal."]).
answer(number(4),part(c),subpart(i),[161,0,"A model of something or someone else."]).
answer(number(4),part(c),subpart(i),[162,1,"A result of asexual reproduction resulting in an exact replica of its parent."]).
answer(number(4),part(c),subpart(i),[163,0,"a creature being created from another animal cell"]).
answer(number(4),part(c),subpart(i),[164,1,"An identical replica of an original animal / plant / human etc"]).
answer(number(4),part(c),subpart(i),[165,0,"where they take a cell of something and put it in an egg and let it grow so it would be like an twin!"]).
answer(number(4),part(c),subpart(i),[166,0,"Something you get when you are born off your parents. If you look like them or not"]).
answer(number(4),part(c),subpart(i),[167,1,"A clone is an exact replicar of an organism that already exists."]).
answer(number(4),part(c),subpart(i),[168,1,"A clone is where you can clone the animal and make another the same."]).
answer(number(4),part(c),subpart(i),[169,1,"A clone is when a organism cell is copy so that you will then have two identical cells."]).
answer(number(4),part(c),subpart(i),[170,1,"the exact Match of something else made by the cells of something else eg Animals."]).
answer(number(4),part(c),subpart(i),[171,1,"Is a copy of an animal."]).
answer(number(4),part(c),subpart(i),[172,1,"A clone is a replicia of an animal that has not been naturally produced."]).
answer(number(4),part(c),subpart(i),[173,0,"A clone is when a part of the other animals cells is saved to make an animal (same species)"]).
answer(number(4),part(c),subpart(i),[174,1,"cloning is done through asexual reproduction. It is an exact copy of an organism."]).
answer(number(4),part(c),subpart(i),[175,0,"To create something that has already been created so it has same characteristics."]).
answer(number(4),part(c),subpart(i),[176,1,"the same as the original one"]).
answer(number(4),part(c),subpart(i),[177,1,"A clone is an exact replica of a living thing which is made from the cell of a living thing."]).
answer(number(4),part(c),subpart(i),[178,1,"A clone is something Identical to the thing you used a cell from."]).
answer(number(4),part(c),subpart(i),[179,1,"a clone is an identical animal that has been created un-naturally."]).
answer(number(4),part(c),subpart(i),[180,1,"a clone is an exact Replica of another creature"]).
answer(number(4),part(c),subpart(i),[181,0,"Its when you take embryo from the animal and make lots of copy of that one animal"]).
answer(number(4),part(c),subpart(i),[182,1,"a clone is a identily thing that has been copyed. this mean every thing is the same."]).
answer(number(4),part(c),subpart(i),[183,1,"A clone is an identical living organism."]).
answer(number(4),part(c),subpart(i),[184,1,"An exact replica of organism produced from the cells from their organism"]).
answer(number(4),part(c),subpart(i),[185,1,"A clone is an exact copy of an organism."]).
answer(number(4),part(c),subpart(i),[186,1,"a clone is an exact replica of a living thing"]).
answer(number(4),part(c),subpart(i),[187,1,"A clone is an exact match to the other Animal who had the same cells."]).
answer(number(4),part(c),subpart(i),[188,0,"A clone is a species of something created by cells from another one of its own species."]).
answer(number(4),part(c),subpart(i),[189,0,"a clone is a man made life form created in labs by tubes and freges"]).
answer(number(4),part(c),subpart(i),[190,0,"something that is made by using tissue and no sex cells are needed."]).
answer(number(4),part(c),subpart(i),[191,0,"exact feature of the original burcado"]).
answer(number(4),part(c),subpart(i),[192,0,"genetical"]).
answer(number(4),part(c),subpart(i),[193,0,"A clone is a type of cell from a living thing"]).
answer(number(4),part(c),subpart(i),[194,0,"a clone is when you take the tissue and cell of a animal and try to reproduce it again e.g dolly the sheep."]).
answer(number(4),part(c),subpart(i),[195,0,"an other living thing of the Same Spicies witch man have created"]).
answer(number(4),part(c),subpart(i),[196,0,"Its when you create a animal with DNA."]).
answer(number(4),part(c),subpart(i),[197,0,"a clones is where you mix cells together to make a different embryo"]).
answer(number(4),part(c),subpart(i),[198,0,"Something that you produce by using cells of a living thing"]).
answer(number(4),part(c),subpart(i),[199,0,"A clone is something that will built the population of bucardo's"]).
answer(number(4),part(c),subpart(i),[200,0,"Cells from the organism to be cloned are taken and they try breed them ; reproduce them"]).

 
