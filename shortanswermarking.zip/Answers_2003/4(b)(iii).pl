
:- multifile answer/4.
answer(number(4),part(b),subpart(iii),[1,1,"Because high in the mountains it is not a hospitable environment for humans and usually there are not conservation centres there so they have to be monitored somewhere else."]).
answer(number(4),part(b),subpart(iii),[2,0,"people don't know properly whats on the mountains as people don't tend to live on them."]).
answer(number(4),part(b),subpart(iii),[3,1,"They are not seen that often, and it is hard to keep tabs on them."]).
answer(number(4),part(b),subpart(iii),[4,1,"Because it would take ages to get to them and then it made it dangerous for humans"]).
answer(number(4),part(b),subpart(iii),[5,0,"The mountains are steep and are high up in the air so the temperature is low and there may not be many other organisms living in such an area."]).
answer(number(4),part(b),subpart(iii),[6,1,"Not much human activity goes on in the mountains, and they are difficult to get to, therefore it is harder to monitor whether the bucardo are being hunted or not."]).
answer(number(4),part(b),subpart(iii),[7,1,"It lived away from homes and people cant live on it to look after them because of landslides"]).
answer(number(4),part(b),subpart(iii),[8,1,"because even in high numbers they are rarley seen due to their habitat so you can't watch their progress or see what people are doing to them"]).
answer(number(4),part(b),subpart(iii),[9,1,"It was difficult because it would be very cold and also it would be very dangerous for humans to be regularly in the mountains due to risks of landslides and other dangers. It also would be very hard to find the bucardo and keep track of its whereabouts."]).
answer(number(4),part(b),subpart(iii),[10,1,"becauce it would be hard to get up to them"]).
answer(number(4),part(b),subpart(iii),[11,1,"Mountains are big which makes it hard to find and count each bucardo"]).
answer(number(4),part(b),subpart(iii),[12,1,"They went places where it was very diffeicult to find them."]).
answer(number(4),part(b),subpart(iii),[13,1,"It's hard to keep track of it."]).
answer(number(4),part(b),subpart(iii),[14,1,"As these are very difficult conditions to live in and you need to be a good climber - therefore they are difficult to access and consequently, protect."]).
answer(number(4),part(b),subpart(iii),[15,1,"it was difficult place to monitor rather than on flat plains."]).
answer(number(4),part(b),subpart(iii),[16,0,"because once they were widespread"]).
answer(number(4),part(b),subpart(iii),[17,0,"beouse in the high mountains it is cold and there is less oxygen up there."]).
answer(number(4),part(b),subpart(iii),[18,0,"No man could get up there to protect it neither can they take it away from its natural habitat"]).
answer(number(4),part(b),subpart(iii),[19,1,"They had such a huge range of places to go and they could get up places humans couldn't."]).
answer(number(4),part(b),subpart(iii),[20,0,"Because you cannot live in the mountains for a long time because you need food & water to survive"]).
answer(number(4),part(b),subpart(iii),[21,1,"It is a difficult species to protect because they live so high up people cannot moniter them very well leading to innaccurate thoughts of the amount of them."]).
answer(number(4),part(b),subpart(iii),[22,1,"they could be hard to find to look after."]).
answer(number(4),part(b),subpart(iii),[23,1,"hunters could by pase sucuroty becouse of the vast area."]).
answer(number(4),part(b),subpart(iii),[24,1,"Rules are difficult to anyone high in the mountains and it is difficult for humans to try and live up there and establish effective measures for its protection."]).
answer(number(4),part(b),subpart(iii),[25,1,"Because there could have been landslides, in which the bucardo's could have died and also because they lived in the mountains it is hard to protect them because less people live on the high mountains."]).
answer(number(4),part(b),subpart(iii),[26,1,"Because it would have been difficult for man to climb the mountain on a regular basis and it would have been hard to find the goat once situated on the mountain."]).
answer(number(4),part(b),subpart(iii),[27,0,"Because it could have fallen down the mountain and they are so far away."]).
answer(number(4),part(b),subpart(iii),[28,0,"Mountains may cover a wide area of land."]).
answer(number(4),part(b),subpart(iii),[29,1,"It will be difficult to monitor the bucardo as mountains are less accesseble and the mountains will make it easy for both bucardos and hunters to hide from i.e, officials trying to protect the bucardo."]).
answer(number(4),part(b),subpart(iii),[30,1,"difficult to monitor and track the bucardo."]).
answer(number(4),part(b),subpart(iii),[31,1,"As humans cannot live in the mountains easily so we cannot keep close watch on them to look after them or protect them."]).
answer(number(4),part(b),subpart(iii),[32,1,"There would be many natural disasters such as landslides which is more difficult to prevent"]).
answer(number(4),part(b),subpart(iii),[33,1,"There is a widespread of land which is hard to find so few species and to protect them. There is difficulty in transport to the montains as it is rocky + high"]).
answer(number(4),part(b),subpart(iii),[34,1,"Because of the climate and rocky terrain in the mountains and the danger of rodeslides etc it is a dangerous habitat to live. It is also hard for people to find and keep track of the bucardos in such a habitat"]).
answer(number(4),part(b),subpart(iii),[35,1,"A mountainous enviroment is difficult to re-create making controlled breeding difficult and it is also difficult to moniter and protect."]).
answer(number(4),part(b),subpart(iii),[36,1,"Not alot of people could look out for them and made it easy for hunters to hunt them down. Alot of accidents could happen up high in the mountains"]).
answer(number(4),part(b),subpart(iii),[37,1,"Because they could not easily be monitered and the dangerous terrain of the mountain meant it was easy for them to be killed (Falling off the mountain, landslide)"]).
answer(number(4),part(b),subpart(iii),[38,1,"Because the location is high, it is difficult to transport the caring materials up to the Bucardo."]).
answer(number(4),part(b),subpart(iii),[39,1,"Because it is difficult to keep track of exactly how many there are as they live in such remote places."]).
answer(number(4),part(b),subpart(iii),[40,1,"They would have been hard to get to and difficult to treat"]).
answer(number(4),part(b),subpart(iii),[41,1,"because it is harder for the people who are protecting it to control what happens and maybe can't reach some of the places they goto"]).
answer(number(4),part(b),subpart(iii),[42,0,"cant keep an eye on who goes up the mountains and when"]).
answer(number(4),part(b),subpart(iii),[43,1,"Because they would have been hard to reach and therefore count population numbers or catch them and try and breed them in captivity."]).
answer(number(4),part(b),subpart(iii),[44,1,"The bucardo live across a vast area so it is very difficult to count them and be aware of their progress."]).
answer(number(4),part(b),subpart(iii),[45,1,"Because it is hard to get to high in the mountains."]).
answer(number(4),part(b),subpart(iii),[46,1,"One cannot protect them from landslides, mudslides, earthquakes etc."]).
answer(number(4),part(b),subpart(iii),[47,1,"Mountains are hard for humans to access so the mountains cannot be patrolled easily to prevent poachers"]).
answer(number(4),part(b),subpart(iii),[48,0,"thin air for man to get to and to Dangerous"]).
answer(number(4),part(b),subpart(iii),[49,1,"Because not many humans, if any, lived there so it would be hard to keep track of them."]).
answer(number(4),part(b),subpart(iii),[50,1,"It is difficult to access them and therefore moniter their numbers in such high up and rocky areas, and difficult to police these areas against harmful factors."]).
answer(number(4),part(b),subpart(iii),[51,1,"People cannot or do not live in the mountains, so they cannot (bucardo) be closely or daily monitered or easily detected as the environment is a difficult place to protect anything in it."]).
answer(number(4),part(b),subpart(iii),[52,0,"Mountain climates are very sparse, so the habitat of the bucardo would of been small, the higher the mountain the less oxygen there is"]).
answer(number(4),part(b),subpart(iii),[53,1,"It was probably hard to monitor its habitat as it would be hard to view the whole area at once."]).
answer(number(4),part(b),subpart(iii),[54,1,"They couldn't be watched very well to look for poachers."]).
answer(number(4),part(b),subpart(iii),[55,1,"As the majority of the human population does not live high in the mountains, making it hard to reach and causing breathing problems due to the lack of oxygen. Furthermore it is harder to catch as humans are not adapted for the mountain environment"]).
answer(number(4),part(b),subpart(iii),[56,1,"because its hard to get to mountains and the humans can't get to all places the bucardo can."]).
answer(number(4),part(b),subpart(iii),[57,1,"because it is hard to reach the high mountains because of the unstable surface."]).
answer(number(4),part(b),subpart(iii),[58,1,"It is difficult to monitor whether people are killing them when they are in a remote area as it cannot be seen or heard often. It is also difficult to alert people of the problem."]).
answer(number(4),part(b),subpart(iii),[59,0,"This made it difficult to protect due to the high mountains"]).
answer(number(4),part(b),subpart(iii),[60,1,"The enviroment they live in is remote and it would be difficult to watch and protect them constantly"]).
answer(number(4),part(b),subpart(iii),[61,1,"Because it is difficult to survey all the mountains to ensure illegal poaching is not taking place"]).
answer(number(4),part(b),subpart(iii),[62,1,"This would make it a difficult species to protect because the mountains take up such a large area of land it would be difficult to keep an eye on them in such a vast space."]).
answer(number(4),part(b),subpart(iii),[63,1,"mountains are extremely dangerous, with the cold climate at the semit, the unexpected landslides, mountains are unstable."]).
answer(number(4),part(b),subpart(iii),[64,0,"Not many people live up in mountains so there would have been less people to enforce it's protection and survival."]).
answer(number(4),part(b),subpart(iii),[65,1,"It would be hard for people to check whether anyone is doing anything illigal."]).
answer(number(4),part(b),subpart(iii),[66,0,"It is not easy for people to set up wildlife parks and such in the mountains."]).
answer(number(4),part(b),subpart(iii),[67,0,"It would be difficult to have a protective barrier such as a game reserve in the mountains and the bucardos would not be able to be watched to see if any harm was coming to them."]).
answer(number(4),part(b),subpart(iii),[68,1,"Because it is a dangerous habitat to live in ie falling trees and animals living there are prone to natural disasters. Also it takes people a lot more effort, and is a lot more dangerous to try and conserve them."]).
answer(number(4),part(b),subpart(iii),[69,1,"if it not easy to get there quickly or easily so it would take time to get there if anything happened, and it would be harder to protect them there."]).
answer(number(4),part(b),subpart(iii),[70,1,"Because they are difficult for humans to reach and it is a difficult habitat to replicate in a zoo."]).
answer(number(4),part(b),subpart(iii),[71,1,"because it is hard to get high up to make sure if it was ok and you can not move it because if you do it not use to being on flat land."]).
answer(number(4),part(b),subpart(iii),[72,1,"It is hard to protect as man are unable to reach such high areas to protect the animals. The conditions also make it hard for man to live in."]).
answer(number(4),part(b),subpart(iii),[73,0,"Because it would be hard to stop people getting to theme."]).
answer(number(4),part(b),subpart(iii),[74,0,"because it lives high on montains it means that it can not be rounded up and took to special reserve"]).
answer(number(4),part(b),subpart(iii),[75,1,"It's hard for people to get up to the top to help the bucardos because it may be quite dangerous"]).
answer(number(4),part(b),subpart(iii),[76,0,"There may be other more dangerous types of animal that may hunt them down for food."]).
answer(number(4),part(b),subpart(iii),[77,1,"The mountains made it difficult for human aid to approach them. It is a hard area to cover."]).
answer(number(4),part(b),subpart(iii),[78,1,"It was difficult to get to."]).
answer(number(4),part(b),subpart(iii),[79,1,"because there are natural causes that can kill the bucardo and if it is injured it is hard to go and give it medical attension"]).
answer(number(4),part(b),subpart(iii),[80,1,"It was a difficult species to protect because not many people could count its numbers or stop others from hunting, as not many people live or go up high in the mountains."]).
answer(number(4),part(b),subpart(iii),[81,1,"It is hard for people to reach high mountainous areas. They would probably have to climb or be airlifted to reach the animals."]).
answer(number(4),part(b),subpart(iii),[82,1,"because the mountains are quite out of the way therefore it is hard to keep an eye on the animals"]).
answer(number(4),part(b),subpart(iii),[83,1,"because it is harder to reach them because they lived so high up."]).
answer(number(4),part(b),subpart(iii),[84,1,"High in the mountains is more inaccesable for humans. Not conveniant as limited transport and difficult weather conditions"]).
answer(number(4),part(b),subpart(iii),[85,1,"Few live high upon the mountains and therefore it is a difficult to help the Bucardo. It is difficult and dangerous to climb up the mountains to protect the animal - by bringing it food etc."]).
answer(number(4),part(b),subpart(iii),[86,1,"It is difficult to monitor the lifestyle of the bucardo & it is difficult to look after them when they are so high up."]).
answer(number(4),part(b),subpart(iii),[87,1,"The mountain tops are hard to reach and probably uninhabitable making it harder for man to protect them from hunters and also landslides."]).
answer(number(4),part(b),subpart(iii),[88,1,"It means that this rule can not easily be enforced as there are no park wardens high up in the mountains also the number of bucardos are hard to find out because of the hostile terrain and so we don't know how many there should be and therefore if some ar"]).
answer(number(4),part(b),subpart(iii),[89,1,"Because the mountains are very remote and it would be difficult for scientists to get to parts of them."]).
answer(number(4),part(b),subpart(iii),[90,1,"As this is a hard place to moniter them as it is difficult terrain to travel across."]).
answer(number(4),part(b),subpart(iii),[91,1,"It is a lot harder to get high into the mountains and so this will be a big problem as in 1973 when the specie needed to be protected ther weren't as good technology as there is now. Also there are less to find making it harder."]).
answer(number(4),part(b),subpart(iii),[92,1,"It would be hard for people to record how many there were."]).
answer(number(4),part(b),subpart(iii),[93,1,"It Is Hard to get Lots of people up Into the mountains."]).
answer(number(4),part(b),subpart(iii),[94,0,"No human's live up in the mouintains to protect it from other animals etc."]).
answer(number(4),part(b),subpart(iii),[95,1,"This would mean having to constantly climb the mountains, to check the animals, it is also dificult to control the environment of a mountain as they are dangerous and wild."]).
answer(number(4),part(b),subpart(iii),[96,1,"It is difficult to get to them to protect them"]).
answer(number(4),part(b),subpart(iii),[97,0,"because the mountain is dangerous and could kill them if they fell."]).
answer(number(4),part(b),subpart(iii),[98,1,"The fact they lived in mountanous areas makes them difficult to protect possibly because of the unpreventable natural hozzards such as landslides."]).
answer(number(4),part(b),subpart(iii),[99,0,"they were too far away"]).
answer(number(4),part(b),subpart(iii),[100,1,"Because the animal was so high up, so it was difficult to reach and not many people would want to climb a mountain to 'just' protect a species of animal who is most probably going to die anyway."]).
answer(number(4),part(b),subpart(iii),[101,1,"It is very hard to find them"]).
answer(number(4),part(b),subpart(iii),[102,0,"because the fell of the mountains."]).
answer(number(4),part(b),subpart(iii),[103,1,"It was difficult to find the bucardos as the terrain made it difficult for humans to get to their habitat. Therefore people couldn't find out what help the bucardos needed or why they were dying, or find bucardos so they could know how many there were."]).
answer(number(4),part(b),subpart(iii),[104,1,"Protectors would find it difficult to find and locate the bucardo"]).
answer(number(4),part(b),subpart(iii),[105,1,"Because there out of sight, hard to find, and keep track of"]).
answer(number(4),part(b),subpart(iii),[106,0,"There aren't many people up in the mountains to protect them."]).
answer(number(4),part(b),subpart(iii),[107,1,"because there are alot of natural desarsters in the high tops of mountains."]).
answer(number(4),part(b),subpart(iii),[108,1,"Because it is a difficult place to visit to track the progress of the species."]).
answer(number(4),part(b),subpart(iii),[109,1,"Because it would be difficult to get up to the mountains to keep track of the bucardo's"]).
answer(number(4),part(b),subpart(iii),[110,1,"People cannot watch over the bucardo all the time because the area is large and too difficult to get to."]).
answer(number(4),part(b),subpart(iii),[111,1,"It would have been difficult for humans to travel up the mountains, as the terrain would probably be to steep and dangerous for cars or trucks to travel across."]).
answer(number(4),part(b),subpart(iii),[112,0,"Because they could fall off the mountain if they loose their balance."]).
answer(number(4),part(b),subpart(iii),[113,0,"the mountains cold and slipey so it was harder to protect them"]).
answer(number(4),part(b),subpart(iii),[114,1,"They are hard to find and monitor numbers or rescue from dangerous situations. It also means they cannot be put into breeding programs as they are hard to catch."]).
answer(number(4),part(b),subpart(iii),[115,1,"The mountains are quite inaccessible and difficult to monitor regularly because there is no nature reserve in the mountains and they cannot be taken away from their natural habitat"]).
answer(number(4),part(b),subpart(iii),[116,1,"People could not get to them. Difficult to capture, or get hold of."]).
answer(number(4),part(b),subpart(iii),[117,0,"because not many people live in mountains to protect them no one could keep an eye on them."]).
answer(number(4),part(b),subpart(iii),[118,0,"because you could never lived in the mountains because it would have been to cold."]).
answer(number(4),part(b),subpart(iii),[119,1,"It is hard to reach by humans."]).
answer(number(4),part(b),subpart(iii),[120,1,"It is difficult to track it, so calculations of how many there are are hard to make, and may be innacurate. It is also hard to moniter hunting high in the mountains."]).
answer(number(4),part(b),subpart(iii),[121,1,"because it might not be manageable for man kind to reach where bucardos live."]).
answer(number(4),part(b),subpart(iii),[122,1,"becouse its hard to get up into the mountains, so its hard to stop poachers. Also there are all the landslides and stuff."]).
answer(number(4),part(b),subpart(iii),[123,1,"It is hard to travel up mountains and so its hard to protect them as they are difficult to reach."]).
answer(number(4),part(b),subpart(iii),[124,1,"Because there cannot easily have rangers to check if they are surviving or if they are being hunted."]).
answer(number(4),part(b),subpart(iii),[125,1,"Living high in the mountains meant that it was fairly difficult for man to get up there and help it."]).
answer(number(4),part(b),subpart(iii),[126,1,"Because it's difficult to stop people from going up the mountains and killing them."]).
answer(number(4),part(b),subpart(iii),[127,1,"Mountains are a difficult area for humans to navigate, therefore they had less control over the protection, & couldn't encourage breeding as easily."]).
answer(number(4),part(b),subpart(iii),[128,1,"Few people live high in the mountains, and so their population cannot easily be monitored. Also, it becomes harder to look after them in such remote areas. Furthermore, it's habitat cannot be replicated in a zoo easily to prevent extinction"]).
answer(number(4),part(b),subpart(iii),[129,1,"As the mountains are a vast area it makes it difficult to monitor there numbers and stop anybody trying to hunt them."]).
answer(number(4),part(b),subpart(iii),[130,0,"Hunters and country people would go shooting for a game and kill them."]).
answer(number(4),part(b),subpart(iii),[131,0,"high in the moutains people can spot you from far."]).
answer(number(4),part(b),subpart(iii),[132,0,"because you would have to keep track of it and this means climing the mountains."]).
answer(number(4),part(b),subpart(iii),[133,1,"because it is a large area to cover and it is difficult getting high up in the mountains."]).
answer(number(4),part(b),subpart(iii),[134,1,"It isn't likely many humans live up there so they wouldn't be able to monitor the species very well."]).
answer(number(4),part(b),subpart(iii),[135,0,"It would take too long to climb a mountain and look for every bucardo to put an electronic tag on it."]).
answer(number(4),part(b),subpart(iii),[136,0,"The mountains are more open and have lots of places they can hide like caves."]).
answer(number(4),part(b),subpart(iii),[137,0,"As there was no one close by to monitor the bucardos and what was going on."]).
answer(number(4),part(b),subpart(iii),[138,1,"It would be difficult for man to climb up to the mountain and help the animals because humans are not adapted to extreme situations. e.g. the height, surface (our feet don't grip). landslides make it dangerous to go up a mountain."]).
answer(number(4),part(b),subpart(iii),[139,0,"The bucardo was not surrounded by urban area's where people could check on them."]).
answer(number(4),part(b),subpart(iii),[140,0,"It is hard to control its surroundings and it was a hard environment to reproduce in captivity."]).
answer(number(4),part(b),subpart(iii),[141,0,"because its to high up and to far and ther are alot of other wildlife up there."]).
answer(number(4),part(b),subpart(iii),[142,1,"the goats lived high in the mountains so people could not get to the goat to protect them well enough"]).
answer(number(4),part(b),subpart(iii),[143,0,"This made it a difficult species to protect, as they cannot take them to specific breeding grounds, and also they cannot prevent people from going onto a mountain."]).
answer(number(4),part(b),subpart(iii),[144,1,"Mountains are hard to transport essential things to, and many natural disasters (like landslides) occur easily there. It is difficult for humans to protect animals against such disasters."]).
answer(number(4),part(b),subpart(iii),[145,1,"people cannot move to the mountains to look after them and natural disasters cannot be prevented, The Bucardo is also likely to hide away and not be seen."]).
answer(number(4),part(b),subpart(iii),[146,0,"Because it will be hard to enclose them into a specific place for them to be protected."]).
answer(number(4),part(b),subpart(iii),[147,0,"because you will have to travel up there to see them."]).
answer(number(4),part(b),subpart(iii),[148,1,"It would be hard to enforce bans if no-one was nearby, it would be labour intensive to go so far away to the high mountains and it would be hard to reach them."]).
answer(number(4),part(b),subpart(iii),[149,0,"It is hard to controll what people are doing up a mountain."]).
answer(number(4),part(b),subpart(iii),[150,0,"Not many people would be around to help them or stop them being hunted."]).
answer(number(4),part(b),subpart(iii),[151,1,"This could have been because they are difficult to keep track of, or reach if they are in danger."]).
answer(number(4),part(b),subpart(iii),[152,1,"Mountainous areas are very hard to reach, so people can not tell if the bucardos are as protected as they should be and mountainous areas are hard to keep protected from harm."]).
answer(number(4),part(b),subpart(iii),[153,1,"Access to the goats habitat would have been difficult and possibly dangerous so it would be difficult for people to monitor and protect."]).
answer(number(4),part(b),subpart(iii),[154,0,"Well away from settlements and you cant close down a mountian just for the goats"]).
answer(number(4),part(b),subpart(iii),[155,0,"Not many people live in the mountains so the bucardo could not be protected all the time so they were still dieing."]).
answer(number(4),part(b),subpart(iii),[156,1,"Cause they are hard to get to"]).
answer(number(4),part(b),subpart(iii),[157,1,"High mountain areas are not easily accesible, and one reason why the goats lived there could have been to stay away from people. This means if people began to climb the mountain to protect them they would probably try to run away."]).
answer(number(4),part(b),subpart(iii),[158,1,"because its hard for us to survie in the mountains because of cold and its stepness."]).
answer(number(4),part(b),subpart(iii),[159,1,"Man was not designed to with-stand the climate in mountains so its hard to get to the mountainous areas that they inhabit to enforce this protection."]).
answer(number(4),part(b),subpart(iii),[160,0,"It is so high up and it is hard to look after ther and no one lived up there."]).
answer(number(4),part(b),subpart(iii),[161,0,"because it cost a lot of money to ensure the safety of a human when climbing a mountain. There fore even more money will be spent protecting the animal"]).
answer(number(4),part(b),subpart(iii),[162,0,"mountain are big so large areas have to been cover to protect the bucardo"]).
answer(number(4),part(b),subpart(iii),[163,1,"it was difficult to monitor the movement and the where abouts of the Animal"]).
answer(number(4),part(b),subpart(iii),[164,1,"It could easily fall or there could be landslides."]).
answer(number(4),part(b),subpart(iii),[165,1,"Because although it is less likely that many humans will be around it often, natural disasters could occur ie landslides."]).
answer(number(4),part(b),subpart(iii),[166,1,"high up and hard to keeps numbers"]).
answer(number(4),part(b),subpart(iii),[167,1,"Mountains are not very accessible areas, and cover large areas. Hence it was difficult to accurately record its population and enforce anti-hunting laws."]).
answer(number(4),part(b),subpart(iii),[168,1,"the mountanious land would have meant man could not protect the bucardo by cars and the landscape would be difficult to cross quickly on foot. There would also be many hiden places where they could be. Also they would not be used to people and therefore m"]).
answer(number(4),part(b),subpart(iii),[169,1,"Because nobody would really be able to keep an eye on it a hunters could still get away with killing them."]).
answer(number(4),part(b),subpart(iii),[170,0,"Not many people go high up in the Mountains"]).
answer(number(4),part(b),subpart(iii),[171,1,"As it would be hard to keep going up to monitar the animal there could be natural desetors that could kill animal"]).
answer(number(4),part(b),subpart(iii),[172,1,"hard to get up there. Some people also cant be seen."]).
answer(number(4),part(b),subpart(iii),[173,0,"They lived high in the mountains where it is dangerous and trying to save them would be very difficult due to the risks involved"]).
answer(number(4),part(b),subpart(iii),[174,0,"- Birds could attack it and eat it. - Humans can't get up to the mountains to protect the goat."]).

/*answer(number(4),part(b),subpart(iii),[175,0,"(too hard to get up there) As people do not live in the mountains so cannot find the goats and monitor them Hard to control preditors as well"]).
answer(number(4),part(b),subpart(iii),[176,"Difficult access to high mountains. bad weather conditions for humans. need lots of equipment so can stay up there to look for them. Difficult access - hard to find."]).
answer(number(4),part(b),subpart(iii),[177,"Because they are alone and they cant really defend themselves"]).
answer(number(4),part(b),subpart(iii),[178,"Not many animals lived high in the mountains for one, and for two there a same species of this type of goat."]).
answer(number(4),part(b),subpart(iii),[179,"because no other prediture could get to kill the species. If it was high in the mountain."]).
answer(number(4),part(b),subpart(iii),[180,"The mountains can be a dangerous ecosystem and its hard to protect the animals habitat when there are different climates and conditions high up."]).
answer(number(4),part(b),subpart(iii),[181,"because of the dry cold air no food"]).
answer(number(4),part(b),subpart(iii),[182,"No other species are adapted to living high in the mountains. They would not be able to survive."]).
answer(number(4),part(b),subpart(iii),[183,"people like to climb mountains so you can't stop them climbing for a goat"]).
answer(number(4),part(b),subpart(iii),[184,"The bucardo is adapted to a not easily replicable environment, so ideally it would stay where it was, but then it is more at risk from hunters and must fend for itself"]).
answer(number(4),part(b),subpart(iii),[185,"You could'nt group a hole load together to incourage them to breed."]).
answer(number(4),part(b),subpart(iii),[186,"because it couldn't be kept in captivity because it's adapted to living in the mountains."]).
answer(number(4),part(b),subpart(iii),[187,"It is dangerous for men to protect it because of tempeature and the amount of food they have."]).
answer(number(4),part(b),subpart(iii),[188,"The mountain could be a large one and maybe dangerous to try and catch one or many and protect them all."]).
answer(number(4),part(b),subpart(iii),[189,"because you cant catch them"]).
*/

answer(number(4),part(b),subpart(iii),[190,0,"The hight of the mountains and they may slip on a wet day."]).
answer(number(4),part(b),subpart(iii),[191,0,"The area that needs to be sectioned off is unknown because scientists don't know the exact place it lives. It is also very hard to section off a whole mountain top because it is used for other purposes by humans i:e farming."]).
answer(number(4),part(b),subpart(iii),[192,0,"its to high up for people to protect them."]).
answer(number(4),part(b),subpart(iii),[193,0,"Because then they couldn't be in their natural environment they would have to adjust a great deal"]).
answer(number(4),part(b),subpart(iii),[194,1,"They cannot be surveyed descretely, easily or often."]).
answer(number(4),part(b),subpart(iii),[195,0,"It couldn't be kept in a zoo because it needed certain conditions it was used to."]).
answer(number(4),part(b),subpart(iii),[196,0,"Because no-one can see you up there"]).
answer(number(4),part(b),subpart(iii),[197,0,"because the higher up the mountains the less amount of oxygen there is."]).
answer(number(4),part(b),subpart(iii),[198,1,"The mountains are dangoress and many would be killed by nature"]).
answer(number(4),part(b),subpart(iii),[199,0,"Humans are not adapted to that kind of environment so they can't help any ill or injured Bucardo goats."]).
answer(number(4),part(b),subpart(iii),[200,0,"Bucardos could hide, hard to protect and mountain."]).

 
